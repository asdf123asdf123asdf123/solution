#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 1005;

namespace Josh_zmf {

	const int MOD = 10007;
	int N, stk[Maxn], top;
	vector <int> son[Maxn];
	
	inline int solve() {
//		printf("solve():: ");
//		for(int i=1; i<=top; i++)	printf("%d, ", stk[i]);
//		puts("");
		int res = 0;
		for(int i=1; i<=top; i++) {
			if(!son[stk[i]].size()) {
				res++; continue;
			}
			int u = stk[i];
			stk[i] = son[u][0];
			for(int j=1; j<(int)son[u].size(); j++) {
				stk[++top] = son[u][j];
			}
			res += solve();
			stk[i] = u, top -= son[u].size()-1;
		}
		return max(res, 1) %MOD;
	}
	
	inline int pow(int a, int b) {
		int res = 1;
		while(b) {
			if(b&1)	res = (res*a) %MOD;
			a = (a*a) %MOD, b >>= 1;
		}
		return res;
	}

	int main() {
		int T; scanf("%d", &T);
		while(T--) {
			for(int i=1; i<=N; i++)	son[i].clear();
			scanf("%d", &N);
			for(int i=1; i<=N; i++) {
				int k;
				scanf("%d", &k);
				int u = i, v;
				for(int j=1; j<=k; j++) {
					scanf("%d", &v);
					son[u].push_back(v);
					u = v;
				}
			}
			stk[top = 1] = 1;
			cout<< solve()<< '\n';
//			int cnt = 0;
//			for(int i=1; i<=N; i++) if(!son[i].size())	cnt++;
//			printf("cnt:%d\n", cnt);
//			int ans = 1;
//			for(int k=cnt; k>=2; k--)	ans = (ans*k) %MOD;
//			cout<< ans<< '\n';
//			int ans = 1;
//			for(int k=2; k<=N; k++)	ans = (ans*k) %MOD; 
//			int mod_2 = pow(2, MOD-2), mod_3 = pow(3, MOD-2);
//			for(int i=1; i<=N; i++) {
//				if(son[i].size() == 1)	ans = (ans*mod_2) %MOD;
//				if(son[i].size() == 2)	ans = (ans*mod_3) %MOD;
//			}
//			cout<< ans<< '\n';
		}
		return 0;
	}

}

int main() {
	freopen("lineup.in", "r", stdin);
	freopen("lineup.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
/*
2
5
2 2 3
2 4 5
0
0
0
7
2 2 3
2 4 5
2 6 7
0
0
0
0

*/ 
