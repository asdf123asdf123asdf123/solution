#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	return 0;
}
