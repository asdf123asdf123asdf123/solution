#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	int mod=10007;
	int T;
	int n,ans;
	struct node
	{
		int to,next;
	}ed[10005];
	int head[10005],cnt;
	void add(int x,int y)
	{
		cnt++;
		ed[cnt].to=y;
		ed[cnt].next=head[x];
		head[x]=cnt;
	}
	int d[1001][1001];
	int x[1005];
	int f[1005];
	void init()
	{
		cnt=0;
		memset(ed,0,sizeof(ed));
		memset(head,0,sizeof(head));
		memset(f,0,sizeof(f));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			int k;
			scanf("%d",&k);
			for(int j=1;j<=k;j++)
			{
				scanf("%d",&x[j]);
				add(i,x[j]);
				d[i][x[j]]=1;//x���ܷ���iǰ�� 
				for(int a=1;a<j;a++)
				{
					d[x[a]][x[j]]=1;
				}
			}
			
		}
	}
//	int maxx;
//	int dis[10005],son[10005],num[10005],size[10005];
	
/*	void dfs(int u,int fa)
	{
		num[dis[u]]++;
		maxx=max(dis[u],maxx);
		int g=0;
		size[u]=1;
		for(int i=head[u];i;i=ed[i].next)
		{
			int v=ed[i].to;
			if(v==fa)continue;
			dis[v]=dis[u]+1;
			dfs(v,u);
			son[v]=g;
			g+=size[v];
			size[u]+=size[v];
		}
	}*/
	void dfs(int u,int fa)
	{
		int son=0;
		for(int i=head[u];i;i=ed[i].next)
		{
			int v=ed[i].to;
			if(v==fa)continue;
			son++;
			dfs(v,u);
		}
		if(!son)f[u]=1;
		for(int i=head[u];i;i=ed[i].next)
		{
			int v=ed[i].to;
			if(v==fa)continue;
			f[u]+=f[v];
			f[u]%=mod;
		}
	}
	int bj[10005],vst[10005];
	void dfs1(int now)
	{
		if(now==n+1)
		{
			for(int i=1;i<=n;i++)
			{
				for(int j=i+1;j<=n;j++)
				{
					if(d[bj[j]][bj[i]])return ;
				}
			}
			ans++;
			ans%=mod;
			return ;
		}
		for(int i=1;i<=n;i++)
		{
			if(!vst[i])
			{
				bj[now]=i;
				vst[i]=1;
				dfs1(now+1);
				bj[now]=0;
				vst[i]=0;
			}
		}
	}
	
	int main()
	{
		freopen("lineup.in","r",stdin);
		freopen("lineup.out","w",stdout);
		scanf("%d",&T);
		while(T--)
		{
			ans=0;
			init();
			if(n<=9)
			{
				dfs1(1);
				printf("%d\n",ans);
				continue;
			}
			dfs(1,0);
			printf("%d\n",f[1]);
		}
		return 0;
	}
}
int main()
{
	return lzz::main();
}
