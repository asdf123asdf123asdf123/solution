#include<bits/stdc++.h>
using namespace std;
int ans;
int n;
bool bj[1005];
int fa[1005],to[1005];
void dfs(int x,int c){
	//cout << x <<" "<< c <<"\n";
//	if(c > n){
//		for(int i =1; i<= n; i ++){
//			cout << to[i] << " ";
//		}
//		cout << "\n";
//		ans++;
//	}
	//cout << "xz: "<< fa[x] << "\n";
	for(int i =1; i <= n; i ++){
		
		if(i == fa[x] ){//&& i != x
			bj[i] =1;
			to[x] = i;
			bool fl = 1;
			for(int j = 1; j <= n; j ++){
				if(!bj[j]&&fa[j] == j){
					fl = 0;
					dfs(j,c+1);
				}
			}
			if(fl){
				for(int j = 1; j <= n;j ++){
					cout << to[j] <<" ";
				}
				cout <<"\n";
				cout << "cg\n";
				ans++;
			}
			bj[i] = 0;
		}
		else if(!bj[i]&&fa[i]==i && i != x){
			fa[i] = fa[x];
			to[x] = i;
			
			dfs(i,c+1);	
			fa[i] = i;
		}
	}
	return ;
}
namespace AK_IOI{
	int main(){
		cin >> n;
		for(int i =1; i <= n; i ++){
			fa[i] = i;
			to[i] = i;
		}
		dfs(1,1);
		cout <<ans;
		return 0;
	}
}
int main(){
//	freopen("game.in","r",stdin);
//	freopen("game.out","w",stdout);
	AK_IOI::main(); // I ak IOI!!!
	return 0;
}
/*
3
*/
