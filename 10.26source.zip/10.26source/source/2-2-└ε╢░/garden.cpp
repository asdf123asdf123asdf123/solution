#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int get_dis(int x1,int y1,int x2,int y2){
		return abs(x2-x1)+abs(y2-y1);
	}
	int n;
	int pos[100050];
	int main(){
		freopen("garden.in","r",stdin);
		freopen("garden.out","w",stdout);
		
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",pos+i);
		sort(pos+1,pos+1+n);
		
		 int t;
		 scanf("%d",&t);
		 while(t--){
		 	int x1,y1,x2,y2;
		 	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
		 	if(x1>x2){
		 		swap(x1,x2);
		 		swap(y1,y2);
		 	}
		 	if(y1>0&&y2>0){
		 		cout<<get_dis(x1,y1,x2,y2)<<'\n';
		 		continue;
		 	}
		 	if(y1<0&&y2<0){
		 		cout<<get_dis(x1,y1,x2,y2)<<'\n';
		 		continue;
		 	}
		 	
		 	int l=1,r=n;
			while(l<=r){
				int mid=(l+r)/2;
				if(pos[mid]>x2)r=mid-1;
				else l=mid+1;
			}
			int p=r;
			int ans=1e9;
			ans=min(ans, get_dis(x1,y1,pos[p],0)+get_dis(x2,y2,pos[p],0));
			ans=min(ans, get_dis(x1,y1,pos[p-1],0)+get_dis(x2,y2,pos[p-1],0));
			ans=min(ans, get_dis(x1,y1,pos[p+1],0)+get_dis(x2,y2,pos[p+1],0));
			cout<<ans<<'\n';
		 	
		 } 
		
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}
