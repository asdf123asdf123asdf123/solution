#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	string a;
	int n,m;
	int sum[2005];
	int f1[2005][2005],f2[2005][2005];//����ǰi���˷�Ϊj�����С����
	int ans1[10005],ans2[10005];
	void solve1()
	{
		int cnt=0;
		for(int j=1;j<=m;j++)
		{
			int minn=0;
			for(int i=ans1[cnt]+1;i<=n;i++)
			{
				if(max(f1[i][j],f2[n-i][m-j])==f1[n][m])
				{
					minn=i;
					break;
				}
			}
			ans1[++cnt]=minn;
		}
	} 
	void solve2()
	{
		int cnt=0;
		for(int j=1;j<=m;j++)
		{
			int maxx=0;
			for(int i=ans1[cnt]+1;i<=n;i++)
			{
				if(max(f1[i][j],f2[n-i][m-j])==f1[n][m])
				{
					maxx=max(maxx,i);
				}
			}
			ans2[++cnt]=maxx;
		}
	} 
	void init1()
	{
		for(int i=0;i<=n;i++)
		{
			for(int j=0;j<=m;j++)
			{
				f1[i][j]=1e9;
			}
		}
		f1[0][0]=1;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=min(i,m);j++)
			{
				for(int k=0;k<i;k++)
				{
					int w=sum[i]-sum[k];//�ж��ٸ�1 
					int g=abs((i-k-w)-w);
					f1[i][j]=min(f1[i][j],max(f1[k][j-1],g));
				}
			}
		}
	}
	void init2()
	{
		for(int i=0;i<=n;i++)
		{
			for(int j=0;j<=m;j++)
			{
				f2[i][j]=1e9;
			}
		}
		f2[0][0]=1;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=min(i,m);j++)
			{
				for(int k=0;k<i;k++)
				{
					int w=sum[i]-sum[k];//�ж��ٸ�1 
					int g=abs((i-k-w)-w);
					f2[i][j]=min(f2[i][j],max(f2[k][j-1],g));
				}
			}
		}
	}
	int main()
	{
		freopen("villa.in","r",stdin);
		freopen("villa.out","w",stdout);
		scanf("%d%d",&n,&m);
		cin>>a;
		for(int i=0;i<n;i++)
		{
			sum[i+1]=sum[i]+(a[i]-'0');
		}
		init1();
		int x=1;
		for(int i=n-1;i>=0;i--)
		{
			sum[x]=sum[x-1]+(a[i]-'0');
		}
		init2();
		solve1();
		for(int i=1;i<=m;i++)
		{
			printf("%d ",ans1[i]-ans1[i-1]);
		}
		printf("\n");
		solve2();
		for(int i=1;i<=m;i++)
		{
			printf("%d ",ans2[i]-ans2[i-1]);
		}
		return 0;
	}
}
int main()
{
	return lzz::main();
}
