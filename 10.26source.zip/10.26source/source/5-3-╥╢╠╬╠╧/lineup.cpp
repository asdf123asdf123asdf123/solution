#include<bits/stdc++.h>
using namespace std;

namespace akak
{

	struct edge
	{
		int to,ne;
	}e[2010];
	int H[1010],fa[1010],T[1010];
	int cnt;
	void add(int a,int b)
	{
		e[++cnt].to=b;
		e[cnt].ne=H[a];
		H[a]=cnt;
	}
	int n,ans,mod=10007;
	void dfs(int u)
	{
		if(u>n)
		{
			ans++;
			ans%=mod;
			return ;
		}
		for(int i=1;i<=n;i++)
		{
			if(T[fa[i]]&&!T[i])
			{
				T[i]=1;
				dfs(u+1);
				T[i]=0;
			}
		}
	}
	int main()
	{
		int t;
		scanf("%d",&t);
		T[0]=1;
		while(t--)
		{
			scanf("%d",&n);
			cnt=ans=0;
			memset(H,0,sizeof(H));
			for(int i=1;i<=n;i++)
			{
				int ls=i,k;
				scanf("%d",&k);
				while(k--)
				{
					int a;
					scanf("%d",&a);
					add(a,ls);
					add(ls,a);
					fa[a]=ls;
					ls=a;
				}
			}
			dfs(1);
			cout<<ans<<'\n';
		}	
		return 0;
	}
}
int main()
{
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	akak::main();
	return 0;
} 
