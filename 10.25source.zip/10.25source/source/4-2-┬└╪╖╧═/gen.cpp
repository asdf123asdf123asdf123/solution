#include<bits/stdc++.h>
using namespace std;
namespace Main {
	random_device R;
	mt19937 G(R());
	int main() {
		cout << G() % 100 + 1 << '\n';
		return 0;
	}
}
int main() {
//	freopen(".in", "r", stdin);
	freopen("game.in", "w", stdout);
	Main :: main();
	return 0;
} 
