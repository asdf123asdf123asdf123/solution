#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int n;
	long long m,a[10001],f[10001][2],ans=0x3f3f3f3f3f3f3f3f;
	int nxt(int x){
		if(x==n) return 1;
		return x+1;
	}
	int pre(int x){
		if(x==1) return n;
		return x-1;
	}
	int main(){
		scanf("%d%lld",&n,&m);
		for(int i=1;i<=n;i++){
			scanf("%lld",&a[i]);
		}
		//0:�½�״̬
		//1:����״̬ 
		if(n<=1000){
			for(int t=1;t<=n;t++){
				f[t][0]=f[t][1]=0;
				for(int i=nxt(t),k=1;k<=n;i=nxt(i),k++){
					if(a[i]>a[pre(i)]){
						f[i][1]=min(f[pre(i)][1]+a[i]-a[pre(i)],f[pre(i)][0]+m+a[i]-a[pre(i)]);
						f[i][0]=min(f[pre(i)][0]+(a[i]-a[pre(i)])*(a[i]-a[pre(i)]),f[pre(i)][1]+m+(a[i]-a[pre(i)])*(a[i]-a[pre(i)]));
					}else{
						f[i][0]=min(f[pre(i)][0]+a[pre(i)]-a[i],f[pre(i)][1]+m+a[pre(i)]-a[i]);
						f[i][1]=min(f[pre(i)][1]+(a[pre(i)]-a[i])*(a[pre(i)]-a[i]),f[pre(i)][0]+m+(a[pre(i)]-a[i])*(a[pre(i)]-a[i]));
					}
				}
				ans=min(ans,min(f[t][0],f[t][1]));
			//	if(f[t][0]>=ans&&f[t][1]>=ans) continue;
			//	cout<<f[t][0]<<" "<<f[t][1]<<endl;
				f[t][0]=f[t][1]=0;
				for(int i=pre(t),k=1;k<=n;i=pre(i),k++){
					if(a[i]>a[nxt(i)]){
						f[i][1]=min(f[nxt(i)][1]+a[i]-a[nxt(i)],f[nxt(i)][0]+m+a[i]-a[nxt(i)]);
						f[i][0]=min(f[nxt(i)][0]+(a[i]-a[nxt(i)])*(a[i]-a[nxt(i)]),f[nxt(i)][1]+m+(a[i]-a[nxt(i)])*(a[i]-a[nxt(i)]));
					}else{
						f[i][0]=min(f[nxt(i)][0]+a[nxt(i)]-a[i],f[nxt(i)][1]+m+a[nxt(i)]-a[i]);
						f[i][1]=min(f[nxt(i)][1]+(a[nxt(i)]-a[i])*(a[nxt(i)]-a[i]),f[nxt(i)][0]+m+(a[nxt(i)]-a[i])*(a[nxt(i)]-a[i]));
					}
				}
				ans=min(ans,min(f[t][0],f[t][1]));
			//	cout<<f[t][0]<<" "<<f[t][1]<<endl<<endl;
			}
			printf("%lld",ans);
			return 0;
		}
		for(int t=1;t<=n;t++){
			f[t][0]=f[t][1]=0;
			for(int i=nxt(t),k=1;k<=n;i=nxt(i),k++){
				if(a[i]>a[pre(i)]){
					f[i][1]=min(f[pre(i)][1]+a[i]-a[pre(i)],f[pre(i)][0]+m+a[i]-a[pre(i)]);
					f[i][0]=min(f[pre(i)][0]+(a[i]-a[pre(i)])*(a[i]-a[pre(i)]),f[pre(i)][1]+m+(a[i]-a[pre(i)])*(a[i]-a[pre(i)]));
				}else{
					f[i][0]=min(f[pre(i)][0]+a[pre(i)]-a[i],f[pre(i)][1]+m+a[pre(i)]-a[i]);
					f[i][1]=min(f[pre(i)][1]+(a[pre(i)]-a[i])*(a[pre(i)]-a[i]),f[pre(i)][0]+m+(a[pre(i)]-a[i])*(a[pre(i)]-a[i]));
				}
			}
			if(f[t][0]>=ans&&f[t][1]>=ans) continue;
			ans=min(ans,min(f[t][0],f[t][1]));
		//	cout<<f[t][0]<<" "<<f[t][1]<<endl;
			f[t][0]=f[t][1]=0;
			for(int i=pre(t),k=1;k<=n;i=pre(i),k++){
				if(a[i]>a[nxt(i)]){
					f[i][1]=min(f[nxt(i)][1]+a[i]-a[nxt(i)],f[nxt(i)][0]+m+a[i]-a[nxt(i)]);
					f[i][0]=min(f[nxt(i)][0]+(a[i]-a[nxt(i)])*(a[i]-a[nxt(i)]),f[nxt(i)][1]+m+(a[i]-a[nxt(i)])*(a[i]-a[nxt(i)]));
				}else{
					f[i][0]=min(f[nxt(i)][0]+a[nxt(i)]-a[i],f[nxt(i)][1]+m+a[nxt(i)]-a[i]);
					f[i][1]=min(f[nxt(i)][1]+(a[nxt(i)]-a[i])*(a[nxt(i)]-a[i]),f[nxt(i)][0]+m+(a[nxt(i)]-a[i])*(a[nxt(i)]-a[i]));
				}
			}
			ans=min(ans,min(f[t][0],f[t][1]));
		//	cout<<f[t][0]<<" "<<f[t][1]<<endl<<endl;
		}
		printf("%lld",ans);
		return 0;
	}
}
int main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	ldm::main();
	return 0;
}
//1m 256m
