#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 100005;
	int n, m, p[MAXN], q[MAXN], a[MAXN], b[MAXN], aa[MAXN], bb[MAXN];
	bool flag1, flag2;
	void dfs(int now, int st, int mid){
		if(now == m + 1){
			if(st == n + 1){
				flag1 = 1;
			}
			return ;
		}
		for(int i = n - m + now;i >= st;i--){
			if(flag1) return ;
			if(abs(q[i] - q[st - 1]) <= mid){
				a[now] = i - st + 1;
				dfs(now + 1, i + 1, mid);
			} 
		}
	}
	void dfss(int now, int st, int mid){
		if(now == 0){
			if(st == 0){
				flag2 = 1;
			}
			return ;
		}
		for(int i = now;i <= st;i++){
			if(flag2) return ;
			if(abs(q[st] - q[i - 1]) <= mid){
				b[now] = st - i + 1;
				dfss(now - 1, i - 1, mid);
			} 
		}
	} 
	/*void dfsss(int now, int st, int mid){
		if(now == m + 1){
			if(st == n + 1) flag2 = 1;
			return ;
		}
		for(int i = st;i <= n - m + now;i++){
			if(flag2) return ;
			if(abs(q[i] - q[st - 1]) <= mid){
				b[now] = i - st + 1;
				dfsss(now + 1, i + 1, mid);
			}
		}
	}*/
	int main(){
		scanf("%d%d", &n, &m);
		for(int i = 1;i <= n;i++){
			scanf("%1d", &p[i]);
			if(!p[i]) p[i] = -1;
			q[i] = q[i - 1] + p[i];
		} 
		int l = 0, r = n;
		while(l <= r){
			//printf("%d %d\n", l, r);
			int mid = (l + r) >> 1;
			flag1 = 0;
			dfs(1, 1, mid);
			flag2 = 0;
			dfss(m, n, mid);
			//dfsss(1, 1, mid);
			if(flag1 && flag2){
				for(int i = 1;i <= m;i++) aa[i] = a[i];
				for(int i = 1;i <= m;i++) bb[i] = b[i];
				r = mid - 1;
			}
			else{
				l = mid + 1;
			}
		}
		for(int i = 1;i <= m;i++) printf("%d ", bb[i]);
		puts("");
		for(int i = 1;i <= m;i++) printf("%d ", aa[i]);//while(1);
		return 0;
	}
} 
int main(){
	freopen("villa.in", "r", stdin);
	freopen("villa.out", "w", stdout);
	return ac::main();
}//3MB
