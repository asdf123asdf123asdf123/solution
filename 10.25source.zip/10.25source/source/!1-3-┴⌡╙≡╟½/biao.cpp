#include <bits/stdc++.h>
using namespace std;
int f[5005];
bool check(int x){
	if(x<10)return 1;
	int last=x%10;
	x/=10;
	while(x){
		int now=x%10;
		x/=10;
		if(abs(now-last)<=1)return 0;
		last=now;
	}
	return 1;
}
int ans;
int main(){
	freopen("biao.in","r",stdin);
	freopen("biao.out","w",stdout);
	for(int i=1;i<=2000000000;i++){
		if(check(i)){
			f[(i+399999)/400000]++;
			ans++;
		}
	}
	for(int i=1;i<=5000;i++){
		cout<<f[i]<<',';
	}
	cout<<'\n';
	cerr<<ans;
}
/*
127322182
*/ 
