#include <iostream>
#include <cstdio>
using namespace std;
namespace zzy{
	const int maxn=1e4+10;
	int a[maxn];
	int now[2][maxn];
	int vis[maxn];
	int tmp[maxn];
	int n;
	int ans=0;
	void dfs(int x){
		if(x>n){
			int f=0;
			int pre=0;
			for(int i=1;i<=n;i++)now[0][i]=i;
			int cnt=1;	
			while(!f){
				cnt++;
				f=1;
				for(int i=1;i<=n;i++){
					now[pre^1][i]=a[now[pre][i]];
					if(now[pre^1][i]!=i)f=0;
				}
				pre^=1;
			}
			if(!tmp[cnt])ans++;
			tmp[cnt]=1;
			return ;
		}
		for(int i=1;i<=n;i++){
			if(!vis[i]){
				vis[i]=1;
				a[x]=i;
				dfs(x+1);
				vis[i]=0;
			}
		}
	}
	int main(){
		freopen("game.in","r",stdin);
		freopen("game.out","w",stdout);
		scanf("%d",&n);
		dfs(1);
		cout<<ans;

		return 0;
	}
}
int main(){
	zzy::main();
	return 0;
}
//832 KB
