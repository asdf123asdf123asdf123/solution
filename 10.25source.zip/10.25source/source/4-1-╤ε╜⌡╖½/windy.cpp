#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
using namespace std;
namespace yjf{
	const int N=20;
	int x[N],len,ans;
	int f[N][N];
	int tmp1,tmp2;
	bool check(int x,int y){
		if(x-y>=2 || x-y<=-2) return true;
		else return false;
	}
	int solve(int a){
		if(a==0) return 0;	
		
		ans=0,len=0;
		int tmp=a;
		while(tmp){
			x[++len]=tmp%10;
			tmp/=10;
		}
		bool flag=true;
		x[len+1]=11;
		for(int i=len;i>=1;i--){
			if(flag==true){
				if(i!=len){
					for(int j=0;j<x[i];j++){
						if(check(x[i+1],j)){
							ans+=f[i][j];
						}
					}
				}
				else{
					for(int j=1;j<x[i];j++){
						if(check(x[i+1],j)){
							ans+=f[i][j];
						}
					}
					for(int i=len-1;i>=1;i--){ //0���� 
						for(int j=1;j<=9;j++){
							ans+=f[i][j];
						}
					}
				}
			}
			flag&=check(x[i+1],x[i]);
		}
		if(flag){
			ans++;
		}
		return ans;
	}
	int main(){
		int a,b;
		scanf("%d%d",&a,&b);
		f[0][11]=true;
		for(int i=1;i<=10;i++){
			for(int j=0;j<=9;j++){
				for(int k=0;k<=11;k++){
					if(check(j,k)){
						f[i][j]+=f[i-1][k];
					}
				}
				//cout<<f[i][j]<<" ";
			}
			//cout<<endl;
		}
		printf("%d\n",solve(b)-solve(a-1));
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	return yjf::main();
}
