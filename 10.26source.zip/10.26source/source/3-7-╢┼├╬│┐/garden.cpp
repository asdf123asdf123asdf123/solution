#include<bits/stdc++.h>
using namespace std;
const int maxn=1e3+5;
int n,m;
int a[maxn];
int ex,ey,tx,ty;
int main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
	}
	sort(a+1,a+n+1);
	scanf("%d",&m);
	for(int i=1;i<=m;++i){
		scanf("%d%d%d%d",&ex,&ey,&tx,&ty);
		if((ex>0&&tx>0)||ex<0&&tx<0){
			cout<<abs(ex-tx)+abs(ey-ty);
		}
		else{
			int l=1,r=n,ans=2147483648-1;
			bool cnt=false;
			while(l<=r){
				int mid=(l+r)>>1;
				if((ey<=a[mid]&&a[mid]<=ty)||(ty<=a[mid]&&a[mid]<=ey)){
					cnt=true;
					break;
				}
				if(ans>min(abs(a[mid]-ey),abs(a[mid]-ty))*2){
					ans=min(abs(a[mid]-ey),abs(a[mid]-ty))*2;
					if(ey<=a[mid]&&ty<=a[mid])r=mid;
					else{
						l=mid+1;
					}
				}
				else{
					if(ey<=a[mid]&&ty<=a[mid]){
						r=mid-1;
					}
					else{
						l=mid+1;
					}
				}
			}
			if(cnt==true){
				cout<<abs(ex-tx)+abs(ey-ty)<<'\n';
			}
			else{
				cout<<abs(ex-tx)+abs(ey-ty)+ans<<'\n';
				//  cout<<"ans="<<ans<<'\n';
			}
		}
	}
	return 0;
}
