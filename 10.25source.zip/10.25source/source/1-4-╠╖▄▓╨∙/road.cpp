#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define N 15
	#define T 10000005
	#define MP(i,j) (node){i,j}
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int n,t,dis[N][N];
	char ch[N];
	int f[N][T];
	signed main(){
		n=read(),t=read();
//		t--;
		for(int i=1;i<=n;i++){
			scanf("%s",ch+1);
			for(int j=1;j<=n;j++) dis[i][j]=ch[j]-'0';
		}
		f[1][0]=1;
		for(int i=1;i<=t;i++){
			for(int j=1;j<=n;j++){
				for(int k=1;k<=n;k++){
					if(dis[k][j]!=0&&i-dis[k][j]>=0) f[j][i]=(f[j][i]+f[k][i-dis[k][j]])%2009;
				}
			}
		}
//		for(int i=0;i<2009;i++){
//			for(int j=i;j<=t;j+=2009){
//				cout<<"j : "<<j<<'\n';
//				for(int l=1;l<=n;l++) cout<<f[l][j]<<' ';
//				putchar(10);
//			}
//			putchar(10);
//		}
		printf("%d",f[n][t]);
		return 0;
	}
}
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	TYX_YNXK::main();
	return 0;
}
