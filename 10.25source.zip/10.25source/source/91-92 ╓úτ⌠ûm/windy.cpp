#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

namespace Wyy{
	int ln=0,rn=0;
	int ch[14],chl[14],chr[14];
	ll L,R,Ans=0;
	ll f[14][14];
	inline bool check(ll num){
		ch[0]=0;
		while(num){
			ch[++ch[0]]=num%10;
			num/=10;
		}
		for(register int i=2;i<=ch[0];++i){
			if(abs(ch[i]-ch[i-1])<2)return false;
		}
		return true;
	}
	signed main(){//100S
		scanf("%lld%lld",&L,&R);
		if(R<=10000000ll){//20S
			for(register int i=L;i<=R;++i){
				if(check(i))++Ans;
			}
			printf("%lld\n",Ans);
			return 0;
		}
		ll tmp=R;
		while(tmp){
			chr[++rn]=tmp%10;
			tmp/=10;
		}
		tmp=L;
		while(tmp){
			chl[++ln]=tmp%10; 
			tmp/=10;
		}
		for(register int i=0;i<=9;++i)f[1][i]=1;
		for(register int i=2;i<=rn;++i){
			for(register int j=0;j<=9;++j){
				f[i][j]=0;
				for(register int k=0;k<=9;++k){
					if(abs(j-k)<2)continue;
					f[i][j]+=f[i-1][k];
				}
			}
		}
		ll Ans=0;
		// ���м� 
		for(register int i=ln+1;i<rn;++i)
			for(register int j=1;j<=9;++j)
				Ans+=f[i][j];
//		cout<<Ans<<endl;
		if(ln!=rn){
			//�� L ��
			for(register int i=ln;i>=1;--i){
				for(register int j=chl[i]+1;j<=9;++j){
					if(ln>i&&abs(chl[i+1]-j)<2)continue;
					Ans+=f[i][j];
				}
				if(ln>i&&abs(chl[i+1]-chl[i])<2)break;
			}
			if(check(L)){++Ans;}
//			cout<<Ans-3341<<endl;
			//�� R С 
			for(register int i=rn;i>=1;--i){
				for(register int j=0;j<chr[i];++j){
					if(!j&&i==rn)continue;
					if(rn>i&&abs(chr[i+1]-j)<2)continue;
					Ans+=f[i][j];
				}
				if(rn>i&&abs(chr[i+1]-chr[i])<2)break;
			}
			if(check(R)){++Ans;}
//			cout<<Ans-3341-463<<endl;
		}else{
			if(check(L)){++Ans;}
			if(check(R)&&L!=R){++Ans;}
			for(register int s=rn;s>=1;--s){
				for(register int j=chl[s]+1;j<chr[s];++j){
					Ans+=f[s][j];
					//cout<<s<<" "<<j<<" "<<f[s][j]<<endl; 
				}
				if(chl[s]!=chr[s]){
					for(register int i=s-1;i>=1;--i){
						for(register int j=0;j<chr[i];++j){
							if(!j&&i==rn)continue;
							if(rn>i&&abs(chr[i+1]-j)<2)continue;
							Ans+=f[i][j];
						}
						if(rn>i&&abs(chr[i+1]-chr[i])<2)break;
					}
					for(register int i=s-1;i>=1;--i){
						for(register int j=chl[i]+1;j<=9;++j){
							if(ln>i&&abs(chl[i+1]-j)<2)continue;
							Ans+=f[i][j];
						}
						if(ln>i&&abs(chl[i+1]-chl[i])<2)break;
					}
					break;
				}
				if(rn>s&&abs(chr[s+1]-chr[s])<2)break;
				if(ln>s&&abs(chl[s+1]-chl[s])<2)break;
			}
		}
		printf("%lld\n",Ans);
		
		return 0;
	}
}
signed main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	Wyy::main();
	return 0;
}

