#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int mod=1e9+7; 
	
	int n,d;
	int c[405][305];
	
	void get_c(){
		c[0][0]=1;
		for(int i=1;i<=402;i++){
			c[i][0]=1;
			for(int j=1;j<=302;j++)
				c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;		
		}
			
	}
	
	int arr[405];
	int tong[405];
	int ans;
	
	int check(int now){
		memset(tong,0,sizeof(tong));
		for(int i=1;i<=now;i++){
			tong[arr[i]]++;	
			if(tong[arr[i]]>n)return 0;
		}
		return 1;		
	}
	void dfs(int now){
		if(now==2*n+1){
			memset(tong,0,sizeof(tong));
			for(int i=1;i<=now;i++)	
				tong[arr[i]]++;
			
			int bj=1;
			for(int i=1;i<=d;i++)
				if(tong[i]!=tong[i+d])bj=0;
			if(bj)ans++;
			
			return ;
		}
		if(!check(now-1))return;
		for(int i=1;i<=2*d;i++){
			arr[now]=i;
			dfs(now+1);
		}
	}
	int main(){
		freopen("shiawase.in","r",stdin);
		freopen("shiawase.out","w",stdout);		
		
		get_c();
				
		scanf("%d%d",&d,&n);
		if(!n){
			cout<<1;return 0;
		}
		if(d==1){
			cout<<c[2*n][n]%mod<<'\n';
			return 0;		
		}
		if(d==2){
			long long ans=0;
			ans=(ans+c[2*n][n]*2%mod)%mod;
			
			long long tmp=0;
			for(int k=1;k<=n-1;k++){
				tmp=(tmp+c[n][k]*c[n][k])%mod;
			}
			ans=(ans+c[2*n][n]*tmp%mod)%mod;
			cout<<ans%mod<<'\n';
			
			return 0;
		}
		
		dfs(1);
		cout<<ans<<'\n';
		
		
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}

//  4*4*(c4,2)
