#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 35, inf = 0x7fffffff / 2;
	int n, m, T;
	int f[MAXN][MAXN], a[MAXN][MAXN];
	int did[MAXN][MAXN], vis[MAXN][MAXN];
	int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
	double ans;
	struct node{
		int x, y, dis;
	};
	bool operator < (node a, node b){
		return a.dis > b.dis;
	}
	priority_queue<node> q;
	void dijkstra(int x, int y){
		for(int i = 1;i <= n;i++){
			for(int j = 1;j <= m;j++){
				did[i][j] = inf;
				vis[i][j] = 0;
			}
		}
		did[x][y] = a[x][y];
		q.push((node){x, y, a[x][y]});
		while(q.size()){
			node tmp = q.top();
			q.pop();
			int x = tmp.x, y = tmp.y;
			if(vis[x][y]) continue;
			vis[x][y] = 1;
			for(int i = 0;i < 4;i++){
				int tx = x + dx[i];
				int ty = y + dy[i];
				if(tx < 1 || tx > n || ty < 1 || ty > m) continue;
				if(did[tx][ty] > did[x][y] + a[tx][ty]){
					did[tx][ty] = did[x][y] + a[tx][ty];
					q.push((node){tx, ty, did[tx][ty]});
				}
			}
		}
	}
	int main(){
		scanf("%d%d%d", &n, &m, &T);
		for(int i = 1;i <= n;i++){
			for(int j = 1;j <= m;j++){
				scanf("%1d", &a[i][j]);
			}
		}
		for(int i = 1;i <= n;i++){
			for(int j = 1;j <= m;j++){
				dijkstra(i, j);
				for(int x = 1;x <= n;x++){
					for(int y = 1;y <= m;y++){
						if(did[x][y] <= T){
							ans = max(ans, sqrt((x - i) * (x - i) + (y - j) * (y - j)));
						}
					}
				}
			} 
		} 
		printf("%.6lf", ans);//while(1);
		return 0;
	}
} 
int main(){
	freopen("maxlength.in", "r", stdin);
	freopen("maxlength.out", "w", stdout);
	return ac::main();
}//684KB
