#include<cstdio>
#include<iostream>
using namespace std;
namespace Hualong_Li{
	const int N = 1e3, Cnt = 200;
	int isprime[N + 10], prime[Cnt + 10], cnt;
	long long f[N + 10], ans;
	int n;
	int main(){
		scanf("%d", &n);
		for(int i = 2; i <= n; i++){
			if(!isprime[i]){
				prime[++cnt] = i;
				for(int j = i * 2; j <= n; j += i)
					isprime[j] = 1;
			}
		}
		f[0] = 1;
		for(int i = 1; i <= cnt; i++)
			for(int j = n; j >= 0; j--)
				for(int k = prime[i]; k <= j; k *= prime[i])
					f[j] += f[j - k];
		for(int i = 0; i <= n; i++)
			ans += f[i];
		printf("%lld", ans);
		return 0;
	}
}
int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	return Hualong_Li::main();
}
//1MB
