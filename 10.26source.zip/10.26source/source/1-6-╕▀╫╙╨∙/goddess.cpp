#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
const long long INF=1e18;
int n,m;
long long f[10005][2],a[20005],b[20005];//0���� 1�½� 
long long solve()
{
	f[1][0]=f[1][1]=0;
	for(int i=2;i<=n;i++)
	{
		if(b[i]>b[i-1])
		{
			long long val=b[i]-b[i-1];
			f[i][0]=min(f[i][0],f[i-1][0]+val);
			f[i][0]=min(f[i][0],f[i-1][1]+val+m);
			f[i][1]=min(f[i][1],f[i-1][1]+val*val);
			f[i][1]=min(f[i][1],f[i-1][0]+val+m);
			
		}
		else
		{
			long long val=b[i-1]-b[i];
			f[i][1]=min(f[i][1],f[i-1][1]+val);
			f[i][1]=min(f[i][1],f[i-1][0]+val+m);
			f[i][0]=min(f[i][0],f[i-1][0]+val*val);
			f[i][0]=min(f[i][0],f[i-1][1]+val+m);
		}
	}
	long long ans=INF;
	if(b[n]<b[1])
	{
		long long val=b[1]-b[n];
		ans=min(ans,f[n][0]+val);
		ans=min(ans,f[n][1]+val+m);
		ans=min(ans,f[n][1]+val*val);
		ans=min(ans,f[n][0]+val+m);
	}
	else
	{
		long long val=b[n]-b[1];
		ans=min(ans,f[n][1]+val);
		ans=min(ans,f[n][0]+val+m);
		ans=min(ans,f[n][0]+val*val);
		ans=min(ans,f[n][1]+val+m);
	}
	return ans;
}
long long ans=INF;
int main()
{
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		a[i+n]=a[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<n+i;j++)
		{
			b[j-i+1]=a[j];
			f[j-i+1][0]=f[j-i+1][1]=INF;
		}
//		for(int i=1;i<=n;i++)cout<<b[i]<<' ';
//		cout<<'\n';
//		
//		cout<<solve()<<'\n';
		ans=min(ans,solve());
//		if(i==3)
//		{
//			for(int j=1;j<=n;j++)
//			{
//				cout<<f[j][0]<<' '<<f[j][1]<<'\n';
//			}
//			break;
//		}
	}
//	cout<<'\n';
	for(int i=1;i<=n;i++)
	{
		int pos=i;
		for(int j=1;j<=n;j++)
		{
			b[j]=a[pos];
			f[j][0]=f[j][1]=INF;
			pos--;
			if(pos==0)pos=n;
		}
//		for(int j=1;j<=n;j++)cout<<b[j]<<' ';
//		cout<<'\n';
//		cout<<solve()<<'\n';
		ans=min(ans,solve());
	}
	cout<<ans;
//	while(1);
	return 0;
}
}
int main(){gzx::main();return 0;}
//1184kb
