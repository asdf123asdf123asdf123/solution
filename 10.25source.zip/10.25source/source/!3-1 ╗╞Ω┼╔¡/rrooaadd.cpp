#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	string s[13];
	int f[1003][13];
	int main(){
		int n,t;
		scanf("%d%d",&n,&t);
		for(int i=1;i<=n;i++){
			cin>>s[i];
			s[i]=" "+s[i];
		}
		f[0][1]=1;
		for(int i=1;i<=t;i++)
			for(int j=1;j<=n;j++)
				for(int k=1;k<=n;k++)
					if(s[k][j]!='0'&&i>=s[k][j]-'0'){
						f[i][j]+=f[i-s[k][j]+'0'][k];
						f[i][j]%=2009;
					}
		printf("%d",f[t][n]);
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("roading.out","w",stdout);
	estidi::main();
	return 0;
}
