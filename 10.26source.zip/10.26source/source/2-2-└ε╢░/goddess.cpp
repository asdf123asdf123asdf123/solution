#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n,M;
	long long a[20050];
	long long f[20050][2];
	int order[20050];
	
	bool cmp(int x,int y){
		return rand()%2;
	}
	int main(){
		freopen("goddess.in","r",stdin);
		freopen("goddess.out","w",stdout);		
		srand(time(NULL));	
		scanf("%d%d",&n,&M);
		for(int i=1;i<=n;i++){
			scanf("%lld",a+i);
			a[i+n]=a[i];
			order[i]=i;
		}
		sort(order+1,order+1+n,cmp);	
		long long ans=1e18;	
		for(int k=1;k<=min(n,1500);k++){
			int st=order[k];
			for(int i=1;i<=2*n;i++)
				f[i][0]=f[i][1]=1e18;
				
			f[st][0]=f[st][1]=0;
			for(int i=st+1;i<=st+n;i++){
				if(a[i]>a[i-1]){
					f[i][0]=min(f[i][0], f[i-1][0]+abs(a[i]-a[i-1]));
					f[i][0]=min(f[i][0], f[i-1][1]+(a[i]-a[i-1])*(a[i]-a[i-1])+M);
	
					f[i][1]=min(f[i][1], f[i-1][1]+(a[i]-a[i-1])*(a[i]-a[i-1]));
					f[i][1]=min(f[i][1], f[i-1][0]+abs(a[i]-a[i-1])+M);
				}
				else {
					f[i][0]=min(f[i][0], f[i-1][0]+(a[i]-a[i-1])*(a[i]-a[i-1]));
					f[i][0]=min(f[i][0], f[i-1][1]+abs(a[i]-a[i-1])+M);
	
					f[i][1]=min(f[i][1], f[i-1][1]+abs(a[i]-a[i-1]));
					f[i][1]=min(f[i][1], f[i-1][0]+(a[i]-a[i-1])*(a[i]-a[i-1])+M);					
				}
			}		
			ans=min(ans, min(f[st+n][0],f[st+n][1]));
		}
		cout<<ans<<'\n';	
		
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}
