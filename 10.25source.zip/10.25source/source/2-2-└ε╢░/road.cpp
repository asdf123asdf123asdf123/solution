#include<bits/stdc++.h>
using namespace std;
namespace ld{
	const int mod=2009;
	int n,T;	
	struct edge{
		int next;
		int to;
		int w;
	}ed[205];int ed_cnt;
	int h[15];
	void add_edge(int x,int y,int w){
		ed[++ed_cnt]={h[x],y,w};
		h[x]=ed_cnt;
	}
	
	int g[15][3000005];		
	int main(){
		freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);		
		
		scanf("%d%d",&n,&T);
		getchar();
		for(int i=1;i<=n;i++,getchar())
			for(int j=1;j<=n;j++){
				int now=getchar()-'0';
				if(!now)continue;
				add_edge(j,i,now);
			}
		
		g[1][0]=1;
		
		for(int t=1;t<=T;t++)
			for(int u=1;u<=n;u++){
				for(int i=h[u];i;i=ed[i].next){
					int v=ed[i].to;
					int w=ed[i].w;
					g[u][t]=(g[u][t]+g[v][t-w])%mod;
				}
			}
		cout<<g[n][T]<<'\n';
		return 0;
	}
}
int main(){
	ld::main();
	return 0;
}
