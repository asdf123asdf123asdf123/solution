#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	long long a,b,ans,aa,f[15][15];
	int la[15],lb[15],lz,rz;
	bool pd(int x){
		int s=-1;
		while(x){
			int k=x%10;
			if(s!=-1){
				if(abs(s-k)<2) return false;
			}
			s=k;
			x/=10;
		}
		return true;
	}
	int main(){
		scanf("%lld%lld",&a,&b);
		memset(la,-1,sizeof(la));
		memset(lb,-1,sizeof(lb));
		la[0]=lb[0]=0;
		if(b<=1000000){
			for(int i=a;i<=b;i++){
				if(pd(i)){
					ans++;
		//			cout<<i<<endl;
				}
			}
			printf("%lld",ans);
			return 0;
		}
		aa=a;
		while(aa){
			la[++la[0]]=aa%10;
			lz=aa%10;
			aa/=10;
		}
		aa=b;
		while(aa){
			lb[++lb[0]]=aa%10;
			rz=aa%10;
			aa/=10;
		}
//		for(int i=1;i<=la[0]/2;i++){
//			swap(la[i],la[la[0]-i+1]);
//		}
//		for(int i=1;i<=lb[0]/2;i++){
//			swap(lb[i],lb[lb[0]-i+1]);
//		}
		for(int i=0;i<=9;i++){
			f[i][1]=1;
		}
		//f[i][j]:��i��ͷ����Ϊj�����ж���Windy�� 
		for(int i=2;i<=10;i++){
			for(int j=0;j<=9;j++){
				for(int k=0;k<=j-2;k++){
					f[j][i]+=f[k][i-1];
				}
				for(int k=j+2;k<=9;k++){
					f[j][i]+=f[k][i-1];
				}
			}
		}
//		for(int i=0;i<=9;i++){
//			cout<<i<<":"<<endl;
//			for(int j=1;j<=10;j++){
//				cout<<f[i][j]<<endl;
//			}
//			cout<<endl;
//		}
		//ֻ��¼a�����λ��b�����λ
		long long x=a;
		b++;
		while(x<b){
		//	cout<<x<<endl;
		//	if(x+1>b) break;
			long long xx=x,k=0,w,jl=1,sum=0;
			while(xx){
				if(xx%10!=0){
					jl=xx%10;
					break;
				}
				k++;
				xx/=10;
			}
			xx=x;
			while(xx){
//				if(xx%10!=0){
//					break;
//				}
				sum++;
				xx/=10;
			}
			w=pow(10,k);
			while(x+w>b){
				w/=10;
				k--;
			}
		//	cout<<x<<" "<<k<<" "<<w<<" "<<jl<<" "<<f[jl][k+1]<<endl; 
			if(sum+1==la[0]){
				if(abs(jl-lz)>=2){
					ans+=f[jl][k+1];
				}
			}else if(sum+1==lb[0]){
				if(abs(jl-rz)>=2){
					ans+=f[jl][k+1];
				}
			}else{
				ans+=f[jl][k+1];
			}
//			if(sum!=la[0]&&sum!=lb[0]){
//				ans+=f[jl][k+1];
//			}else if(sum==la[0]){
//				if(abs(jl-la[k+1])>=2){
//					ans+=f[jl][k+1];
//				}else if(la[k+2]==-1){
//					ans+=f[jl][k+1];
//				}
//			}else if(sum==lb[0]&&sum!=la[0]){
//				if(abs(jl-lb[k+1])>=2){
//					ans+=f[jl][k+1];
//				}else if(lb[k+2]==-1){
//					ans+=f[jl][k+1];
//				}
//			}
			x+=w;
		}
		printf("%lld",ans);
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	ldm::main();
	return 0;
}
//5 168
//96
//5+7*8+8+7*3+6

//51 1348
//513
//51-99  6+7*3+8=35
//100-999 50+51*6+50+57=463
//1000-1348=15
