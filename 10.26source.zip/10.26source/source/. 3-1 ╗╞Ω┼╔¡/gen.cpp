#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	int main(){
		srand(time(0));
		int n=10000,m=(long long)rand()*rand()*rand()%1000000000+1;
		cout<<n<<" "<<m<<endl;
		for(int i=1;i<=n;i++)
			cout<<(long long)rand()*rand()*rand()%1000000+1<<" ";
		return 0;
	}
}
int main(){
	freopen("goddess.in","w",stdout);
	estidi::main();
	return 0;
}
