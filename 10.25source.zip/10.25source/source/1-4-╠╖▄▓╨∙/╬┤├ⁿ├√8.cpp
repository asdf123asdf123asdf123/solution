#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int a,b;
	signed main(){
		srand((unsigned long long)time(NULL));
		a=1ull*(((rand()*100000+rand())*100000+rand())*100000+rand())%2000000000+1;
		b=1ull*(((rand()*100000+rand())*100000+rand())*100000+rand())%2000000000+1;
		if(a>b) swap(a,b);
		printf("%d %d",a,b);
		return 0;
	}
}
signed main(){
//	freopen("windy.in","r",stdin);
	freopen("windy1.in","w",stdout);
	TYX_YNXK::main();
	return 0;
}
