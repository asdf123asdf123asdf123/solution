#include<bits/stdc++.h>
using namespace std;
namespace AFO{
	const int maxn=35,maxT=35;
	int n,m,t;
	int a[maxn][maxn];
	int Tx[4]={0,0,1,-1};
	int Ty[4]={1,-1,0,0};
	bool Vst[maxn][maxn];
	queue<pair<int,int> > q;
	void Bfs(int x,int y){
		memset(Vst,0,sizeof(Vst));
		q.push(make_pair(x,y));
		Vst[x][y]=1;
		while(!q.empty()){
			pair<int,int>u=q.front();
			q.pop();
			for(int i=0;i<4;i++){
				int xt=u.first+Tx[i],yt=u.second+Ty[i];
				if(xt<1||xt>n||yt<1||yt>m)continue;
				if(a[xt][yt])continue;
				if(Vst[xt][yt])continue;
				Vst[xt][yt]=1;
				q.push(make_pair(xt,yt));
			}
		}
	}
	double Work(){
		double ans=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++){
				if(a[i][j])continue;
				Bfs(i,j);
				for(int x=1;x<=n;x++)
					for(int y=1;y<=m;y++)
						if(Vst[x][y])
							ans=max(ans,sqrt(abs(x-i)*abs(x-i) + abs(y-j)*abs(y-j)));
			}
		return ans;
	}
	bool vst[maxn][maxn][maxT];
	struct pri{int x,y,t;};
	queue<pri>Q;
	double maxx;
	void BFS(int X,int Y){
		memset(vst,0,sizeof(vst));
		while(!Q.empty())Q.pop();
		if(a[X][Y])Q.push({X,Y,t-1});
		else Q.push({X,Y,t});
		while(!Q.empty()){
			pri now=Q.front();
			Q.pop();
			for(int i=0;i<4;i++){
				int xt=now.x+Tx[i],yt=now.y+Ty[i];
				if(xt<1||xt>n||yt<1||yt>m)continue;
				if(a[xt][yt]){
					if(now.t>0&&!vst[xt][yt][now.t-1]){
						vst[xt][yt][now.t-1]=1;
						Q.push({xt,yt,now.t-1});
						maxx=max(maxx,sqrt(abs(xt-X)*abs(xt-X)+(yt-Y)*(yt-Y)));
					}
				}else{
					if(!vst[xt][yt][now.t]){
						vst[xt][yt][now.t]=1;
						Q.push({xt,yt,now.t});
						maxx=max(maxx,sqrt(abs(xt-X)*abs(xt-X)+(yt-Y)*(yt-Y)));
					}
				}
			}
		}
	}
	int main(){
		scanf("%d%d%d",&n,&m,&t);
		char c;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++){
				cin>>c;
				a[i][j]=c-'0';
			}
		if(t==0){
			printf("%.6lf",Work());
		}else{
			for(int i=1;i<=n;i++)
				for(int j=1;j<=m;j++){
					BFS(i,j);
				}
			printf("%.6lf",maxx);
		}
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
//	double S=clock(); 
	AFO::main();
//	double T=clock();
//	cerr<<'\n'<<T-S;
	return 0;
}

