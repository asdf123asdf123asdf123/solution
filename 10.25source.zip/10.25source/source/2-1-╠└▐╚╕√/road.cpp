#include<cstdio>
#include<iostream>
using namespace std;
namespace Hualong_Li{
	const int N = 10, mod = 2009;
	struct edge{
		int nxt, to, val;
	} e[N * N + 10];
	int head[N + 10], cnt;
	int n, T, ans;
	inline void add(int u, int v, int w){
		e[++cnt] = {head[u], v, w};
		head[u] = cnt;
	}
	void dfs(int u, int time){
		if(time > T)
			return;
		if(u == n && time == T)
			ans = (ans + 1) % mod;
		for(int i = head[u]; i; i = e[i].nxt)
			dfs(e[i].to, time + e[i].val);
	}
	int main(){
		scanf("%d%d", &n, &T);
		for(int i = 1; i <= n; i++){
			for(int j = 1, k; j <= n; j++){
				scanf("%1d", &k);
				if(k)
					add(i, j, k);
			}
		}
		dfs(1, 0);
		printf("%d", ans);
		return 0;
	}
}
int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	return Hualong_Li::main();
}
