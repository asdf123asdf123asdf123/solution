#include <bits/stdc++.h>
#define int long long

using namespace std;

namespace rsy{
	
	const int N = 100010;
	
	int n, m, a[N];
	int x1, y1, x2, y2;
	
	int zf(int x) {
		if (x > 0) return 1;
		if (x == 0) return 0;
		if (x < 0) return -1;
	}
	int check(int x) {
		return abs(x1 - x) + abs(x2 - x) + abs(y1) + abs(y2);
	}
	
	void solve() {
		cin >> n;
		for (int i = 1; i <= n; i++) cin >> a[i];
		sort (a + 1, a + 1 + n);
		cin >> m;
		while (m -- ) {
			cin >> x1 >> y1 >> x2 >> y2;
			if (zf(y1) * zf(y2) == 1) {
				cout << abs(x1 - x2) + abs(y1 - y2) << '\n';
			} else {
				if (zf(y1) == 1) swap(y1, y2), swap(x1, x2);
				int l = 1, r = n;
				while (l < r - 2) {
					int mid1 = l + (r - l) / 3;
					int mid2 = r - (r - l) / 3;
					if (check(a[mid1]) < check(a[mid2])) r = mid2;
					else l = mid1;
				}
				int res = LLONG_MAX;
				for (int i = max(1ll, l - 3ll); i <= min(n, l + 3ll); i++)
					res = min(res, check(a[i]));
				cout << res << '\n';
			}
		}
	}
	
	signed main(){
		ios::sync_with_stdio(false);
		cin.tie(0); 
		int T = 1;
		while (T -- ) solve(); 
		return 0;
	}
}

signed main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	return rsy::main();
}
