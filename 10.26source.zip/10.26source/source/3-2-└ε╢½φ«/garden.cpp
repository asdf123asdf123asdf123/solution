#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int n,m,a[100001];
	int main(){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		scanf("%d",&m);
		sort(a+1,a+1+n);
		while(m--){
			int x,y,i,j;
			scanf("%d%d%d%d",&x,&y,&i,&j);
			if((y>=0&&j>=0)||(y<0&&j<0)){
				printf("%d\n",abs(x-i)+abs(y-j));
			}else{
				int x1=a[lower_bound(a+1,a+1+n,x)-a-1],x2=a[lower_bound(a+1,a+1+n,x)-a];
				int v1,v2;
				v1=v2=abs(y)+abs(j);
				v1+=abs(x1-x)+abs(x1-i);
				v2+=abs(x2-x)+abs(x2-i);
				printf("%d\n",min(v1,v2));
			}
		}
		return 0;
	}
}
int main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	ldm::main();
	return 0;
}
//1m 256m
