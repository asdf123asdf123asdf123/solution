#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const int INf=1e9+7;

namespace NoFive{
	
	signed main(){
		cout<<"5000000 100000\n";
		for(register int i=1;i<=5000000;++i){
			cout<<rand()%2; 
		}
		
		return 0;
	}
}
signed main(){
//	freopen(".in","r",stdin);
	freopen("villa114.in","w",stdout);
	NoFive::main();
	return 0;
}

