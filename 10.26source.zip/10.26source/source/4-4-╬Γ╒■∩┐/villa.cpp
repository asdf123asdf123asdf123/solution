#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int n,m;
	char s[5100000];
	int sum[5100000];
	int getnum(int l,int r){
		return sum[r]-sum[l-1];
	}
	int getcha(int l,int r){
		return abs(r-l+1-getnum(l,r)-getnum(l,r));
	}
	int f[1200][1200]/*,minn*/;
	vector<int>vec[470][470];
	int minans[1200],maxans[1200];
	int now[1200];
	void checkmin(){
		for(int i=1;i<=m;i++){
			if(now[i]>minans[i]){
				return;
			}
			if(now[i]<minans[i]){
				break;
			}
		}
		for(int i=1;i<=m;i++){
			minans[i]=now[i];
		}
	}
	void dfsmin(int u,int v,int dep){
		if(dep<0){
			return;
		}
		bool bj=0;
		for(int i=0;i<vec[u][v].size();i++){
			now[dep]=u-vec[u][v][i];
			if(vec[u][v][i]){
				bj=1;
				dfsmin(vec[u][v][i],v-1,dep-1);
			}
		}
		if(bj==0){
			checkmin();
			return;
		}
	}
	void checkmax(){
		for(int i=1;i<=m;i++){
			if(now[i]<maxans[i]){
				return;
			}
			if(now[i]>maxans[i]){
				break;
			}
		}
		for(int i=1;i<=m;i++){
			maxans[i]=now[i];
		}
	}
	void dfsmax(int u,int v,int dep){
		if(dep<0){
			return;
		}
		bool bj=0;
		for(int i=0;i<vec[u][v].size();i++){
			now[dep]=u-vec[u][v][i];
			if(vec[u][v][i]){
				bj=1;
				dfsmax(vec[u][v][i],v-1,dep-1);
			}
		}
		if(bj==0){
			checkmax();
			return;
		}
	}
	int main(){
		freopen("villa.in","r",stdin);
		freopen("villa.out","w",stdout);
		scanf("%d%d",&n,&m);
		scanf("%s",s+1);
		for(int i=1;i<=n;i++){
			sum[i]=sum[i-1];
			if(s[i]=='1'){
				sum[i]++;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				f[i][j]=1e9;
			}
		}
		for(int i=1;i<=n;i++){
			f[i][1]=getcha(1,i);
			vec[i][1].push_back(0);
//			cout<<f[i][1]<<'\n';
		}
		for(int i=1;i<=n;i++){
			for(int j=2;j<=min(i,m);j++){
				for(int k=1;k<i;k++){
					if(max(f[k][j-1],getcha(k+1,i))<f[i][j]){
						vec[i][j].clear();
						vec[i][j].push_back(k);
					}else if(max(f[k][j-1],getcha(k+1,i))==f[i][j]){
						vec[i][j].push_back(k);
					}
					f[i][j]=min(f[i][j],max(f[k][j-1],getcha(k+1,i)));
				}
			}
		}
//		for(int i=1;i<=n;i++){
//			for(int j=1;j<=m;j++){
//				cout<<f[i][j]<<' ';
//			}
//			cout<<'\n';
//		}
//		cout<<f[n][m]<<'\n';
//		minn=f[n][m];
		for(int i=1;i<=m;i++){
			minans[i]=1e9;
		}
		dfsmin(n,m,m);
		for(int i=1;i<=m;i++){
			if(i>1){
				printf(" ");
			}
			printf("%d",minans[i]);
		}
		printf("\n");
		memset(now,0,sizeof(now));
		dfsmax(n,m,m);
		for(int i=1;i<=m;i++){
			if(i>1){
				printf(" ");
			}
			printf("%d",maxans[i]);
		}
		printf("\n");
		return 0;
	}
}
int main(){
	return wzk::main();
}

