#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	int n , a[15] = {0,1,2,3,4,6,6,9,11,14,16};
	int main()
	{
		scanf("%d",&n);
		cout<<a[n]<<'\n';
	}
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	hxc::main();
}
