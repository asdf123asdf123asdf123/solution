#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	long long a,b;
	int f[10005][12];//��iλΪj���ĸ��� 
	int l,r;
	int q[10005],g[10005];
	long long ans;
	int main()
	{
		freopen("windy.in","r",stdin);
		freopen("windy.out","w",stdout);
		scanf("%lld%lld",&a,&b);
		if(a<=1000000&&b<=1000000)
		{
			for(int i=a;i<=b;i++)
			{
				int x=i;
				int pre=0,flag=0;
				pre=x%10;
				x/=10;
				while(x)
				{
					if(abs(x%10-pre)<2)
					{
						flag=1;
						break;
					}
					pre=x%10;
					x/=10;
				}
				if(!flag)ans++;
			}
			printf("%lld",ans);
			return 0;
		}
		int x=a;
		while(x)
		{
			l++;
			q[l]=x%10;
			x/=10;
		}
		x=b;
		while(x)
		{
			r++;
			g[r]=x%10;
			x/=10;
		}
		
		for(int i=1;i<=l/2;i++)swap(q[i],q[l-i+1]);
		for(int i=1;i<=r/2;i++)swap(g[i],g[r-i+1]);
		bool flag=0;
		for(int i=2;i<=l;i++)
		{
			if(abs(q[i]-q[i-1])!=2)
			{
				flag=1;
				break;
			}
		}
		if(!flag)ans++;
		flag=0;
		for(int i=2;i<=r;i++)
		{
			if(abs(g[i]-g[i-1])!=2)
			{
				flag=1;
				break;
			}
		}
		if(!flag)ans++;
		flag=0;
		for(int i=0;i<=9;i++)f[1][i]=1;
		for(int i=2;i<=r;i++)
		{
			for(int j=0;j<=9;j++)
			{
				for(int k=0;k<=j-2;k++)
				{
					f[i][j]+=f[i-1][k];
				}
				for(int k=j+2;k<=9;k++)
				{
					f[i][j]+=f[i-1][k];
				}
			}
		}
		if(l!=r)
		{
			for(int i=l+1;i<=r-1;i++)
			{
				for(int j=1;j<=9;j++)
				{
					ans+=f[i][j];
				}
			}
			int pre=ans;
			for(int i=1;i<=l;i++)
			{
				if(i==1)
				{
					for(int j=q[i]+1;j<=9;j++)ans+=f[l-i+1][j];
				}
				else
				{
					for(int j=q[i]+1;j<=9;j++)
					{
						if(abs(j-q[i-1])<2)continue;
						ans+=f[l-i+1][j];
					}
					if(abs(q[i]-q[i-1])<2)break;
				}
			}
			pre=ans;
			for(int i=1;i<=r;i++)
			{
				if(i==1)
				{
					for(int j=1;j<g[i];j++)ans+=f[r-i+1][j];
				}
				else
				{
					for(int j=0;j<g[i];j++)
					{
						if(abs(j-g[i-1])<2)continue;
						ans+=f[r-i+1][j];
					}
					if(abs(g[i]-g[i-1])<2)break;
				}
			}
		}
		else
		{
			bool flag=1;
			for(int i=1;i<=l;i++)
			{
				if(i==1)
				{
					for(int j=q[i]+1;j<=g[i]-1;j++)
					{
						ans+=f[l-i+1][j];
					}
				}
				else
				{
					int maxx=9,minn=0;
					if(q[i-1]==g[i-1]&&flag)maxx=g[i]-1,minn=q[i]+1;
					else flag=0;
					for(int j=q[i]+1;j<=maxx;j++)
					{
						if(abs(j-q[i-1])<2)continue;
						ans+=f[l-i+1][j];
					}
					for(int j=minn;j<g[i];j++)
					{
						if(abs(j-g[i-1])<2)continue;
						ans+=f[l-i+1][j];
					}
					if(abs(g[i]-g[i-1])<2&&abs(q[i]-q[i-1])<2)break;
				}
			}
		}
		printf("%lld",ans);
		return 0;
	}
}
int main()
{
	return lzz::main();
}
