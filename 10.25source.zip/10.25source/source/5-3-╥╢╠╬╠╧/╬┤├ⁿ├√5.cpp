#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	int ans=0;
	map<int,int>mp;
	void dfs(int u,int lcm,int ls)
	{
		if(!u||ls==1)
		{
			
			if(!mp[lcm])ans++;
			mp[lcm]=1;
			return ;
		}
	//	cout<<u<<endl;
		for(int i=min(u,ls);i;i--)
		{
			dfs(u-i,lcm*i/__gcd(lcm,i),i);
		}
	}
	int main()
	{
		cout<<"db[1010]={0,";
		for(int i=1;i<=1000;i++)
		{
			ans=0;
			dfs(i,1,i);
			cout<<ans<<',';
		}
		cout<<"}";
		return 0;
	}
} 
int main()
{
//	freopen("game.in","r",stdin);
	freopen("B.out","w",stdout);
	akak::main();
	return 0;
}
