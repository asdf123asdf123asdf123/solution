#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 35;

namespace Josh_zmf {
	
	#define get_dis(x, y, i, j)	((x-i)*(x-i)+(y-j)*(y-j))
	
	int N, M, T, dis[Maxn][Maxn];
	int dx[4] = {0, 0, -1, 1};
	int dy[4] = {-1, 1, 0, 0};
	bool a[Maxn][Maxn], vis[Maxn][Maxn];
	struct Dij {
		int x, y, dis;
		bool operator < (const Dij &a) const { return dis > a.dis; }
	}; priority_queue <Dij> h;
	
	inline void dijstra(int x, int y) {
		memset(dis, 0x3f, sizeof(dis));
		memset(vis, 0, sizeof(vis));
		dis[x][y] = a[x][y], h.push( Dij {x, y, dis[x][y]} );
		while(!h.empty()) {
			int x = h.top().x, y = h.top().y;
			h.pop();
			if(vis[x][y]) 	continue;
			vis[x][y] = 1;
			for(int i=0; i<4; i++) {
				int xx = x+dx[i], yy = y+dy[i];
				if(xx<1 || xx>N || yy<1 || yy>M)	continue; 
				if(dis[x][y]+a[xx][yy] < dis[xx][yy]) {
					if(dis[x][y]+a[xx][yy] > T)	continue;
					dis[xx][yy] = dis[x][y]+a[xx][yy];
					h.push( Dij {xx, yy, dis[xx][yy]} );
				}
			}
		}
	} 
	
	char s[Maxn];
	
	int main() {
		scanf("%d%d%d", &N, &M, &T);
		for(int i=1; i<=N; i++) {
			scanf("%s", s+1);
			for(int j=1; j<=M; j++) {
				a[i][j] = s[j]-'0';
			}
		}
		int ans = 0;
		for(int x=1; x<=N; x++) {
			for(int y=1; y<=M; y++) {
				dijstra(x, y);
				for(int i=1; i<=N; i++) {
					for(int j=1; j<=M; j++) {
						if(dis[i][j] <= T) {
							ans = max(ans, get_dis(x, y, i, j));
						}
					}
				}
			}
		}
		printf("%.6lf", sqrt(ans));
		return 0;
	}
	
}

int main() {
	freopen("maxlength.in", "r", stdin);
	freopen("maxlength.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
