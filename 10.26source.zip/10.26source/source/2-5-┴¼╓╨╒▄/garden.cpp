#include<cstdio>
using namespace std;
const int inf = 100000005;
inline int abs(int x){
	if(x < 0)return -x;
	return x;
}
inline int min(int a,int b){
	return a < b ? a : b;
}
inline int read(){
	int ans = 0,f = 1;
	char c = getchar();
	while(c < '0' || c > '9'){
		if(c == '-')f = -1;
		c = getchar();
	}
	while('0' <= c && c <= '9'){
		ans = (ans<<3)+(ans<<1)+c-'0';
		c = getchar();
	}
	return ans*f;
}
inline void write(int x){
	if(x == 0)return;
	write(x/10);
	putchar(x%10+'0');
}
int n,m,arr[100005],a,b,c,d,brr[100005],ans;
inline void sort(int l,int r){
	if(l < r){
		int mid = l+r>>1,l1 = l,r1,tot = l;
		sort(l,mid);
		sort(mid+1,r);
		r1 = mid+1;
		while(l1 <= mid && r1 <= r){
			if(arr[l1] < arr[r1])brr[tot++] = arr[l1++];
			else brr[tot++] = arr[r1++];
		}
		while(l1 <= mid)brr[tot++] = arr[l1++];
		while(r1 <= r)brr[tot++] = arr[r1++];
		for(int i = l;i <= r;i++){
			arr[i] = brr[i];
		}
	} 
}
int l,r,mid,ans1,ans2;
int main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	n = read();
	for(int i = 1;i <= n;i++){
		arr[i] = read();
	}
	sort(1,n);
	arr[0] = arr[n+1] = inf;
	m = read();
	for(int i = 1;i <= m;i++){
		a = read();
		b = read();
		c = read();
		d = read();
		if(b < d){
			a ^= c;
			c ^= a;
			a ^= c;
			b ^= d;
			d ^= b;
			b ^= d;
		}
		if(d > 0){
			ans = abs(a-c)+abs(b-d);
			if(ans == 0)putchar('0');
			else write(ans);
			putchar('\n');
		}
		else if(b < 0){
			ans = abs(a-c)+abs(b-d);
			if(ans == 0)putchar('0');
			else write(ans);
			putchar('\n');
		}
		else{
			if(a > c){
				a ^= c;
				c ^= a;
				a ^= c;
				b ^= d;
				d ^= b;
				b ^= d;
			}
			l = 1;
			r = n;
			ans1 = 1;
			while(l <= r){
				mid = l+r>>1;
				if(arr[mid] <= a){
					ans1 = mid;
					l = mid+1;
				}
				else{
					r = mid-1;
				}
			}
			l = 1;
			r = n;
			ans2 = 1;
			while(l <= r){
				mid = l+r>>1;
				if(arr[mid] <= c){
					ans2 = mid;
					l = mid+1;
				}
				else{
					r = mid-1;
				}
			}
			//printf("(%d,%d)\n",arr[ans1],arr[ans2]);
			ans = min(min(min(abs(a-arr[ans1])+abs(arr[ans1]-c),
					abs(a-arr[ans1+1])+abs(arr[ans1+1]-c)),
					abs(a-arr[ans1-1])+abs(arr[ans1-1]-c)),
				min(min(abs(a-arr[ans2-1])+abs(arr[ans2-1]-c),
					abs(a-arr[ans2])+abs(arr[ans2]-c)),
					abs(a-arr[ans2+1])+abs(arr[ans2+1]+c))) + abs(b-d);
			//printf("(%d,%d,%d,%d)\n",abs(a-arr[ans1])+abs(arr[ans1]-c),abs(a-arr[ans1+1])+abs(arr[ans1+1]-c),abs(a-arr[ans2-1])+abs(arr[ans2-1]-c),abs(a-arr[ans2])+abs(arr[ans2]-c));
			if(ans == 0)putchar('0');
			else write(ans);
			putchar('\n');
		}
	}
	return 0;
}//100pts
/*
2
2 -1
2
0 1 0 -1
1 1 2 2
*/
// 0.007488s/1.3MB
