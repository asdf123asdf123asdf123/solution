#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=100005;
	int n,ax[MAXN],m;
	long long ans;
	int find(int x) {
		int l=1,r=n,mid;
		while (l<=r) {
			mid=l+r>>1;
			if (ax[mid]<=x) l=mid+1;
			else r=mid-1; 
		}
		return r;
	}
	long long qua(int x1,int y1,int x2,int y2) {
		return 1ll*abs(x1-x2)+1ll*abs(y1-y2);
	}
	int main() {
		freopen("garden.in","r",stdin);
		freopen("garden.out","w",stdout);
		scanf("%d",&n);
		for (int i=1;i<=n;i++) {
			scanf("%d",&ax[i]);
		}
		sort(ax+1,ax+n+1);
		scanf("%d",&m);
		int x1,y1,x2,y2;
		for (int i=1;i<=m;i++) {
			scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
			if ((y1>0 && y2>0) || (y1<0 && y2<0)) {
				ans=qua(x1,y1,x2,y2);
			} else {
				if (x2<x1) {
					swap(x1,x2);
					swap(y1,y2);
				}
				int t=find(x2);
				if (x1<=ax[t] && ax[t]<=x2) {
					//printf("%d %d %d ",x1,x2,ax[t]);
					ans=qua(x1,y1,x2,y2);
				} else {
					if (t==n) ans=qua(x1,y1,ax[t],0)+qua(ax[t],0,x2,y2);
					else ans=min(qua(x1,y1,ax[t],0)+qua(ax[t],0,x2,y2),qua(x1,y1,ax[t+1],0)+qua(ax[t+1],0,x2,y2));
				//printf("%lld %lld ",qua(x1,y1,ax[t],0)+qua(ax[t],0,x2,y2),qua(x1,y1,ax[t+1],0)+qua(ax[t+1],0,x2,y2));
				}
			}
			printf("%lld\n",ans);
		}
		return 0;
	}
}
int main() {
	//1M 
	hw::main();
	return 0;
} 
/*
2
2 -1 
2 
0 1 0 -1 
1 1 2 2
*/
