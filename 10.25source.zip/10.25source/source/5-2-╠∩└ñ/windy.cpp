#include<bits/stdc++.h>
#define LL long long
using namespace std;
namespace AFO{
	int fj[15];
	bool check(LL x){
		memset(fj,0,sizeof(fj));
		while(x){
			fj[++fj[0]]=x%10;
			x/=10;
		}
		for(int i=2;i<=fj[0];i++)
			if(abs(fj[i]-fj[i-1])<=1)return 0;
		return 1;
	}
	int main(){
		LL A,B;
		scanf("%lld%lld",&A,&B);
		if(A>B)swap(A,B);
		LL ans=0;
		for(LL i=A;i<=B;i++)
			if(check(i))ans++;
		cout<<ans;
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	AFO::main();
	return 0;
}
