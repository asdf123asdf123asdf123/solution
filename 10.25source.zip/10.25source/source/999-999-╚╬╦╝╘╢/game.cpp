#include <bits/stdc++.h>
#define int long long 

using namespace std;

namespace rsy{
	
	const int N = 100010;
	
	int gcd(int a, int b) {
		return b ? gcd(b, a % b) : a;
	}
	int lcm(int a, int b) {
		return a * b / gcd(a,b);
	}
	int n, path[N], res, maxv, f[N];
	unordered_map<int, int> vis;
	bool st[N];
	int primes[N], cnt;
	void init(int n) {
		for (int i = 2; i <= n; i++) {
			if (!st[i]) primes[++ cnt] = i;
			for (int j = 1; primes[j] <= n / i; j++) {
				st[primes[j] * i] = 1;
				if (i % primes[j] == 0) break;
			}
		}
	}
	int qmi(int a,int b){
		int res=1;
		while(b){
			if(b&1)res*=a;
			a*=a,b>>=1;
		}return res;
	}
	int fj_prime(int x) {
		int q = 0;
		for (int i = 1; ; i ++ ){
			int p = primes[i];
			if (p > x / p) break;
			if (x % p != 0) continue;
			int cnt = 0;
			while (x % p == 0) x /= p, cnt ++ ;
			q += qmi(p, cnt);
			if (q > n) return 0;
		}
		if (x > 1) q += x;
		if (q > n) return 0;
		return 1; 
	}
	void dfs(int u, int sy, int zhi){
		int s = primes[u];
		if (!vis[zhi])res ++ , vis[zhi]=1;
		if (u == cnt + 1) return;
		if (!sy) return;
		if (primes[u] > sy) return;
		if (u == 1) s = 1;
		for (int i = 0; s <= sy; i ++ ){
			for (int j = 1; j <= cnt - u + 1; j++)
				dfs (u + j, sy - (s == 1 ? 0 : s), zhi * s);
			s *= primes[u];
		}	
	}
	
	void solve(){
		cin >> n;
		init(n);
		dfs(1, n, 1);
		cout<<res<<'\n';
	}

	signed main(){
		int T = 1;
		while (T -- ) solve();
		return 0;
	}
}

signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	return rsy::main();
}
// 18663
