#include<bits/stdc++.h>
using namespace std;
#define ll long long
namespace Main {
	const int N = 15;
	int cur;
	int r[N];
	ll dp[N][N][2][2];
	ll dfs(int x, int k, bool equ, bool z) {
		//�ڼ�λ����һ����Ϊk���Ƿ�Ϊ0���Ƿ�С��r 
		if(x > cur) {
			if(!equ) return 1;
			return 0;
		}
		if(dp[x][k][equ][z] != -1) return dp[x][k][equ][z];
		ll res = 0;
		for (int i = 0; i <= (!z ? r[x] : 9); ++i) {
			if(!equ) {
				if(abs(i - k) < 2)continue;
			}
			bool _z = (i < r[x]) || z;
			bool _equ = equ && (i == 0);
			res += dfs(x + 1, i, _equ, _z);
		}
//		cout << x << ' ' << k << ' ' << equ <<' ' << z << ' ' << res << '\n';
		return dp[x][k][equ][z] = res;
	}
	ll f(int R) {
		memset(dp, -1, sizeof(dp));
		cur = 0;
		if(!R) return 0;
		while(R) {
			r[++cur] = R % 10;
			R /= 10;
		}
		reverse(r + 1, r + 1 + cur);
		return dfs(1, 0, 1, 0);
	}
	int main() {
		int a, b;
		scanf("%d%d", &a, &b);
		printf("%lld\n", f(b) - f(a - 1));
//		while(1); 
		return 0;
	}
}
int main() {
	freopen("windy.in", "r", stdin);
	freopen("windy.out", "w", stdout);
	Main :: main();
	return 0;
} 
//meb:0.5mb
