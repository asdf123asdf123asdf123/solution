#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	

	int main()
	{
		cout<<"10000 114514\n";
		for(int i=1;i<=10000;i++)
		{
			cout<<i<<' ';
		}
		return 0;
	}
}
int main()
{
//	freopen("garden.in","r",stdin);
	freopen("goddess.in","w",stdout);
	akak::main();
	return 0;
} 
