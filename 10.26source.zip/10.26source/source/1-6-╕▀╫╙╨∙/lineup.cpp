#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
int T,n,a[105],b[105],ans,flag,cnt;
vector<int>q[105];
void dfs(int u,int fa)
{
	if(!flag)return;
	int maxn=0;
	for(int i=0;i<q[u].size();i++)
	{
		int v=q[u][i];
		if(v==fa)continue;
		if(b[v]<b[u])
		{
			flag=0;
			return;
		}
		if(b[v]<maxn)
		{
			flag=0;
			return;
		}
		maxn=max(maxn,b[v]);
		dfs(v,u);
	}
	return;
}
void solve(int k)
{
	if(k==n+1)
	{
		flag=1;
		dfs(1,0);
		if(flag)
		{
//			for(int i=1;i<=n;i++)cout<<a[i]<<' '<<b[i]<<'\n';
//			cout<<'\n';
		}
		ans+=flag;
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(!b[i])
		{
			b[i]=k;
			a[k]=i;
			solve(k+1);
			b[i]=0;
			a[k]=0;
		}
	}
	return;
}
int main()
{
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	cin>>T;
	while(T--)
	{
		memset(q,0,sizeof(q));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			int s;
			scanf("%d",&s);
			for(int j=1;j<=s;j++)
			{
				int x;
				scanf("%d",&x);
				q[i].push_back(x);
				q[x].push_back(i);
			}
		}
//		for(int i=1;i<=n;i++)
//		{
//			cout<<i<<'\n';
//			for(int j=0;j<q[i].size();j++)
//			{
//				cout<<q[i][j]<<' ';
//			}
//			cout<<"\n\n";
//		}
		ans=0;
		solve(1);
		cout<<ans<<'\n';
	}
//	while(1);
	return 0;
}
}
int main(){gzx::main();return 0;}
//761kb
