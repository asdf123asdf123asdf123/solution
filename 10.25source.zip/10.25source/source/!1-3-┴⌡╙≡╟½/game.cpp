#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ans=(ans<<1)+(ans<<3)+ch-'0';
		ch=getchar();
	}
	return w*ans;
}
int n;
int gcd(int x,int y){
	if(x<y)swap(x,y);
	if(x%y==0)return y;
	return gcd(x%y,y);
}
int a[100005];
int f[1005];
int ans;
int sum;
bool vis[20000005];
void check(int p){
	sum=1;
	for(int i=1;i<=p;i++){
//		cout<<i<<' '<<p<<' '<<a[i]<<' '<<sum<<endl;;
		sum=sum*a[i]/gcd(a[i],sum);
	}
//	cout<<"*** "<<sum<<endl;
	if(!vis[sum]){
		ans++;
		vis[sum]=1;
	}
	return ;
}
void dfs(int now,int last,int k){
//	cout<<now<<' '<<last<<' '<<k<<endl;
	if(k==0){
		check(now-1);	
		return;
	}
	for(int i=last;i<=k;i++){
		a[now]=i;
		if(k-i<0)break;
		dfs(now+1,i,k-i);
		a[now]=0;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	f[1]=1;
f[2]=2;
f[3]=3;
f[4]=4;
f[5]=6;
f[6]=6;
f[7]=9;
f[8]=11;
f[9]=14;
f[10]=16;
f[11]=20;
f[12]=23;
f[13]=27;
f[14]=31;
f[15]=35;
f[16]=43;
f[17]=47;
f[18]=55;
f[19]=61;
f[20]=70;
f[21]=78;
f[22]=88;
f[23]=98;
f[24]=111;
f[25]=123;
f[26]=136;
f[27]=152;
f[28]=168;
f[29]=187;
f[30]=204;
f[31]=225;
f[32]=248;
f[33]=271;
f[34]=296;
f[35]=325;
f[36]=356;
f[37]=387;
f[38]=418;
f[39]=455;
f[40]=495;
f[41]=537;
f[42]=581;
f[43]=629;
f[44]=678;
f[45]=732;
f[46]=787;
f[47]=851;
f[48]=918;
f[49]=986;
f[50]=1056;
f[51]=1133;
f[52]=1217;
f[53]=1307;
f[54]=1399;
f[55]=1498;
f[56]=1600;
f[57]=1708;
f[58]=1823;
f[59]=1950;
f[60]=2083;
f[61]=2218;
f[62]=2356;
f[63]=2506;
f[64]=2671;
f[65]=2842;
f[66]=3025;
f[67]=3211;
f[68]=3409;
f[69]=3610;
f[70]=3830;
f[71]=4067;
f[72]=4316;
f[73]=4568;
f[74]=4829;
f[75]=5105;
f[76]=5406;
f[77]=5722;
f[78]=6051;
f[79]=6393;
f[80]=6746;
f[81]=7112;
f[82]=7506;
cin>>n;
if(n<=82){
	cout<<f[n];
	return 0;
}
else{
	while(1);
}
	return 0;
}
