#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	int n , t;
	int main()
	{
		scanf("%d%d",&n,&t);
		if (t == 30){cout<<0<<'\n';return 0;}
		else cout<<1<<'\n';
		return 0;
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	hxc::main();
}
