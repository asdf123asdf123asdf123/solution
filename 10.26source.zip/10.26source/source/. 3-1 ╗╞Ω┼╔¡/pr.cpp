#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	int main(){
		int x;
		cin>>x;
		for(int i=2;i*i<=x;i++)
			if(x%i==0)
				cout<<i<<" ";
		return 0;
	}
}
int main(){
	estidi::main();
	return 0;
}
