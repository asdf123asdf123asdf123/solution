#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	int n , m , T;
	char a[35][35];
	int size[35][35] , bj[35][35] , cnt;
	
	double dist(int x1,int y1,int x2,int y2)
	{
		double a = abs(x1-x2);
		double b = abs(y1-y2);
		return sqrt(a*a+b*b);
	}
	
	bool vst[35][35];
	struct node{int x,y;};
	node pos[405][5];
	queue<node> q1; queue<node> q2;
	void bfs1(int x,int y)
	{
		memset(vst,0,sizeof(vst));
		while (!q1.empty())	q1.pop();
		while (!q2.empty())	q2.pop();
		vst[x][y] = 1; bj[x][y] = cnt;
		q1.push((node){x,y}); q2.push((node){x,y});
		
		while (!q1.empty())
		{
			int i = q1.front().x;
			int j = q1.front().y;
			q1.pop();
			if (i+1<=n && a[i+1][j]=='0' && vst[i+1][j]==0)
			{
				vst[i+1][j] = 1;
				bj[i+1][j] = cnt;
				q1.push((node){i+1,j}); q2.push((node){i+1,j});
			}
			if (i-1>=1 && a[i-1][j]=='0' && vst[i-1][j]==0)
			{
				vst[i-1][j] = 1;
				bj[i-1][j] = cnt;
				q1.push((node){i-1,j}); q2.push((node){i-1,j});
			}
			if (j+1<=m && a[i][j+1]=='0' && vst[i][j+1]==0)
			{
				vst[i][j+1] = 1;
				bj[i][j+1] = cnt;
				q1.push((node){i,j+1}); q2.push((node){i,j+1});
			}
			if (j-1>=1 && a[i][j-1]=='0' && vst[i][j-1]==0)
			{
				vst[i][j-1] = 1;
				bj[i][j-1] = cnt;
				q1.push((node){i,j-1}); q2.push((node){i,j-1});
			}
		}
		int sz = q2.size();
		while (!q2.empty())
		{
			int i = q2.front().x;
			int j = q2.front().y;
			q2.pop();
			
			size[i][j] = sz;
		}
		return;
	}
	
	int main()
	{
		scanf("%d%d%d",&n,&m,&T);
		for (int i = 1;i <= n;i++)	scanf("%s",a[i]+1);	
		double ans = 0.0;
		if (T == 0)
		{
			for (int i = 1;i <= n;i++)
				for (int j = 1;j <= m;j++)
					if (a[i][j]=='0' && size[i][j]==0){cnt++;bfs1(i,j);}
			for (int i = 1;i < n;i++)
			for (int j = 1;j < m;j++)
				for (int l = i+1;l <= n;l++)
					for (int r = j+1;r <= m;r++)
					{
						if (bj[i][j] == bj[l][r])
							ans = max(ans,dist(i,j,l,r));
					}
			printf("%.6lf\n",ans);
			return 0;
		}
		return 0;
	}
}
int main()
{
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
//	while(1);
	hxc::main();
}
