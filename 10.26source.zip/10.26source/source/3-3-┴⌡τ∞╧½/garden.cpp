#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 1e5+5;

namespace Josh_zmf {
	
	#define dis(i, j)	(q[j].y1-q[j].y2+abs(a[i]-q[j].x1)+abs(a[i]-q[j].x2))
	
	int Q, N, a[Maxn], ans[Maxn], stk1[Maxn], top1;
	struct Que { int x1, y1, x2, y2, id; } q[Maxn];
	inline bool cmp_q(Que a, Que b) { return a.x2 < b.x2; }
	
	int main() {
		scanf("%d", &N);
		for(int i=1; i<=N; i++)	scanf("%d", &a[i]);
		scanf("%d", &Q);
		for(int i=1; i<=Q; i++) {
			int x1, y1, x2, y2;
			scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
			if(y1 < y2)	swap(y1, y2);
			if(x2 < x1)	swap(x1, x2); 
			q[i] = {x1, y1, x2, y2, i};
		}
		sort(a+1, a+1+N), sort(q+1, q+1+Q, cmp_q);
		memset(ans, 0x3f, sizeof(ans));
		int last_a = 0, i = 1, j = 1;
		while(i<=N && j<=Q) {
			if(a[i] <= q[j].x2) {
				while(top1) {
					int t = stk1[top1--];
					ans[q[t].id] = min(ans[q[t].id], dis(i, t));
				}
				last_a = i++;
			} else {
				if(last_a)	ans[q[j].id] = dis(last_a, j);
				stk1[++top1] = j++;
			}
//			printf("i:%d, a[i]:%d, j:%d, q[j]:{%d, %d, %d, %d, %d}\n", i, a[i], j, q[j].x1, q[j].y1, q[j].x2, q[j].y2, q[j].id);
		}
		if(i <= N) {
			while(top1) {
				int t = stk1[top1--];
				ans[q[t].id] = min(ans[q[t].id], dis(i, t));
			}
		} else if(j <= Q) {
			while(j <= Q) {
				if(last_a)	ans[q[j].id] = dis(last_a, j);
				j++;
			}
		}
		for(int i=1; i<=Q; i++)	printf("%d\n", ans[i]);
		return 0;
	}
	
} 

int main() {
	freopen("garden.in", "r", stdin);
	freopen("garden.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
/*
2
2 -1
2
0 1 0 -1
1 1 2 2

*/
