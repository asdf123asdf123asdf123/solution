#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	int n,m;
	long long ans=1e18;
	long long f[20005][2];//�ߵ���i�������½�״������������С����
	long long a[20005]; 
	long long solve1(int st)
	{
		for(int i=st;i<=st+n;++i)f[i][0]=f[i][1]=1e18;
		f[st][0]=0;
		f[st][1]=0;
		for(int i=st+1;i<=st+n;++i)//������ 
		{
			long long w=abs(a[i]-a[i-1]);
			if(a[i]>a[i-1])
			{
				f[i][0]=min(f[i-1][0]+w*w,f[i-1][1]+w+m);
				f[i][1]=min(f[i-1][1]+w,f[i-1][0]+w*w+m);
			}
			else
			{
				f[i][0]=min(f[i-1][0]+w,f[i-1][1]+w*2+m);
				f[i][1]=min(f[i-1][1]+w*w,f[i-1][0]+w+m);
			}
			if(f[i][0]>=ans&&f[i][1]>=ans)return 1e18;
		}
		return min(f[st+n][1],f[st+n][0]);
	}
	long long solve2(int st)
	{
		for(int i=st;i<=st+n;++i)f[i][0]=f[i][1]=1e18;
		f[st+n][0]=0;
		f[st+n][1]=0;
		for(int i=st+n-1;i>=st;--i)//������ 
		{
			long long w=abs(a[i]-a[i+1]);
			if(a[i]>a[i+1])
			{
				f[i][0]=min(f[i+1][0]+w*w,f[i+1][1]+w+m);
				f[i][1]=min(f[i+1][1]+w,f[i+1][0]+w*w+m);
			}
			else
			{
				f[i][0]=min(f[i+1][0]+w,f[i+1][1]+w*2+m);
				f[i][1]=min(f[i+1][1]+w*w,f[i+1][0]+w+m);
			}
			if(f[i][0]>=ans&&f[i][1]>=ans)return 1e18;
		}
		return min(f[st][1],f[st][0]);
	}
	int main()
	{
		freopen("goddess.in","r",stdin);
		freopen("goddess.out","w",stdout);
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;++i)
		{
			scanf("%lld",&a[i]);
			a[i+n]=a[i];
		}
		for(int st=1;st<=n;++st)
		{
			ans=min(ans,solve1(st));
			ans=min(ans,solve2(st));
		}
		printf("%lld",ans);
		return 0;
	}
}
int main()
{
	return lzz::main();
}
