#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
using namespace std;
namespace yjf{
	const int N=1010;
	int n;
	bool fl[N];
	int a[N];
	int b[N];
	bool flag[N];
	void dfs(int u){
		if(u==n+1){
			int cnt=1;
			for(int i=1;i<=n;i++){
				b[i]=a[i];
				//cout<<a[i]<<" ";
			}
			//cout<<endl;
			while(1){
				cnt++;
				bool flag=true;
				for(int i=1;i<=n;i++){
					if(b[i]!=i){
						flag=false;
					}
				}
				if(flag) break;
				for(int i=1;i<=n;i++){
					b[i]=a[b[i]];
				}
			}
//			cout<<cnt<<endl;
			flag[cnt]=true;
			return ;
		}
		for(int i=1;i<=n;i++){
			if(!fl[i]){
				fl[i]=true;
				a[u]=i;
				dfs(u+1);
				fl[i]=false;
			}
		}
	}
	int main(){
		for(n=1;n<=100;n++){
			dfs(1);
			int ans=0;
			for(int i=2;i<=1000;i++){
				if(flag[i]){
					//cout<<i<<endl;
					ans++;
				}
			}
			cout<<ans<<",";
		}
		return 0;
	}
}
int main(){
//	freopen("game.in","r",stdin);
//	freopen("game.out","w",stdout);
	return yjf::main();
}
