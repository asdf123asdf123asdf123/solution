#include <bits/stdc++.h>
#define MOD 10007
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in) {
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	int main(){
		puts ("3\n10");
		return 0;
	}
}

int main(){
	freopen ("lineup.in", "r", stdin);
	freopen ("lineup.out", "w", stdout);
	return wzy::main();
}
