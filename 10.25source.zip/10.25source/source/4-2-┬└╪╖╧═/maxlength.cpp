#include<bits/stdc++.h>
using namespace std;
namespace Main {
	const int N = 30 + 5;
	const int dir[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
	int n, m, T;
	char str[N][N];
	bool dis[N][N][N];
	//�ߵ�(i, j)����k���ϰ��ܷ񵽴� 
	struct node{
		int x, y, k;
	};
	node q[N * N * N];
	long long ans;
	long long dist(int a, int b, int c, int d) {
		return 1ll * (a - c) * (a - c) + 1ll * (b - d) * (b - d);
	}
	void bfs(int sx, int sy) { //bfs O(nmk)
		memset(dis,0,sizeof(dis));
		int l = 1, r = 0;
		q[++r] = {sx, sy, str[sx][sy] - '0'};
		dis[sx][sy][str[sx][sy] - '0'] = 1;
		while (l <= r) {
			node u = q[l++];
			ans = max(ans, dist(sx, sy, u.x, u.y));
			for (int i = 0; i < 4; ++i) {
				int nx = u.x + dir[i][0], ny = u.y + dir[i][1];
				if(1 <= nx && nx <= n && 1 <= ny && ny <= m) {
					int nk = u.k + str[nx][ny] - '0';
					if (nk <= T) {
						if(!dis[nx][ny][nk]) {
							dis[nx][ny][nk] = 1;
							q[++r] = {nx, ny, nk};
						}
					}
				}
			}
		}
	}
	int main() {
		scanf ("%d%d%d", &n, &m, &T);
		for (int i = 1; i <= n; ++i) {
			scanf("%s", str[i] + 1);
		}
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j <= m; ++j) {
				//O(n ^ 5)
				bfs(i, j);
			}
		}
		printf("%.6f", sqrt(ans));
//		while(1);
		return 0;
	}
}
int main() {
//	int S = clock();
	freopen("maxlength.in", "r", stdin);
	freopen("maxlength.out", "w", stdout);
	Main :: main();
//	int T = clock();
//	cerr << (T - S) << '\n';
	return 0;
} 
//meb:1mb
