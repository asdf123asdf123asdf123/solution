#include<bits/stdc++.h>
using namespace std;
int n,m;
int t;
char d[35][35];
bool mp[35][35];
int fx[9] = {0,0,0,1,-1};
int fy[9] = {0,1,-1,0,0};
double ans;
double jl(int f_x,int f_y,int s_x,int s_y){
	double jl_x = abs(f_x-s_x);
	double jl_y = abs(f_y-s_y);
	
	return sqrt((jl_x*jl_x)+(jl_y * jl_y));
}
struct node{
	int x,y;
};
queue<node> qu;
int c[35][35];
void bfs(int st_x,int st_y){
	for(int i = 1; i <= n; i ++){
		for(int j = 1; j <= m; j ++){
			c[i][j] = 1e9;
		}
	}
	c[st_x][st_y] = mp[st_x][st_y];
	if(mp[st_x][st_y] <= t){
		qu.push((node){st_x,st_y});
	}
	while(!qu.empty()){
		node tmp = qu.front();
		qu.pop();
		int n_x = tmp.x,n_y = tmp.y;
		for(int i = 1; i <= 4; i ++){
			int to_x = n_x + fx[i],to_y = n_y + fy[i];
			if(1 <= to_x &&to_x <= n && 1 <= to_y &&to_y <= m){
				if(c[n_x][n_y]+mp[to_x][to_y] <= t){
					if(c[to_x][to_y] > c[n_x][n_y]+mp[to_x][to_y]){
						c[to_x][to_y] = c[n_x][n_y]+mp[to_x][to_y];
						ans = max(ans,jl(st_x,st_y,to_x,to_y));
						//cout << st_x << " " << st_y << " " << s_x << " " << s_y << "\n";
						qu.push((node){to_x,to_y}); 
					}
				} 
			}
		}
	}
	return ;
}
namespace hua_tu{
	int main(){
		cin >> n >> m;
		cin >> t;
		for(int i = 1; i <= n; i ++){
			for(int j = 0; j <= m; j ++){
				scanf("%c",&d[i][j]);
				mp[i][j] = d[i][j]-'0';
			}
		}
		for(int i = 1; i <= n ; i ++){
			for(int j = 1; j <= m; j ++){
				//cout << mp[i][j] <<" ";
				bfs(i,j);
			}
//			cout << " ans:" << ans ;
//			cout << "\n";
		}
		printf("%.6lf",ans);
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	hua_tu::main(); // ��ͼ 
	return 0;
}
/*
3 3 1
001
001
001
AC
3 3 0
001
001
110
AC
4 3 0
001
001
011
000
AC
*/
