#include <bits/stdc++.h>
#define int long long

using namespace std;

namespace rsy{
	
	const int N = 20010, inf = 1e16;
	
	int n, m, a[N], dp[2][2], res = inf;
	//0��������1���½� 
	
	void solve() {
		scanf ("%lld%lld", &n, &m);
		for (int i = 1; i <= n; i++)
			scanf ("%lld", &a[i]), a[i + n] = a[i];
		for (int i = 1; i <= n; i++) {
			int l = i, r = i + n;
			dp[l & 1][0] = dp[l & 1][1] = 0;
			for (int j = l + 1; j <= r; j++) {
				dp[j & 1][0] = dp[j & 1][1] = inf;
				if (a[j] > a[j - 1]) {
					int x = a[j] - a[j - 1];
					for (int k = 0; k <= 1; k++) {
						int t = (k == 0 ? x : x * x);
						dp[j & 1][k] = min({dp[j & 1][k], dp[(j - 1) & 1][k], dp[(j - 1) & 1][k ^ 1] + m}) + t;
					}
				} else {
					int x = a[j - 1] - a[j];
					for (int k = 0; k <= 1; k++) {
						int t = (k == 0 ? x * x : x);	
						dp[j & 1][k] = min({dp[j & 1][k], dp[(j - 1) & 1][k], dp[(j - 1) & 1][k ^ 1] + m}) + t;
					}
				}
			}
			res = min({res, dp[r & 1][0], dp[r & 1][1]});
		}
		printf("%lld\n", res);
	}

	signed main(){
		int T = 1;
		while (T -- ) solve();
		return 0;
	}
}

signed main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	return rsy::main();
}
