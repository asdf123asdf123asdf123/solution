#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	int A[30][30];
	int n,t,ans,mod=2009;
	void dfs(int u,int now)
	{
		if(now>t)return ;
		if(now==t)
		{
			if(u==n)ans++;
			ans%=mod;
			return ;
		}
		for(int i=1;i<=n;i++)
		{
			if(A[u][i])
			{
				dfs(i,now+A[u][i]);
			}
		}
	}
	int main()
	{
		scanf("%d%d",&n,&t);
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				char ch=' ';
				while(ch<'0')
				{
					ch=getchar();
				}
				A[i][j]=ch-'0';
			}
		}
		dfs(1,0);
		cout<<ans;
		return 0;
	}
} 
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	akak::main();
	return 0;
}
