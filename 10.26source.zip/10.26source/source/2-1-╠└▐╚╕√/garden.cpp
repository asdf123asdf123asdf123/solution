#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
namespace Zimu_Zhao{
	const int N = 1e5, inf = 0x7fffffff / 2;
	int a[N + 10], n, m;
	inline int f(int x1, int y1, int x2, int y2){
		return abs(x1 - x2) + abs(y1 - y2);
	}
	int main(){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++)
			scanf("%d", &a[i]);
		scanf("%d", &m);
		int x1, y1, x2, y2, ans;
		while(m--){
			scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
			if(1ll * y1 * y2 > 0)
				printf("%d\n", f(x1, y1, x2, y2));
			else{
				ans = inf;
				for(int i = 1; i <= n; i++)
					ans = min(ans, f(x1, y1, a[i], 0) + f(a[i], 0, x2, y2));
				printf("%d\n", ans);
			}
		}
		return 0;
	}
}
int main(){
	freopen("garden.in", "r", stdin);
	freopen("garden.out", "w", stdout);
	return Zimu_Zhao::main();
}
//1MB
