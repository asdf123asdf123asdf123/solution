#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int a,b;
//	int v[13];
//	long long l,ll;
	long long ans;
//	long long lll;
//	int wei;
//	bool check(){
//		l=0;
//		ll=1;
//		for(int i=wei;i>=1;i--){
//			l+=v[i]*ll;
//			ll*=10;
//		}
//		lll++;
////		cout<<l<<' '<<lll<<'\n';
//		if((a<=l)&&(l<=b)){
//			return 1;
//		}
//		return 0;
//	}
//	int ra[13],rb[13];
//	void dfs(int u,int r){
////		for(int i=1;i<=u;i++){
////			cout<<v[i]<<' ';
////		}
////		cout<<'\n';
//		if(u>wei){
//			if(check()){
//				ans++;
//			}
//			return;
//		}
//		if(r==1){
//			for(int i=0;i<=9;i++){
//				if(abs(i-v[u-1])<2){
//					continue;
//				}
//				
//				v[u]=i;
//				dfs(u+1,1);
//			}
//		}else if(r==2){
//			for(int i=ra[u];i<=9;i++){
//				if(abs(i-v[u-1])<2){
//					continue;
//				}
//				
//				v[u]=i;
//				dfs(u+1,1);
//			}
//		}else if(r==3){
//			for(int i=0;i<=rb[u];i++){
//				if(abs(i-v[u-1])<2){
//					continue;
//				}
//				
//				v[u]=i;
//				dfs(u+1,1);
//			}
//		}else{
//			v[u]=ra[u];
//			dfs(u+1,2);
//			for(int i=ra[u]+1;i<rb[i];i++){
//				v[u]=i;
//				dfs(u+1,1);
//			}
//			v[u]=rb[u];
//			dfs(u+1,3);
//		}
//	}
	bool check(int x){
		int last=x%10,now=0;
		x/=10;
		while(x){
			now=x%10;
			x/=10;
			if(abs(now-last)<2){
				return 0;
			}
			last=now;
		}
		return 1;
	}
	int main(){
		freopen("windy.in","r",stdin);
		freopen("windy.out","w",stdout);
		scanf("%d%d",&a,&b);
//		int c=b;
//		while(c){
//			wei++;
//			c/=10;
//		}
//		for(int i=wei;i>=1;i--){
//			ra[i]=a%10;
//			a/=10;
//			rb[i]=b%10;
//			b/=10;
//		}
//		for(int i=1;i<=wei;i++){
//			cout<<ra[i]<<' ';
//		}
//		cout<<'\n';
//		for(int i=1;i<=wei;i++){
//			cout<<rb[i]<<' ';
//		}
//		cout<<'\n';
//		for(int i=ra[1];i<=rb[1];i++){
//			v[1]=i;
//			dfs(2);
//		}
		for(int i=a;i<=b;i++){
			if(check(i)){
				ans++;
			}
		}
		printf("%lld\n",ans);
		return 0;
	}
}
int main(){
	return wzk::main();
}

