#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const int INf=1e9+7;

namespace NoFive{

	signed main(){
		srand(time(0));
		for(int i=2;i<10007;i++){
			if(10007%i==0)printf("%d\n",i); 
		} 
		return 0;
	}
}
signed main(){
//	freopen(".in","r",stdin);
//	freopen("goddess114.in","w",stdout);
	NoFive::main();
	return 0;
}

