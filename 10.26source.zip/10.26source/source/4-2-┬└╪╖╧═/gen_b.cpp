#include<bits/stdc++.h>
using namespace std;
namespace Main {
	mt19937 G(time(0));
	int main() {
		freopen("goddess.in", "w", stdout);
		int n = 10000;
		cout << n << ' ' << G() % 1000000000 + 1 << '\n';
		for (int i = 1; i <= n; ++i) {
			cout << G() % (1000000) + 1 << ' '; 
		}
		return 0;
	}
}
int main() {
	Main::main();
//	freopen(".in", "r", stdin);
	return 0;
} 
