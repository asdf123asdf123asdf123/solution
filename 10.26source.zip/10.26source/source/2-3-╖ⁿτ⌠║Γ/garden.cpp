#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 100005, inf = 0x7fffffff / 2;
	int n, m, x[MAXN], x1, x2, y1, y2, l, r;
	int main(){
		scanf("%d", &n);
		for(int i = 1;i <= n;i++){
			scanf("%d", &x[i]);
		}
		sort(x + 1, x + n + 1);
		scanf("%d", &m);
		for(int i = 1;i <= m;i++){
			scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
			if(1ll * y1 * y2 > 0){
				printf("%d\n", abs(x1 - x2) + abs(y1 - y2));
				continue;
			}
			l = 1;
			r = n;
			int ans = inf;
			if(x1 > x2){
				swap(x1, x2);
				swap(y1, y2);
			}
			while(l <= r){
				int mid = (l + r) >> 1;
				ans = min(ans, abs(x1 - x[mid]) + abs(x2 - x[mid]));
				if(x1 <= x[mid] && x[mid] <= x2){
					ans = abs(x1 - x2);
					break;
				}
				else if(x1 > x[mid]){
					l = mid + 1;
				}
				else if(x2 < x[mid]){
					r = mid - 1;
				}
			}
			printf("%d\n", ans + abs(y1 - y2));
		}//while(1);
		return 0;
	}
} 
int main(){
	freopen("garden.in", "r", stdin);
	freopen("garden.out", "w", stdout);
	return ac::main();
}//1MB
