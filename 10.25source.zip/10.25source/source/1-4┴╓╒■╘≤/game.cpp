#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	int n;
/*	int num[1005];//��i������Ӧ�ĸ���
	int vst[1005];
	map<int,int>bj;
	int a[1005],ans;*/
	int ans[1005]={0,1,2,3,4,6,6,9,11,14,16,20,23};
	/*void dfs(int now)
	{
		if(now==n+1)
		{
			int x=1;
			for(int i=1;i<=n;i++)
			{
				a[i]=num[i];
			}
			while(1)
			{
				int flag=1;
				for(int i=1;i<=n;i++)
				{
					if(i!=a[i])
					{
						flag=0;
						break;
					}
				}
				if(flag)break;
				for(int i=1;i<=n;i++)a[i]=num[a[i]];
				x++;
			}
			if(!bj[x])bj[x]=1,ans++;
		}
		for(int i=1;i<=n;i++)
		{
			if(vst[i])continue;
			num[now]=i;
			vst[i]=1;
			dfs(now+1);
			num[now]=0;
			vst[i]=0;
		}
	} */
	int main()
	{
		freopen("game.in","r",stdin);
		freopen("game.out","w",stdout);
		int n;
		scanf("%d",&n);
		printf("%d",ans[n]);
		return 0;
	}
}
int main()
{
	return lzz::main();
}
