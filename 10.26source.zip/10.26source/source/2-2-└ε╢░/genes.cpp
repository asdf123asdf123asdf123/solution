#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n;
	int a[2000050];
	int sum[2000050];
	int main(){
		freopen("genes.in","r",stdin);
		freopen("genes.out","w",stdout);		
		
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",a+i);
			sum[i]=sum[i-1]+a[i];
		}		
		for(int i=n+1;i<=2*n;i++){
			a[i]=a[i-n];
			sum[i]=sum[i-1]+a[i];
		}
		
		int ans=0;
		for(int i=1;i<=n;i++){
			int bj=1;
			for(int j=i;j<=i+n-1;j++){
				int now=sum[j]-sum[i-1];
				if(now<0){
					bj=0;
					break;	
				}			
			}
			if(bj)ans++;
		}	
		cout<<ans<<'\n';
					
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}

//  4*4*(c4,2)
