#include<bits/stdc++.h>
using namespace std;
namespace F1{
	int T,n,k,u;
	struct edge{
		int to,next;
	}ed[2002];
	int head[2002],cnt=0,a[1002][1002],mod=10007,ans=0;
	void add_edge(int x,int y){
		ed[++cnt].next=head[x];
		ed[cnt].to=y;
		head[x]=cnt;
	}
	bool b[1002];
	void dfs(int step){
		if(step==n-1){
			ans++;
			return ;
		}
		for(int i=1;i<=n;i++){
			if(b[i]){
				int minn=1e9,p=-1;
				for(int j=head[i];j;j=ed[j].next){
					int v=ed[j].to;
					if(b[v]){
						continue;
					}
					if(minn>a[i][v]){
						minn=a[i][v];
						p=v;
					}
				}
				if(p!=-1){
					b[p]=1;
					dfs(step+1);
					b[p]=0;
				}
			}
		}
	}
	int main(){
		scanf("%d",&T);
		while(T--){
			ans=0;
			memset(b,0,sizeof(b));
			scanf("%d",&n);
			for(int i=1;i<=n;i++){
				scanf("%d",&k);
				for(int j=1;j<=k;j++){
					scanf("%d",&u);
					a[i][u]=j;
					add_edge(i,u);
					add_edge(u,i);
				}
			}
			b[1]=1;
			dfs(0);
			printf("%d\n",ans%mod);
		}
		return 0;
	}
}
signed main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	F1::main();
	return 0;
}
/*
2
5
2 2 3
2 4 5
0
0
0
7
2 2 3
2 4 5
2 6 7
0
0
0
0
*/
