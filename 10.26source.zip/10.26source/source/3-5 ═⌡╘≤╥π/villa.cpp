#include <bits/stdc++.h>
#define MAXN 5000005
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in) {
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	int n;
	int m;
	int bg[MAXN];
	char chin;
	
	int anssum=INT_MAX;
	int ans1[MAXN];
	int ans2[MAXN];
	int ret[MAXN];
	
	inline int Ask(int l, int r){
		return bg[r]-bg[l-1];
	}
	
	void Dfs(int u, int lim, int now){
		if (u==n+1){
			if (lim<0 || lim>0) return;
			if (now<anssum){
				anssum=now;
				for (int i=1;i<=m;i++) ans1[i]=ans2[i]=ret[i];
				return;
			}
			if (now==anssum){
				for (int i=1;i<=m;i++) ans2[i]=ret[i];
				return;
			}
			return;
		}
		if (now>anssum) return;
		if (lim<=0) return;
		int pos=m-lim+1;
		ret[pos+1]++;
		if (ret[pos]) Dfs (u+1, lim-1, max(now, abs(ret[pos]-2*Ask(u-ret[pos]+1, u))));
		ret[pos+1]--;
		ret[pos]++;
		Dfs (u+1, lim, now);
		ret[pos]--;
		return;
	}
	
	int main(){
		Read (n);
		Read (m);
		while (chin=getchar(), !isdigit(chin) && chin!=EOF);
		for (int i=1;i<=n;i++){
			bg[i]=chin=='1';
			chin=getchar();
		}
		for (int i=1;i<=n;i++) bg[i]+=bg[i-1];
		Dfs (1, m, 0);
		for (int i=1;i<=m;i++) printf ("%d ", ans1[i]);
		printf ("\n");
		for (int i=1;i<=m;i++) printf ("%d ", ans2[i]);
		return 0;
	}
}

int main(){
	freopen ("villa.in", "r", stdin);
	freopen ("villa.out", "w", stdout);
	return wzy::main();
}

/*
8 3
11001100
*/
