#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	long long num[13][13],s[13];
	long long count(long long x){
		if(x==0)
			return 1;
		int ans=0;
		while(x){
			x/=10;
			ans++;
		}
		return ans;
	}
	long long get(long long x){
		long long c=count(x),cc=c,ans=s[c-1],last=-10,xx;
		for(int k=cc-1;k>=1;k--){
			xx=x/(long long)(pow(10,k))%10;
			int kkk=0;
			if(k==cc-1)
				kkk=1;
			for(int i=kkk;i<xx;i++)
				if(abs(i-last)>=2)
					ans+=num[c][i];
			if(abs(last-xx)<2){
//				cerr<<last<<" "<<xx<<" "<<x<<" "<<ans<<endl;
				return ans;
			}
			last=xx;
			c--;
		}
		xx=x%10;
		for(int i=0;i<=xx;i++)
			if(abs(i-last)>=2)
				ans+=num[c][i];
//		cerr<<x<<" "<<ans<<endl;
		return ans;
	}
	int main(){
		long long a,b;
		scanf("%lld%lld",&a,&b);
		for(int i=0;i<=9;i++)
			num[1][i]=1;
		s[1]=10;
		for(int i=2;i<=10;i++){
			for(int j=0;j<=9;j++)
				for(int k=0;k<=9;k++)
					if(abs(j-k)>=2)
						num[i][j]+=num[i-1][k];
			s[i]=s[i-1];
			for(int j=1;j<=9;j++)
				s[i]+=num[i][j];
		}
//		for(int i=1;i<=10;i++){
//			for(int j=0;j<=9;j++)
//				cerr<<setw(9)<<num[i][j]<<" ";
//			cerr<<"|"<<setw(9)<<s[i]<<endl;
//		}
		printf("%d",get(b)-get(a-1));
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	estidi::main();
	return 0;
}
//[16] 20 24
