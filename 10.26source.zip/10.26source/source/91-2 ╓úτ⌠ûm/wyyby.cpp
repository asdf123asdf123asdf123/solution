#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const int INf=1e9+7;

namespace NoFive{
	
	signed main(){
		
		
		return 0;
	}
} 
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	NoFive::main();
	return 0;
}
