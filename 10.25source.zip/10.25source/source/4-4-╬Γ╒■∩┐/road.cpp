#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int n,t;
	char c[20][20];
	int cnt,head[20];
	struct ed{
		int next,to,val;
	}edge[40];
	void add(int u,int v,int w){
		++cnt;
		edge[cnt].next=head[u];
		edge[cnt].to=v;
		edge[cnt].val=w;
		head[u]=cnt;
	}
	int f[13][500000];
	queue<pair<int,int> >q;
	void solve(){
		q.push({0,0});
		int u,nowt;
		while(q.size()){
			u=q.front().first;
			nowt=q.front().second;
			q.pop();
			if(nowt>t){
				continue;
			}
			f[u][nowt]++;
			f[u][nowt]%=2009;
			for(int i=head[u];i;i=edge[i].next){
				int v=edge[i].to;
				q.push({v,nowt+edge[i].val});
			}
		}
	}
	int main(){
		freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);
		scanf("%d%d",&n,&t);
		for(int i=0;i<n;i++){
			scanf("%s",c[i]);
			for(int j=0;j<n;j++){
				if(c[i][j]!='0'){
					add(i,j,c[i][j]-'0');
				}
			}
		}
		solve();
		printf("%d\n",f[n-1][t]);
		return 0;
	}
}
int main(){
	return wzk::main();
}

