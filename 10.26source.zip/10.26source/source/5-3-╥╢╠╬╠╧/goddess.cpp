#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	long long n,m;
	long long dp[20010][4],A[20010];

	int main()
	{
		scanf("%lld%lld",&n,&m);
		
		for(int i=1;i<=n;i++)
		{
		//	cout<<i<<endl;
			scanf("%lld",&A[i]);
			A[i+n]=A[i];
		}
		
		long long ans=1e18;
		for(int i=1;i<=n;i++)
		{
			memset(dp,127,sizeof(dp));
			dp[i][0]=dp[i][1]=0;
			for(int j=i+1;j<=i+n;j++)
			{
				long long dis=abs(A[j-1]-A[j]);
				if(A[j-1]>A[j])
				{
					dp[j][0]=min(dp[j-1][0]+dis,dp[j-1][1]+m+dis);
					dp[j][1]=min(dp[j-1][0]+m+dis*dis,dp[j-1][1]+dis*dis);
				}
				else
				{
					dp[j][1]=min(dp[j-1][1]+dis,dp[j-1][0]+m+dis);
					dp[j][0]=min(dp[j-1][0]+dis*dis,dp[j-1][1]+m+dis*dis);
				}
			//	if(i==3)cout<<dp[j][0]<<' '<<dp[j][1]<<endl;
			}
			
			ans=min(ans,min(dp[i+n][0],dp[i+n][1]));
		}
		cout<<ans;
		return 0;
	}
}
int main()
{
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	akak::main();
	return 0;
} 
