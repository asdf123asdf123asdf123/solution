#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 1005, mod = 10007;
	int T, g[MAXN][MAXN], n, k, tmp;
	int head[MAXN], cnt;
	struct node{
		int next, to;
	}ed[2 * MAXN];
	void add_edge(int u, int v){
		ed[++cnt].next = head[u];
		ed[cnt].to = v;
		head[u] = cnt;
	} 
	int f[MAXN], sz[MAXN];
	void dfs(int u){
		if(!u) return ;
		f[u] = sz[u] = 1;
		for(int i = head[u];i;i = ed[i].next){
			int v = ed[i].to;
			dfs(v);
			f[u] = 1ll * f[u] * f[v] % mod * g[sz[u] - 1][sz[v] - 1] % mod;
			sz[u] += sz[v]; 
		}
	}
	int main(){
		scanf("%d", &T);
		for(int i = 0;i <= 1000;i++) g[i][0] = g[0][i] = 1;
		for(int i  = 1;i <= 1000;i++){
			for(int j = 1;j <= 1000;j++){
				g[i][j] = (g[i - 1][j] + g[i][j - 1]) % mod;
			}
		}
		/*for(int i = 1;i <= 10;i++){
			for(int j = 1;j <= 10;j++){
				printf("%d ", g[i][j]);
			}
			puts("");
		}*/
		for(int ii = 1;ii <= T;ii++){
			scanf("%d", &n);
			cnt = 0;
			for(int i = 1;i <= n;i++) f[i] = sz[i] = head[i] = 0;
			for(int i = 1;i <= n;i++){
				scanf("%d", &k);
				for(int j = 1;j <= k;j++){
					scanf("%d", &tmp);
					add_edge(i, tmp);
				}
			}
			dfs(1);
			/*for(int i = 1;i <= n;i++) printf("%d ", f[i]);
			puts("");
			for(int i = 1;i <= n;i++) printf("%d ", sz[i]);
			puts("");*/
			printf("%d\n", f[1]);
		}//while(1); 
		return 0;
	}
} 
int main(){
	freopen("lineup.in", "r", stdin);
	freopen("lineup.out", "w", stdout);
	return ac::main();
}//4MB
