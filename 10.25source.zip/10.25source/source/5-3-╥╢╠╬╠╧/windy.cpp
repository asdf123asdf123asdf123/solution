#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	char A[110],B[110];
	long long dp[110][12];
	int t1[110],t2[110];
	char C[110];
	int cheak(long long num)
	{
		int ls=-4;
		while(num)
		{
			if(abs(num%10-ls)<=1)return 0;
			ls=num%10;
			num/=10;
		}
		return 1;
	}
	
	
	int main()
	{
		scanf("%s%s",A+1,B+1);
		int n=strlen(B+1),m=strlen(A+1);
		long long ia=0,ib=0,ans=0;
		for(int i=1;i<=n;i++)
		{
			ib=ib*10+B[i]-'0';
		}
		for(int i=1;i<=m;i++)
		{
			ia=ia*10+A[i]-'0';
		}
		if(ib-ia<=1000000)
		{
			for(long long i=ia;i<=ib;i++)
			{
				ans+=cheak(i);
			}
			cout<<ans;
			return 0;
		}
		
		
		//�ع�һ�� 
		for(int i=0;i<=9;i++)
		{
			dp[1][i]=1;
		}
		for(int i=2;i<=n;i++)
		{
			for(int j=0;j<=9;j++)
			{
				for(int k=0;k<=9;k++)
				{
					if(abs(k-j)<=1)continue;
					dp[i][j]+=dp[i-1][k];
				}
			}
		}
		
		for(int i=1;i<=n;i++)
		{
			if(i<=m)t2[i]=A[m-i+1]-'0';
			t1[i]=B[n-i+1]-'0';
		} 
		for(int i=n;i>1;i--)
		{
			for(int j=t1[i]-1;j>=0;j--)
			{
				if(i!=n&&abs(j-t1[i+1])<=1)continue;
				for(int k=0;k<=9;k++)
				{
					if(abs(j-k)<=1)continue;
					ans+=dp[i-1][k];
				}
				if(i==n&&!j)ans+=dp[i-1][1];
			} 
		}
		
		for(int i=m;i>1;i--)
		{
			for(int j=t2[i]-1;j>=0;j--)
			{
				if(i!=m&&abs(j-t2[i+1])<=1)continue;
				for(int k=0;k<=9;k++)
				{
					if(abs(j-k)<=1)continue;
					ans-=dp[i-1][k];
				}
				if(i==m&&!j)ans-=dp[i-1][1];
			} 
		}
		
		cout<<ans;
		return 0;
	}
} 
//660k=0.6m
int main()
{
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	akak::main();
	return 0;
}
