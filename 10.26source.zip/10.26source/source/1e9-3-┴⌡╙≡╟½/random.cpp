#include <bits/stdc++.h>
#include <random>
using namespace std;
random_device R;
mt19937 G(R());
int rd(int l,int r){
	return uniform_int_distribution<int>(l,r)(G);
} 
int main(){
//	freopen("garden.in","r",stdin);
	freopen("random.in","w",stdout);
	cout<<10000<<' '<<rd(20000000,100000000)<<'\n';
	for(int i=1;i<=10000;i++){
		cout<<rd(100000,1000000)<<' ';
	}
}
