#include<cstdio>
using namespace std;
#define ll long long
namespace windy{
	inline ll abs(ll x){
		if(x < 0)return -x;
		return x;
	}
	ll a,b,ans = 0;
	inline ll dfs(ll x,ll y){
		if(y > b)return 0;
		ll i,anss = 0;
		if(y >= a)anss++;
		for(i = 0;i <= x-2;i++){
			if((y<<3)+(y<<1)+i > b)return anss;
			anss += dfs(i,(y<<3)+(y<<1)+i);
		}
		for(i = x+2;i <= 9;i++){
			if((y<<3)+(y<<1)+i > b)return anss;
			anss += dfs(i,(y<<3)+(y<<1)+i);
		}
		return anss;
	}
	int main(){
		scanf("%lld %lld",&a,&b);
		for(int i = 1;i <= 9;i++)ans += dfs(i,i);
		printf("%lld",ans);
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	windy::main();
	return 0;
}//100pts
