#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	int n,m;
	long long a[100005];
	int main()
	{
		freopen("garden.in","r",stdin);
		freopen("garden.out","w",stdout);
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%lld",&a[i]);
		}
		sort(a+1,a+n+1);
		a[n+1]=a[n+2]=1e18;
		scanf("%d",&m);
		while(m--)
		{
			long long x1,y1,x2,y2;
			scanf("%lld%lld%lld%lld",&x1,&y1,&x2,&y2);
			if(x1>x2)swap(x1,x2),swap(y1,y2);
			if((y1<0&&y2<0)||(y1>0&&y2>0))//��ͬһ�� 
			{
				printf("%lld\n",abs(x1-x2)+abs(y1-y2));
				continue;
			}
			int now=lower_bound(a+1,a+n+3,x1)-a;
			if((a[now]>=x1&&a[now]<=x2))//���м��п��е� 
			{
				printf("%lld\n",abs(x1-x2)+abs(y1-y2));
				continue;
			}
			long long w1,w2,w3;
			w1=2*min(abs(a[now]-x1),abs(a[now]-x2));
			w2=2*min(abs(x1-a[now-1]),abs(x2-a[now-1]));
			w3=2*min(abs(x1-a[now+1]),abs(x2-a[now+1]));
			printf("%lld\n",min(w1,min(w2,w3))+abs(x1-x2)+abs(y1-y2));
		}
		return 0;
	}
}
int main()
{
	return lzz::main();
} 
