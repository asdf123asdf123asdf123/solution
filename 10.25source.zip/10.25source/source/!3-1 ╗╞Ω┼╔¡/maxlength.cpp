#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	string s[33];
	int n,m,t,vis[33][33],gox[7]={0,1,-1,0,0},goy[7]={0,0,0,1,-1};
	double ans=-1;
	struct mypair{
		int x,y,z;
	};
	void getans(int fx,int fy,int sx,int sy){
		ans=max(ans,sqrt((fx-sx)*(fx-sx)+(fy-sy)*(fy-sy)));
	}
	void get(int x,int y,int st){
		mypair p,pp;
		queue<mypair>q,qq;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				vis[i][j]=0;
		q.push({x,y,st});
		while(q.size()||qq.size()){
			while(q.size()){
				p=q.front();
				q.pop();
				if(vis[p.x][p.y])
					continue;
				vis[p.x][p.y]=1;
				getans(x,y,p.x,p.y);
				for(int i=1;i<=4;i++){
					pp={p.x+gox[i],p.y+goy[i],p.z};
					if(pp.x<=0||pp.x>n||pp.y<=0||pp.y>m||vis[pp.x][pp.y])
						continue;
					if(s[pp.x][pp.y]=='1'){
						if(pp.z){
							pp.z--;
							qq.push(pp);
						}
					}
					else
						q.push(pp);
				}
			}
			while(qq.size()){
				p=qq.front();
				qq.pop();
				if(vis[p.x][p.y])
					continue;
				vis[p.x][p.y]=1;
				getans(x,y,p.x,p.y);
				for(int i=1;i<=4;i++){
					pp={p.x+gox[i],p.y+goy[i],p.z};
					if(pp.x<=0||pp.x>n||pp.y<=0||pp.y>m||vis[pp.x][pp.y])
						continue;
					if(s[pp.x][pp.y]=='1'){
						if(pp.z){
							pp.z--;
							q.push(pp);
						}
					}
					else
						qq.push(pp);
				}
			}
		}
	}
	int main(){
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++){
			cin>>s[i];
			s[i]=" "+s[i];
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				if(s[i][j]=='0')
					get(i,j,t);
				else
					if(t)
						get(i,j,t-1);
		printf("%.6lf",ans);
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	estidi::main();
	return 0;
}
