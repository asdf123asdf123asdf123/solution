#include<bits/stdc++.h>
using namespace std;
int n,m;
int jl(int s_x,int s_y,int l_x,int l_y) {
	return abs(s_x-l_x) + abs(s_y-l_y);
}
int a[100005];
bool cmp(int xx,int yy) {
	return xx < yy;
}
int ans = 1e9;
namespace wxl{
	int main(){
		return 0;
	}
}
int main() {
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	//wxl::main(); ��д namespace �ˣ���һ�� 
	cin >> n;
	int jian = 0;
	for(int i = 1; i <= n; i ++) {
		scanf("%d",&a[i]);
	}
	sort(a+1,a+n+1,cmp);
	for(int i = 1; i < n; i++){
		if(a[i] == a[i+1]){
			a[i] = 1e9;
			jian++;
		}
	}
	sort(a+1,a+n+1,cmp);
	n = n - jian;
	int tx,ty,ex,ey;
	int l,r,mid;
	cin >> m; 
	if(m <= 3000){
		//cout << "a!";
		for(int i = 1; i <= m; i ++) {
			int ans = 1e9;
			scanf("%d%d%d%d",&tx,&ty,&ex,&ey);
			if(ty > 0 && ey > 0){
				printf("%d\n",jl(tx,ty,ex,ey));
				continue;
			}
			else if(ty < 0 && ey < 0){
				printf("%d\n",jl(tx,ty,ex,ey));
				continue;
			}
			for(int j = 1; j <= n; j ++){
				ans = min(jl(tx,ty,a[j],0)+jl(a[j],0,ex,ey),ans); 
			}
			printf("%d\n",ans);
		}
		return 0;
	}
	for(int i = 1; i <= m; i ++) {
		l = 1,r = n;
		
		//bool zbj = 0,ybj = 0;
		scanf("%d%d%d%d",&tx,&ty,&ex,&ey);
		if(ty > 0 && ey > 0){
			printf("%d\n",jl(tx,ty,ex,ey));
			continue;
		}
		else if(ty < 0 && ey < 0){
			printf("%d\n",jl(tx,ty,ex,ey));
			continue;
		}
		
		//|| (zbj||jl(tx,ty,a[l],0)+jl(a[l],0,ex,ey) <= jl(tx,ty,a[l-1],0)+jl(a[l-1],0,ex,ey)) && (ybj||jl(tx,ty,a[l],0)+jl(a[l],0,ex,ey) <= jl(tx,ty,a[l+1],0)+jl(a[l+1],0,ex,ey))
		while(l <= r+1){
			//zbj = 0,ybj = 0;
			mid = (l+r)>>1;
			//cout << l << " " << r <<" " << mid<<"\n";
			int md = jl(tx,ty,a[mid],0)+jl(a[mid],0,ex,ey);
			if(md < jl(tx,ty,a[l],0)+jl(a[l],0,ex,ey)){
				l = mid;
			}
			else {
				r = mid-1;
			}
//			if(l-1 <= 0){
//				zbj = 1;
//			}
//			if(l+1 > n){
//				ybj = 1;
//			}
		} 
//		for(int k = l; k <= r; k ++){
//			ans = min(jl(tx,ty,a[k],0)+jl(a[k],0,ex,ey),ans); 
//		}
		//cout << l <<" " << r <<"\n";
		ans = min(jl(tx,ty,a[l],0)+jl(a[l],0,ex,ey),min(min(jl(tx,ty,a[1],0)+jl(a[1],0,ex,ey),jl(tx,ty,a[n-1],0)+jl(a[n-1],0,ex,ey)),jl(tx,ty,a[n],0)+jl(a[n],0,ex,ey))); 
		printf("%d\n",ans);
	}
	return 0;
}
/*
2
2 -1
2
0 1 0 -1
1 1 2 2


1
-2
1
1 1 -1 -1

25428 83260 -74108 68997
62876 -18716 62874 38812
41432 9593 41592 -54193
-37290 -34871 -37295 4634
*/
