#include<bits/stdc++.h>
#define int long long
using namespace std;
namespace gzx
{
const int INF=0x7fffffff/2;
int n,a[100005],Q;
int dis(int x1,int y1,int x2,int y2)
{
	return abs(x1-x2)+abs(y1-y2);
}
signed main()
{
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	sort(a+1,a+1+n);
	scanf("%lld",&Q);
	while(Q--)
	{
		int x1,y1,x2,y2;
		scanf("%lld%lld%lld%lld",&x1,&y1,&x2,&y2);
		if(x1>x2)
		{
			swap(x1,x2);
			swap(y1,y2);//�����2 
		}
		if((y1<=0&&y2<=0)||(y1>0&&y2>0))
		{
			cout<<dis(x1,y1,x2,y2)<<'\n';
			continue;
		}
		int ans=INF;
		for(int i=1;i<=n;i++)
		{

			ans=min(ans,dis(x1,y1,a[i],0)+dis(x2,y2,a[i],0));
			if(x1<=a[i]&&a[i]<=x2)break;
		}
		cout<<ans<<'\n';
	}
//	while(1);
	return 0;
}
}
signed main(){gzx::main();return 0;}
//1496kb
