#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	int main(){
		cout<<"30 30 30\n";
		for(int i=1;i<=30;i++){
			for(int j=1;j<=30;j++)
				if(i%2==0&&j%2==0)
					cout<<"0";
				else
					cout<<"1";
			cout<<endl;
		}
		return 0;
	}
}
int main(){
	freopen("maxlength.in","w",stdout);
	estidi::main();
	return 0;
}
