#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

namespace Wyy{
	

	signed main(){
		srand(time(0));
		cout<<"30 30 2\n";
		for(register int i=1;i<=30;++i){
			for(register int j=1;j<=30;++j){
				cout<<rand()%2;
			} 
			cout<<endl;
		}
		return 0;
	}
}
signed main(){
//	freopen(".in","r",stdin);
	freopen("maxlength114.in","w",stdout);
	Wyy::main();
	return 0;
}

