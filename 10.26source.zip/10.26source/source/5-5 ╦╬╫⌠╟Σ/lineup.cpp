#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[1005][1005];
int T;
namespace No_AFO{
	int main(){
		cin >> T;
		while(T--){
//			cin >> n;
//			for(int i =1; i <= n; i ++){
//				scanf("%d",&a[i][0]);
//				for(int j = 1; j <= a[i][0]; j ++){
//					scanf("%d",&a[i][j]);
//				}
//			}
			printf("1\n");
		}
		
		
		return 0;
	}
}
int main() { 
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	No_AFO::main(); 
	return 0;
}
/*
*/
