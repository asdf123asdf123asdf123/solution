#include<cstdio>
using namespace std;
#define ll long long
inline ll abs(ll x){
	if(x < 0)return -x;
	return x;
}
inline ll min(ll a,ll b){
	return a < b ? a : b;
}
inline ll read(){
	ll ans = 0,f = 1;
	char c = getchar();
	while(c < '0' || c > '9'){
		if(c == '-')f = -1;
		c = getchar();
	}
	while('0' <= c && c <= '9'){
		ans = (ans<<3)+(ans<<1)+c-'0';
		c = getchar();
	}
	return ans*f;
}
inline void write(ll x){
	if(x == 0)return;
	write(x/10);
	putchar(x%10+'0');
}
ll n,m,arr[20005],dep[20005],dp1[20005][2],dp2[20005][2],fa1[20005][2],fa2[20005][2],ans = ((ll)9223372036854775807),tmp1,tmp2;
inline ll dfs1(int x,int y,int z){
	if(z <= 0)return dp1[x][y];
	if(x <= 1)return dp1[x][y];
	return dfs1(x-1,fa1[x][y],z-1);
}
inline ll dfs2(int x,int y,int z){
	if(z <= 0)return dp2[x][y];
	if(x >= (n<<1))return dp2[x][y];
	return dfs2(x+1,fa2[x][y],z-1);
}
int main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	n = read();
	m = read();
	for(int i = 1;i <= n;i++){
		arr[i] = arr[i+n] = read();
		dep[i] = dep[i+n] = abs(arr[i]-arr[i-1]);
	}
	dep[1] = dep[n+1] = abs(arr[1]-arr[n]);
	for(int i = 2;i <= (n<<1);i++){
		if(arr[i-1] > arr[i]){
			tmp1 = dp1[i-1][1]+dep[i];
			tmp2 = dp1[i-1][0]+dep[i]+m;
			dp1[i][1] = min(tmp1,tmp2);
			if(dp1[i][1] == tmp1){
				fa1[i][1] = 1;
			}
			else{
				fa1[i][1] = 0;
			}
			tmp1 = dp1[i-1][0]+dep[i]*dep[i];
			tmp2 = dp1[i-1][1]+dep[i]*dep[i]+m;
			dp1[i][0] = min(tmp1,tmp2);
			if(dp1[i][0] == tmp1){
				fa1[i][0] = 0;
			}
			else{
				fa1[i][0] = 1;
			}
		}
		else{
			tmp1 = dp1[i-1][1]+dep[i]*dep[i];
			tmp2 = dp1[i-1][0]+dep[i]*dep[i]+m;
			dp1[i][1] = min(tmp1,tmp2);
			if(dp1[i][1] == tmp1){
				fa1[i][1] = 1;
			}
			else{
				fa1[i][1] = 0;
			}
			tmp1 = dp1[i-1][0]+dep[i];
			tmp2 = dp1[i-1][1]+dep[i]+m;
			dp1[i][0] = min(tmp1,tmp2);
			if(dp1[i][0] == tmp1){
				fa1[i][0] = 0;
			}
			else{
				fa1[i][0] = 1;
			}
		}
	}
	for(int i = n+1;i <= (n<<1);i++){
		ans = min(ans,min(dp1[i][0]-dfs1(i,0,n),dp1[i][1]-dfs1(i,1,n)));
	}
	for(int i = (n<<1)-1;i >= 1;i--){
		if(arr[i+1] > arr[i]){
			tmp1 = dp2[i+1][1]+dep[i+1];
			tmp2 = dp2[i+1][0]+dep[i+1]+m;
			dp2[i][1] = min(tmp1,tmp2);
			if(dp2[i][1] == tmp1){
				fa2[i][1] = 1;
			}
			else{
				fa2[i][1] = 0;
			}
			tmp1 = dp2[i+1][0]+dep[i+1]*dep[i+1];
			tmp2 = dp2[i+1][1]+dep[i+1]*dep[i+1]+m;
			dp2[i][0] = min(tmp1,tmp2);
			if(dp2[i][0] == tmp1){
				fa2[i][0] = 0;
			}
			else{
				fa2[i][0] = 1;
			}
		}
		else{
			tmp1 = dp2[i+1][1]+dep[i+1]*dep[i+1];
			tmp2 = dp2[i+1][0]+dep[i+1]*dep[i+1]+m;
			dp2[i][1] = min(tmp1,tmp2);
			if(dp2[i][1] == tmp1){
				fa2[i][1] = 1;
			}
			else{
				fa2[i][1] = 0;
			}
			tmp1 = dp2[i+1][0]+dep[i+1];
			tmp2 = dp2[i+1][1]+dep[i+1]+m;
			dp2[i][0] = min(tmp1,tmp2);
			if(dp2[i][0] == tmp1){
				fa2[i][0] = 0;
			}
			else{
				fa2[i][0] = 1;
			}
		}
	}
	dfs2(1,0,0);
	dfs2(1,1,1);
	for(int i = 1;i <= n;i++){
		ans = min(ans,min(dp2[i][0]-dfs2(i,0,n),dp2[i][1]-dfs2(i,1,n)));
	}
	if(ans == 0)putchar('0');
	else write(ans);
	return 0;
}//50pts
/*
6 7
4 2 6 2 5 6
*/
