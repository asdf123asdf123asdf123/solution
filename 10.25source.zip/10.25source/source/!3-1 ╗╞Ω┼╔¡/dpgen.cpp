#include<bits/stdc++.h>
using namespace std;
int main(){
	int xx;
	freopen("road.in","r",stdin);
	cin>>xx>>xx;
	fclose(stdin);
	freopen("road.in","w",stdout);
	srand(time(0)*xx);
	cout<<"10 "<<rand()%50<<endl;
	for(int i=1;i<=10;i++){
		for(int j=1;j<=10;j++)
			cout<<rand()%10;
		cout<<endl;
	}
	return 0;
}
