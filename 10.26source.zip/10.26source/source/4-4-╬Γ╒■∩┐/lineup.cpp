#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	const int mod=10007;
	int T;
	int n,k,l,last;
	int cnt,head[1200];
	struct ed{
		int next,to;
	}edge[2400];
	int fa[1200];
	void add(int u,int v){
		++cnt;
		edge[cnt].next=head[u];
		edge[cnt].to=v;
		head[u]=cnt;
	}
//	int sz[1200];
//	void getsz(int u){
//		sz[u]=1;
//		for(int i=head[u];i;i=edge[i].next){
//			int v=edge[i].to;
//			getsz(v);
//			sz[u]+=sz[v];
//		}
//	}
//	int f[1200];
//	void solve(int u){
//		for(int i=head[u];i;i=edge[i].next){
//			int v=edge[i].to;
//			solve(v);
//			
//		}
//	}
	int df[1200];
	bool can[1200];
	int ans;
	void dfs(int u){
		if(u>n){
			ans++;
			ans%=mod;
//			for(int i=1;i<=n;i++){
//				cout<<df[i]<<' ';
//			}
//			cout<<'\n';
			return;
		}
		for(int i=1;i<=n;i++){
			if(!can[i]){
				continue;
			}
			df[u]=i;
			can[i]=0;
			for(int j=head[i];j;j=edge[j].next){
				int v=edge[j].to;
				can[v]=1;
			}
			dfs(u+1);
			can[i]=1;
			for(int j=head[i];j;j=edge[j].next){
				int v=edge[j].to;
				can[v]=0;
			}
		}
	}
//	void ckk(int u){
//		cout<<u<<'\n';
//		for(int i=head[u];i;i=edge[i].next){
//			int v=edge[i].to;
//			ckk(v);
//		}
//	}
	int main(){
		freopen("lineup.in","r",stdin);
		freopen("lineup.out","w",stdout);
		scanf("%d",&T);
		while(T--){
			scanf("%d",&n);
			for(int i=1;i<=n;i++){
				scanf("%d",&k);
				for(int j=1;j<=k;j++){
					scanf("%d",&l);
					if(j==1){
						add(i,l);
					}else{
						add(last,l);
					}
					fa[l]=i;
					last=l;
				}
			}
//			if(n<=9){
				memset(can,0,sizeof(can));
				ans=0;
//				ckk(1);
				can[1]=1;
				dfs(1);
				printf("%d\n",ans);
//			}else{
//				getsz(1);
//				solve(1);
//			}
		}
		return 0;
	}
}
int main(){
	return wzk::main();
}

