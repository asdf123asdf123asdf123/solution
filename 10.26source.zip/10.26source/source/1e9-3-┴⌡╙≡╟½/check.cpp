#include <bits/stdc++.h>
using namespace std;
int n;
int a[100005],b[100005]; 
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	for(int i=1;i<=n;i++){
		if(a[i]!=b[i])cout<<i<<endl;
	}
}
