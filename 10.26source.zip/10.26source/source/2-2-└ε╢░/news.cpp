#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n;

	vector<int> ed[200050];	
	int f[200050];
	int son_num[200050];
	int ti[200050];
	int min_time=1e9;
	
	void dfs(int u, int last){
		int cnt=0;
		for(int i=0;i<ed[u].size();i++){
			int v=ed[u][i];
			if(v==last)continue;
			++cnt;
			f[v]=f[u]+cnt;
			dfs(v,u);
		}
	}
	bool cmp(int x,int y){
		return son_num[x]>son_num[y];
	}
	int main(){
		freopen("news.in","r",stdin);
		freopen("news.out","w",stdout);		
		
		scanf("%d",&n);
		for(int i=2;i<=n;i++){
			int f;
			scanf("%d",&f);
			ed[f].push_back(i);
			ed[i].push_back(f);
			son_num[f]++;
			son_num[i]++;
		}
		
	
		for(int i=1;i<=n;i++){
				
			for(int j=1;j<=n;j++)
				sort(ed[j].begin(),ed[j].end(),cmp);
				
			f[i]=1;
			dfs(i,0);
			
			for(int j=1;j<=n;j++){
				ti[i]=max(ti[i],f[j]);
			}
				
			min_time=min(min_time, ti[i]);
				
		}
		cout<<min_time<<'\n';
		for(int i=1;i<=n;i++)
			if(ti[i]==min_time)
				cout<<i<<' ';
		
		
		
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}
