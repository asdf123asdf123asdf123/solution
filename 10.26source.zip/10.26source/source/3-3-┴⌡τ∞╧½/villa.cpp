#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 2e6+5;

namespace Josh_zmf {

	int N, M, sum[Maxn], res[Maxn], ans[Maxn];
	bool a[Maxn];
	
	inline bool Check(int mid) {
		int last = N+1;
		for(int i=M; i>=1; i--) {
			res[i] = 0;
//			printf("i:%d, last:%d\n", i, last);
			for(int j=i; j<last; j++) {
//				printf("i:%d, last:%d, j:%d\n", i, last, j);
				if(abs(sum[last-1]-sum[j-1]) <= mid) {
//					printf("i:%d, %d~%d\n", i, j, last-1);
					res[i] = last-j, last = j;
					break;
				}
			} 
			if(res[i] == 0)	return 0;
		}
		return 1;
	}
	
	char s[Maxn];

	int main() {
		scanf("%d%d%s", &N, &M, s+1);
		for(int i=1; i<=N; i++) {
			a[i] = s[i]^48;
			sum[i] = sum[i-1]+(a[i] ?1 :-1);
//			printf("sum[%d]:%d\n", i, sum[i]);
		}
		int l = 0, r = (N+M-1)/M, mid;
		while(l <= r) {
			mid = (l+r)>>1;
//			printf("l:%d, r:%d, mid:%d\n", l, r, mid);
			if(!Check(mid))	l = mid+1;
			else {
//				printf("mid:%d\n", mid);
				r = mid-1;
				for(int i=1; i<=M; i++)	ans[i] = res[i];
//				int cnt = 0;
//				for(int i=1; i<=M; i++)	cnt += ans[i];
//				if(cnt != N)	printf("cnt:%d\n", cnt);
			}
		}
		for(int i=1; i<=M; i++)	printf("%d ", ans[i]);
		return 0;
	}

}

int main() {
	freopen("villa.in", "r", stdin);
	freopen("villa.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
