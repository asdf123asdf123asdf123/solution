#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	long long a[20003],f[5][5];
	int main(){
//time_t s=clock();
		int n;
		long long m,ans=21474836477777777;
		scanf("%d%lld",&n,&m);
		for(int i=1;i<=n;i++){
			scanf("%lld",&a[i]);
			a[i+n]=a[i];
		}
		for(int i=1;i<=n;i++){
			f[1][1]=0;
			f[1][2]=0;
			for(int k=2;k<=n+1;k++){
				int j=i+k-1;
				if(a[j]>a[j-1]){
					f[k%2][1]=min(f[(k-1)%2][1]+abs(a[j]-a[j-1]),f[(k-1)%2][2]+(a[j]-a[j-1])*(a[j]-a[j-1])+m);
					f[k%2][2]=min(f[(k-1)%2][1]+abs(a[j]-a[j-1])+m,f[(k-1)%2][2]+(a[j]-a[j-1])*(a[j]-a[j-1]));
				}
				else{
					f[k%2][1]=min(f[(k-1)%2][1]+(a[j]-a[j-1])*(a[j]-a[j-1]),f[(k-1)%2][2]+abs(a[j]-a[j-1])+m);
					f[k%2][2]=min(f[(k-1)%2][1]+(a[j]-a[j-1])*(a[j]-a[j-1])+m,f[(k-1)%2][2]+abs(a[j]-a[j-1]));
				}
			}
			ans=min(ans,min(f[(n-1)%2][1],f[(n-1)%2][2]));
		}
		for(int i=2*n-1;i>=n;i--){
			f[1][1]=0;
			f[1][2]=0;
			for(int k=2;k<=n+1;k++){
				int j=i-k+1;
				if(a[j]>a[j+1]){
					f[k%2][1]=min(f[(k-1)%2][1]+abs(a[j]-a[j+1]),f[(k-1)%2][2]+(a[j]-a[j+1])*(a[j]-a[j+1])+m);
					f[k%2][2]=min(f[(k-1)%2][1]+abs(a[j]-a[j+1])+m,f[(k-1)%2][2]+(a[j]-a[j+1])*(a[j]-a[j+1]));
				}
				else{
					f[k%2][1]=min(f[(k-1)%2][1]+(a[j]-a[j+1])*(a[j]-a[j+1]),f[(k-1)%2][2]+abs(a[j]-a[j+1])+m);
					f[k%2][2]=min(f[(k-1)%2][1]+(a[j]-a[j+1])*(a[j]-a[j+1])+m,f[(k-1)%2][2]+abs(a[j]-a[j+1]));
				}
			}
			ans=min(ans,min(f[(n-1)%2][1],f[(n-1)%2][2]));
		}
		printf("%lld",ans);
//cerr<<clock()-s;//mod O2
		return 0;
	}
}
int main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	estidi::main();
	return 0;
}
