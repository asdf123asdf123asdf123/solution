#include<bits/stdc++.h>
#define LL long long
using namespace std;
namespace last_context{
	const int maxn=10005;
	int a[maxn];
	int n;
	LL m;
	struct edge{int nxt,to;LL w;}eg[2][maxn*4+5];
	int h[2][maxn*2],cnt[2]={0};//i Ϊ���� ��i+nΪ�½�    �������� 
	void in(int bh,int u,int v,LL w){
		eg[bh][++cnt[bh]]={h[bh][u],v,w};
		h[bh][u]=cnt[bh]; 
	}
	void build(){
		
		//tu 0 shun
		for(int i=1;i<n;i++){
			//lian i -> i+1 de
			if(a[i]>a[i+1]){
				//no;
				in(0,i+n,i+1+n,abs(a[i]-a[i+1]));
				in(0,i,i+1,pow(abs(a[i]-a[i+1]),2));
				//yes �������� 
				in(0,i,i+1+n,m+abs(a[i]-a[i+1]));
				in(0,i+n,i+1,m+pow(abs(a[i]-a[i+1]),2));
			}else{
				//no;
				in(0,i,i+1,abs(a[i]-a[i+1]));
				in(0,i+n,i+1+n,pow(abs(a[i]-a[i+1]),2));
				//yes �������� 
				in(0,i+n,i+1,m+abs(a[i]-a[i+1]));
				in(0,i,i+1+n,m+pow(abs(a[i]-a[i+1]),2));
			}
		}
		//lian n -> 1
		if(a[n]>a[1]){
			//no;
			in(0,n+n,1+n,abs(a[i]-a[i+1]));
			in(0,n,1,pow(abs(a[i]-a[i+1]),2));
			//yes �������� 
			in(0,n,1+n,m+abs(a[i]-a[i+1]));
			in(0,n+n,1,m+pow(abs(a[i]-a[i+1]),2));
		}else{
			//no;
			in(0,n,1,abs(a[i]-a[i+1]));
			in(0,n+n,1+n,pow(abs(a[i]-a[i+1]),2));
			//yes �������� 
			in(0,n+n,1,m+abs(a[i]-a[i+1]));
			in(0,n,1+n,m+pow(abs(a[i]-a[i+1]),2));
		}
		//end
		
		//tu 1 ni
		for(int i=2;i<=n;i++){
			//lian i -> i-1 de
			if(a[i]>a[i-1]){
				//no;
				in(1,i+n,i-1+n,abs(a[i]-a[i-1]));
				in(1,i,i-1,pow(abs(a[i]-a[i-1]),2));
				//yes �������� 
				in(1,i,i-1+n,m+abs(a[i]-a[i-1]));
				in(1,i+n,i-1,m+pow(abs(a[i]-a[i-1]),2));
			}else{
				//no;
				in(1,i,i-1,abs(a[i]-a[i-1]));
				in(1,i+n,i-1+n,pow(abs(a[i]-a[i-1]),2));
				//yes �������� 
				in(1,i+n,i-1,m+abs(a[i]-a[i-1]));
				in(1,i,i-1+n,m+pow(abs(a[i]-a[i-1]),2));
			}
		}
		//lian 1 -> n
		if(a[1]>a[n]){
			//no;
			in(1,1,n,pow(abs(a[1]-a[n]),2));
			in(1,1+n,n+n,abs(a[1]-a[n]));
			//yes �������� 
			in(1,1,n+n,m+abs(a[1]-a[n]));
			in(1,1+n,n,m+pow(abs(a[1]-a[n]),2));
		}else{
			//no;
			in(1,1+n,n+n,pow(abs(a[1]-a[n]),2));
			in(1,1,n,abs(a[1]-a[n]));
			//yes �������� 
			in(1,1+n,n,m+abs(a[1]-a[n]));
			in(1,1,n+n,m+pow(abs(a[1]-a[n]),2));
		}
		//end
		
	}
	int d[maxn*2][4];
	bool vst[maxn*2];
	priority_queue<pair<int,int> >q;
	void dij(int s,int bh,int wz){
		memset(vst,0,sizeof vst);
		for(int i=1;i<=2*n;i++)d[i][wz]=1e9;
		d[i][s]=0;
		q.push(make_pair(0,s));
		while(!q.empty()){
			int u=q.top().second;
			q.pop();
			if(vst[u])continue;
			vst[u]=1;
			for(int i=h[u];i;i=eg[i].nxt){
				
			}
		}
	}
	int main(){
		scanf("%d%lld",&n,&m);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		build();
		dij(2,0,0);
		dij(2+n,0,1);
		dij(2,1,2);
		dij(2+n,1,3);
		LL ans=1e17;
		//shun
		
		//ni
		
		return 0;
	}
}
int main(){
//	freopen("goddess.in","r",stdin);
//	freopen("goddess.out","w",stdout);
	last_context::main();
	return 0;
}
