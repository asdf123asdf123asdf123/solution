#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int check(int x){
		int last=x%10;
		x/=10;
		while(x){
			int now=x%10;
			if(abs(now-last)<2)return 0;
			x/=10;
			last=now;
		}	
		return 1;
	}	
	
	int F[25][15];
	int f[25][15];
	int g[25];
	int a,b;
	int ttl;	
	int lim[25];

	int Get_b(int x){
		int ans=0;
		int cnt=(int)log10(x)+1;	
		int tx=x;
		int tcnt=0;
		while(tx){
			lim[++tcnt]=tx%10;
			tx/=10;
		}
		
		int last=lim[cnt];
		for(int i=last+1;i<=9;i++)
			ans+=F[cnt][i];
			
		for(int i=cnt-1;i>=1;i--){
			int now=lim[i];
			for(int j=now+1;j<=9;j++){
				if(abs(j-last)<2)continue;
				ans+=F[i][j];
			}
			if(abs(now-last)<2)break;
			last=now;
		}
		return ans;		
	}
	int Get_s(int x){		
		int ans=0;
		int cnt=(int)log10(x)+1;	
		int tx=x;
		int tcnt=0;
		while(tx){
			lim[++tcnt]=tx%10;
			tx/=10;
		}
		
		int last=lim[cnt];
		for(int i=1;i<last;i++)
			ans+=F[cnt][i];
			
		for(int i=cnt-1;i>=1;i--){
			int now=lim[i];
			for(int j=0;j<now;j++){
				if(abs(j-last)<2)continue;
				ans+=F[i][j];
			}
			if(abs(now-last)<2)break;
			last=now;
		}
		return ans;		
	}
	int Get_double(int x,int y){
		int x1=Get_b(x);
		int y1=Get_b(y);		
		if(check(x))return x1-y1+1;
		else return x1-y1;	
	}	
	int main(){
		freopen("windy.in","r",stdin);
		freopen("windy.out","w",stdout);		
		
		scanf("%d%d",&a,&b);
		for(int i=0;i<=9;i++)
			f[1][i]=1;
		
		for(int i=2;i<=10;i++){
			for(int j=0;j<=9;j++)
				for(int k=0;k<=9;k++){
					if(abs(j-k)<2)continue;
					f[i][j]=f[i][j]+f[i-1][k];
				}
			for(int j=1;j<=9;j++)
				g[i]+=f[i][j];
		}
		memcpy(F,f,sizeof(f));
		
		int lena=(int)log10(a)+1;
		int lenb=(int)log10(b)+1;
		
		for(int i=lena+1;i<=lenb-1;i++){
			ttl+=g[i];
		}
			
		
		if(lenb-lena>=1){
			ttl+=Get_b(a);
			ttl+=Get_s(b);
			
			if(check(a))ttl++;
			if(check(b))ttl++;
			cout<<ttl<<'\n';
			return 0;
		}	
		
		ttl+=Get_double(a,b);
		cout<<ttl<<'\n';
		return 0;
	}
}
int main(){
	ld::main();
	return 0;
}
