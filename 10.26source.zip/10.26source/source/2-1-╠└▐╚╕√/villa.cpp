#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
namespace Zimu_Zhao{
	const int N = 1e3;
	int a[N + 10], q[N + 10], f[N + 10][N + 10], g[N + 10][N + 10];
	int n, m;
	void print(int i, int j){
		if(i){
			print(i - 1, g[i][j]);
			printf("%d", j - g[i][j]);
			if(i != n)
				printf(" ");
		}
	}
	int main(){
		scanf("%d%d", &n, &m);
		for(int i = 1; i <= n; i++){
			scanf("%1d", &a[i]);
			a[i] = a[i] ? 1 : -1;
			q[i] = q[i - 1] + a[i];
		}
		memset(f, 0x3f, sizeof(f));
		f[0][0] = 0;
		for(int i = 1; i <= m; i++){
			for(int j = i; j <= n; j++){
				for(int k = i - 1; k < j; k++)
					f[i][j] = min(f[i][j], max(f[i - 1][k], abs(q[j] - q[k])));
				for(int k = i - 1; k < j; k++){
					if(f[i][j] == max(f[i - 1][k], abs(q[j] - q[k]))){
						g[i][j] = k;
						break;
					}
				}
			}
		}
		print(m, n);
		puts("");
		memset(f, 0x3f, sizeof(f));
		f[0][0] = 0;
		for(int i = 1; i <= m; i++){
			for(int j = i; j <= n; j++){
				for(int k = j - 1; k >= i - 1; k--)
					f[i][j] = min(f[i][j], max(f[i - 1][k], abs(q[j] - q[k])));
				for(int k = j - 1; k >= i - 1; k--){
					if(f[i][j] == max(f[i - 1][k], abs(q[j] - q[k]))){
						g[i][j] = k;
						break;
					}
				}
			}
		}
		print(m, n);
		return 0;
	}
}
int main(){
	freopen("villa.in", "r", stdin);
	freopen("villa.out", "w", stdout);
	return Zimu_Zhao::main();
}
