#include<bits/stdc++.h>
using namespace std;
namespace Main {
	mt19937 G(time(0));
	int main() {
		int T = 0;
		while(1) {
			cout << (++T) << '\n';
			system("gen_b.exe");
			int s0 = clock();
			system("std.exe");
			int s = clock();
			system("goddess.exe");
			int t = clock();
			if(t - s > 900) {
				cout << "Time Out\n";
				break;
			}
			cerr << s - s0 << ' ' << t - s << '\n';
			if(system("fc std.out goddess.out")) {
				cout<<"Faild\n";
				break;
			}
			
		}
		return 0;
	}
}
int main() {
	Main::main();
//	freopen(".in", "r", stdin);
	return 0;
} 
