#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ans=(ans<<1)+(ans<<3)+ch-'0';
		ch=getchar();
	}
	return w*ans;
}
int n,t;
struct edge{
	int to;
	int next;
	int w;
}ed[250];
int cnt;
int h[15];
void add(int x,int y,int w){
	ed[++cnt]={y,h[x],w};
	h[x]=cnt;
}
int ans;
void dfs(int x,int now){
	if(now>t)return ;
	if(now==t){
		if(x==n)ans=(ans+1)%2009;
		return ;
	}
	for(int i=h[x];i;i=ed[i].next){
		dfs(ed[i].to,now+ed[i].w);
	} 
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	t=read(); 
	for(int i=1;i<=n;i++){
		string s;
		cin>>s;
		for(int j=0;j<n;j++){
			if(s[j]=='0')continue;
			add(i,j+1,s[j]-'0');
		}
	}
	dfs(1,0);
	cout<<ans;
	return 0;
}
/*
2 2
11
00
*/
/*
5 30
12045
07105
47805
12024
12345
*/
