/*
Happy birthday to jzp!!!
*/
#include<bits/stdc++.h>
using namespace std;
int n,cnt,p[10005];
bool flag[10005];
long long f[1005][1005],ans;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	for(int i=2;i<=n;++i){
		if(!flag[i]){
			p[++cnt]=i;
			for(int j=i;j<=n;j+=i){
				flag[j]=1;
			}
		}
	}
	f[0][0]=1;
	for(int i=1;i<=cnt;++i){
		for(int j=0;j<=n;++j){
			f[i][j]=f[i-1][j];
			int num=p[i];
			while(j-num>=0){
				f[i][j]+=f[i-1][j-num];
				num*=p[i];
			}
		}
	}
	for(int i=0;i<=n;++i){
		ans+=f[cnt][i];
	}
	cout<<ans<<'\n';
	return 0;
} 

