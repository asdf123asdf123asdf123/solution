#include<bits/stdc++.h>
using namespace std;
long long a,b;
long long ans;
long long xz[15] = {8,7,7,7,7,7,7,7,7,8};
void dfs(long long x){
	if(x > b)return;
	if(a <= x && x <= b){
		//cout <<x  <<"\n";
		ans++;
	}
	for(int i = 0; i <=9; i ++){
		if((x == 0&&i!=0)||abs((x%10)-i) >= 2){
			dfs(x*10+i);
		}
	}
	return ;
}
namespace oier{
	int main(){
		cin >> a >> b;
		dfs(0);
		cout << ans;
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	oier::main(); // oier
	return 0;
}
/*
1 10
AC
25 50
AC
"��" ����
AC 
*/
