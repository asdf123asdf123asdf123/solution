#include <bits/stdc++.h>
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in){
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	int n;
	
	inline long long Gcd(long long a, long long b){
		while (a^=b^=a^=b%=a);
		return b;
	}
	
	inline long long Lcm(long long a, long long b){
		return a*b/Gcd(a, b);
	}
	
	int ans;
	map <int, bool> bj;
	
	void Dfs(int lim, long long now){
		if (!lim){
			if (bj[now]) return;
			bj[now]=1;
			ans++;
			return;
		}
		for (int i=1;i<=lim;i++){
			Dfs (lim-i, Lcm(now, i));
		}
		return;
	}
	
	void Clean(){
		map <int, bool> ts;
		swap (bj, ts);
		return;
	}
	
	int list[40]={0, 1, 2, 3, 4, 6, 6, 9, 11, 14, 16, 20, 23, 27, 31, 35, 43, 47, 55, 61, 70, 78, 88, 98, 111, 123, 136, 152, 168, 187, 204, 225, 248, 271, 296, 325, 356};
	
	int main(){
		Read (n);
		if (n<=36){
			cout<<list[n];
			return 0;
		}
		Dfs (n, 1);
		printf ("%d\n", ans);
		
		return 0;
	}
}

int main(){
	freopen ("game.in", "r", stdin);
	freopen ("game.out", "w", stdout);
	return wzy::main();
}
