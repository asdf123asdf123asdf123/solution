#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 1e4+10;
const ll INF = 1e18+5;

namespace Josh_zmf {

	int N, M, a[Maxn*2];
	ll f[Maxn][2];

	int main() {
		scanf("%d%d", &N, &M);
		for(int i=1; i<=N; i++)	scanf("%d", &a[i]), a[i+N] = a[i];
		a[2*N+1] = a[1];
		ll ans = INF;
		for(int s=1; s<=N; s++) {
			f[1][0] = f[1][1] = 0;
			for(int i=2; i<=N+1; i++) {
				if(a[s+i-1] < a[s+i]) {
					f[i][1] = min(f[i-1][1]+a[s+i]-a[s+i-1], f[i-1][0]+1ll*(a[s+i]-a[s+i-1])*(a[s+i]-a[s+i-1])+M);
					f[i][0] = min(f[i-1][1]+a[s+i]-a[s+i-1]+M, f[i-1][0]+1ll*(a[s+i]-a[s+i-1])*(a[s+i]-a[s+i-1]));
//					f[i][1] = f[i-1][1]+a[s+i]-a[s+i-1];
//					f[i][0] = f[i][1]+M;
				} else {
					f[i][0] = min(f[i-1][0]+a[s+i-1]-a[s+i], f[i-1][1]+1ll*(a[s+i-1]-a[s+i])*(a[s+i-1]-a[s+i])+M);
					f[i][1] = min(f[i-1][0]+a[s+i-1]-a[s+i]+M, f[i-1][1]+1ll*(a[s+i-1]-a[s+i])*(a[s+i-1]-a[s+i]));
//					f[i][0] = f[i-1][0]+a[s+i]-a[s+i-1];
//					f[i][1] = f[i][0]+M;
				}
//				printf("f[%d][0]:%lld, f[%d][1]:%lld\n", i, f[i][0], i, f[i][1]);
			}
			ans = min(ans, min(f[N+1][0], f[N+1][1]));
		}
		cout<< ans;
		return 0;
	}

}

int main() {
	freopen("goddess.in", "r", stdin);
	freopen("goddess.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
/*
6 7
4 2 6 2 5 6

*/ 
