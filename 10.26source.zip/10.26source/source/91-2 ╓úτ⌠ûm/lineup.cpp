#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const int INF=1e9+7;

namespace NoFive{
	const int N=1005;
	const int mod=10007;
	int T,n;
	vector<int>tr[N];
	ll f[N],fac[N],C[N][N],A[N][N],sz[N];
	void init(){
		fac[0]=1;
		for(register int i=1;i<=1000;++i)
			fac[i]=(fac[i-1]*i)%mod;
//		cout<<fac[5]<<endl;
		memset(C,0,sizeof(C));
		C[1][0]=1,C[1][1]=1;
		for(register int i=2;i<=1000;++i){
			C[i][0]=1;
			A[i][0]=1;
			for(register int j=1;j<=i;++j){
				C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
				A[i][j]=(C[i][j]*fac[j])%mod;
			}
		}
//		cout<<C[4][2]<<'\n';
		return;
	}
	inline ll Get(int L,int R){//R<L
		ll Res=L+1;
		for(register int i=2;i<=R;++i){
			ll tmp=C[R-1][i-1];
			Res=(Res+((C[L+1][i]*tmp)%mod))%mod;
		}
//		cout<<Res<<endl;
		return Res;
	}
	void DP(int now){
		if(tr[now].size()==0){
			sz[now]=1;
			f[now]=1;
//			cout<<now<<"A :"<<f[now]<<endl;
			return;
		}else if(tr[now].size()==1){
//			cout<<now<<"A->"<<tr[now][0]<<endl;
			DP(tr[now][0]);
			sz[now]=sz[tr[now][0]]+1;
			f[now]=f[tr[now][0]];
//			cout<<now<<"B :"<<f[now]<<endl;
			return;
		}else{
//			cout<<now<<"B->"<<tr[now][0]<<endl;
			DP(tr[now][0]);
//			cout<<now<<"B->"<<tr[now][1]<<endl;
			DP(tr[now][1]);
			int L=max(sz[tr[now][1]],sz[tr[now][0]]),R=min(sz[tr[now][1]],sz[tr[now][0]]);
			f[now]=(((f[tr[now][0]]*f[tr[now][1]])%mod)*Get(L,R))%mod;
			sz[now]=sz[tr[now][0]]+sz[tr[now][1]]; 
			for(int i=2;i<tr[now].size();++i){
				int v=tr[now][i];
				DP(v);
			 	L=max(sz[now],sz[v]),R=min(sz[now],sz[v]);
				f[now]=(((f[now]*f[v])%mod)*Get(L,R))%mod;
				sz[now]+=sz[v];
			}
//			cout<<now<<"C :"<<f[now]<<endl;
			++sz[now];
			return;
		}
		
		return;
	}
	signed main(){
		init();
//		cout<<Get(3,2)<<endl;
		scanf("%d",&T);
		while(T--){
			scanf("%d",&n);
			memset(f,0,sizeof(f));
			memset(sz,0,sizeof(sz));
			for(register int i=1;i<=n;++i)tr[i].clear();
			for(register int i=1,K,next,x;i<=n;++i){
				scanf("%d",&K);
				next=x=0;
				for(register int j=1;j<=K;++j){
					scanf("%d",&x);
					if(j==1)tr[i].pb(x);
					else tr[next].pb(x);
					next=x;
				}
			}
			DP(1);
			printf("%lld\n",f[1]);
		}
		
		return 0;
	}
}
signed main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	NoFive::main();
	return 0;
}

