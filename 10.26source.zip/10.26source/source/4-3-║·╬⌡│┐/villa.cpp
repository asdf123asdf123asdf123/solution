#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	
	
	int main()
	{
		
		
		return 0;
	}
}
int main()
{
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	hxc::main();
}
