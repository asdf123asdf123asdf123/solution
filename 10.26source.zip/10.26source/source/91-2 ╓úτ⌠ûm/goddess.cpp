#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const ll INF=1e20;

namespace NoFive{
	const int N=1e5+7;
	int n;
	ll h[N<<1];
	ll m,Ans=INF;
	ll f[N<<1][2];
	signed main(){//50~100S
		srand(time(0));
		scanf("%d%lld",&n,&m);
		for(register int i=1;i<=n;++i){
			scanf("%lld",&h[i]);
			h[i+n]=h[i];
		}
		if(n<=5000){//50~60S
			for(register int s=1;s<=n;++s){
				memset(f,0x3f,sizeof(f));
				f[s][0]=f[s][1]=0;
				for(register int i=s+1;i<=n+s;++i){
					if(h[i-1]<h[i]){
						f[i][0]=min(f[i-1][0]+h[i]-h[i-1],f[i-1][1]+(h[i]-h[i-1])*(h[i]-h[i-1])+m);
						f[i][1]=min(f[i-1][1]+(h[i]-h[i-1])*(h[i]-h[i-1]),f[i-1][0]+h[i]-h[i-1]+m);
					}else{
						f[i][0]=min(f[i-1][0]+(h[i-1]-h[i])*(h[i-1]-h[i]),f[i-1][1]+h[i-1]-h[i]+m);
						f[i][1]=min(f[i-1][1]+h[i-1]-h[i],f[i-1][0]+(h[i-1]-h[i])*(h[i-1]-h[i])+m);
					}
					
				}
				Ans=min(Ans,min(f[n+s][0],f[n+s][1]));
			}
			printf("%lld\n",Ans);
			return 0;
		}
		Ans=INF;
		for(register int Random=1;Random<=555;++Random){
			memset(f,0x3f,sizeof(f));
			int s=rand()%n+1;
			f[s][0]=f[s][1]=0;
			for(register int i=s+1;i<=n+s;++i){
				if(h[i-1]<h[i]){
					f[i][0]=min(f[i-1][0]+h[i]-h[i-1],f[i-1][1]+(h[i]-h[i-1])*(h[i]-h[i-1])+m);
					f[i][1]=min(f[i-1][1]+(h[i]-h[i-1])*(h[i]-h[i-1]),f[i-1][0]+h[i]-h[i-1]+m);
				}else{
					f[i][0]=min(f[i-1][0]+(h[i-1]-h[i])*(h[i-1]-h[i]),f[i-1][1]+h[i-1]-h[i]+m);
					f[i][1]=min(f[i-1][1]+h[i-1]-h[i],f[i-1][0]+(h[i-1]-h[i])*(h[i-1]-h[i])+m);
				}
				
			}
			Ans=min(Ans,min(f[n+s][0],f[n+s][1]));
		}
		printf("%lld\n",Ans);
		return 0;
	}
}
signed main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	NoFive::main();
	return 0;
}

