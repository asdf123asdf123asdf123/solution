#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
int n,ans,a[1005];
map<long long,int>tong;
long long gcd(long long a,long long b)
{
	if(b==0)return a;
	return gcd(b,a%b);
}
void dfs(int sum,int k,int now)
{
	if(sum==0)
	{
//		ans++;
		long long GCD=1;
		for(int i=1;i<now;i++)
		{
			GCD=GCD*a[i]/gcd(GCD,a[i]);
//			cout<<a[i]<<' ';
		}
//		cout<<'\n';
		if(!tong[GCD])
		{
//			for(int i=1;i<now;i++)cout<<a[i]<<' ';
//			cout<<'\n';
			tong[GCD]=1;
			ans++;
		}
		return;
	}
	for(int i=k;i<=sum;i++)
	{
		a[now]=i;
		dfs(sum-i,i,now+1);
	}
	return;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n;
	dfs(n,1,1);
	cout<<ans;
	return 0;
}
}
int main(){gzx::main();return 0;}
