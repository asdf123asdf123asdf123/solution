#include<bits/stdc++.h>
#define LL long long
using namespace std;
namespace last_context{
	const int maxn=10005;
	int a[maxn];
	int main(){
		int n;
		LL m;
		scanf("%d%lld",&n,&m);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		LL ans=0;
		for(int i=1;i<=n;i++)ans+=abs(a[i]-a[(i+1)%n]);
		cout<<ans+m<<'\n';
		return 0;
	}
}
int main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	last_context::main();
	return 0;
}
//while(1) stO ���� Orz; 
