#include<bits/stdc++.h>
using namespace std;
namespace ld{
	const int mod=10007;
	int n;
	struct edge{
		int next;
		int to;
	}ed[1005];int ed_cnt;
	int h[1005];
	void add_edge(int x,int y){
		ed[++ed_cnt]={h[x],y};
		h[x]=ed_cnt;
	} 

	int vis[1005];
	int ans=0;
	void dfs(int now){
		if(now==n){
			ans++;
			return;
		}
		for(int u=1;u<=n;u++){
			if(vis[u])continue;
			int bj=1;
			for(int i=h[u];i;i=ed[i].next){
				int v=ed[i].to;
				if(!vis[v]){
					bj=0;
					break;
				}
			}
			if(bj){
				vis[u]=1;
				dfs(now+1);
				vis[u]=0;
			}
		}
	}
	int main(){
		freopen("lineup.in","r",stdin);
		freopen("lineup.out","w",stdout);			
		int t;
		scanf("%d",&t);
		while(t--){
			scanf("%d",&n);
			ed_cnt=0;
			memset(h,0,sizeof(h));
			memset(vis,0,sizeof(vis));
			ans=0;
			for(int i=1;i<=n;i++){
				int k;
				scanf("%d",&k);
				int last;
				for(int j=1;j<=k;j++){
					int x;
					scanf("%d",&x);
					add_edge(x,i);
					if(j>1)add_edge(x,last);
					last=x;
				}
			}
			dfs(0);
			cout<<ans%10007<<'\n';				
		}

		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}
