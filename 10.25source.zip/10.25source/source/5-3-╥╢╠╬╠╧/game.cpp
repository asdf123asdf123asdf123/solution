#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	int ans=0;
	map<int,int>mp;
	void dfs(int u,int lcm,int ls)
	{
		if(!u)
		{
			
			if(!mp[lcm])ans++;
			mp[lcm]=1;
			return ;
		}
		for(int i=min(u,ls);i;i--)
		{
			dfs(u-i,lcm*i/__gcd(lcm,i),i);
		}
	}
	int main()
	{
		int n;
		scanf("%d",&n); 
		dfs(n,1,n);
		cout<<ans;
		return 0;
	}
} 

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	akak::main();
	return 0;
}
