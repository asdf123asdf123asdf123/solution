#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
using namespace std;
namespace zzy{
	const int maxn=50;
	char a[maxn][maxn];
	int vis[maxn][maxn][maxn];
	int tmp[maxn][maxn];
	int n,m,t;
	int sx,sy;
	double dis(int x1,int y1,int x2,int y2){
		return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	}
	double ans=0.0;
	int x2[5]={0,0,1,0,-1};
	int y2[5]={0,1,0,-1,0};
	void dfs(int x,int y,int cnt){
		if(vis[x][y][cnt])return ;
		if(cnt>t)return ;
		vis[x][y][cnt]=1;
		if(cnt==0)tmp[x][y]=1;
		ans=max(ans,dis(sx,sy,x,y));
		for(int i=1;i<=4;i++){
			int dx=x+x2[i];
			int dy=y+y2[i]; 
			if(dx>=1&&dx<=n&&dy>=1&&dy<=m){
				if(a[dx][dy]=='1'){
					dfs(dx,dy,cnt+1);
				}else{
					dfs(dx,dy,cnt);
				}
			}
			
		}
	}
	int main(){
		freopen("maxlength.in","r",stdin);
		freopen("maxlength.out","w",stdout);
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				memset(vis,0,sizeof(vis));
				sx=i,sy=j;
				if(dis(sx,sy,n,m)<=ans&&dis(sx,sy,1,1)<=ans)continue;
				dfs(i,j,(a[i][j]=='1')?1:0);
			}
		}
		printf("%.6lf",ans);
		
		return 0;
	}
}
int main(){
	zzy::main();
	return 0;
}
//1136 KB
