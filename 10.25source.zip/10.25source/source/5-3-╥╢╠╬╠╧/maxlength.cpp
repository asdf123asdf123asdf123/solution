#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	char A[40][40];
	int D[1810][4],T[40][40];
	int dx[7]={0,1,-1,0,0};
	int dy[7]={0,0,0,-1,1};
	double ans=0; 
	int n,m,t;
	void bfs(int x,int y)
	{
		int l=1,r=1;
		D[l][0]=x;
		D[l][1]=y;
	//	cout<<A[x][y]<<endl;
		D[l][2]=A[x][y]-'0';
		while(l<=r)
		{
			if(D[l][2]>=T[D[l][0]][D[l][1]]||D[l][2]>t)
			{
				l++;
				continue;
			}
		//	if(x*y==1)cout<<D[l][0]<<' '<<D[l][1]<<' '<<D[l][2]<<endl;
			T[D[l][0]][D[l][1]]=D[l][2];
			ans=max(ans,sqrt((x-D[l][0])*(x-D[l][0])+(y-D[l][1])*(y-D[l][1])));
			for(int i=1;i<=4;i++)
			{
				int wx=dx[i]+D[l][0],wy=dy[i]+D[l][1];
				int wz=A[wx][wy]-'0'+D[l][2];
				if(wx>n||wx<=0||wy>m||wy<=0||wz>t||T[wx][wy]<=wz)continue;
			//	cout<<wx<<endl;
				D[++r][0]=wx;
				D[r][1]=wy;
				D[r][2]=wz;
			}
			l++;
		}
	}
	int main()
	{

		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{

				A[i][j]=getchar();
				while(A[i][j]!='0'&&A[i][j]!='1')
				{
					A[i][j]=getchar();
				}
			}
		}
		
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				memset(T,127,sizeof(T));
				bfs(i,j);
				
				
			}
		}
		printf("%0.6lf",ans);
		return 0;
	}
} 
int main()
{
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	akak::main();
	return 0;
}
