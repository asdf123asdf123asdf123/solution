#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 15;
	int a, b, numa, numb, ans;
	int aa[MAXN], bb[MAXN];
	int f[MAXN][MAXN][2][2][2];
	bool check(int n){
		int tmp = -11;
		while(n){
			int t = n % 10;
			if(abs(tmp - t) <= 1) return 0;
			tmp = t;
			n /= 10;
		}
		return 1;
	}
	void solve(){
		int ans = 0;
		for(int i = a;i <= b;i++){
			if(check(i)) ans++;
		}
		printf("%d", ans);
	}
	int s[MAXN];
	/*void dfs(int now, bool f, int maxs, int nows, int aa[], int numb){
		if(!now) return ;
		for(int i = numb;i > 0;i--){
			if(s[i] != aa[i]){
				if(s[i] > aa[i]) return ;
				break;
			}
		}
		if(f){
			int tmp = 1;
			for(int i = 1;i <= now;i++) tmp *= 10;
			ans += min((1 + nows) * tmp - 1, maxs) - nows * tmp;
			return ;
		}
		for(int i = 0;i <= 9;i++){
			s[now] = i;
			if(abs(s[now + 1] - i) < 2) dfs(now - 1, 0, maxs, nows * 10 + i, aa, numb);
			else dfs(now - 1, 1, maxs, nows * 10 + i, aa, numb);
		}
		s[now] = 0;
	}*/
	int main(){
		scanf("%d%d", &a, &b);
		/*if(b - a <= 1000000){
			solve();
			return 0;
		}
		while(a){
			aa[++numa] = a % 10;
			a /= 10;
		}
		while(b){
			bb[++numb] = b % 10;
			b /= 10;
		}
		if(aa[numb] == bb[numb]){
			f[numb][aa[numb]][0][0][1] = 1;
		}
		else{
			f[numb][aa[numb]][0][1][1] = 1;
			f[numb][bb[numb]][1][0][1] = 1;
		}
		for(int i = aa[numb] + 1;i < bb[numb];i++){
			f[numb][i][1][1][1] = 1;
		}
		for(int i = numb;i > 1;i--){
			if(aa[i - 1] == bb[i - 1]){
				if(abs(aa[i] - aa[i - 1]) < 2){
					f[i - 1][aa[i - 1]][0][0][0] = f[i][aa[i]][0][0][0];
				} 
			} 
			for(int j = 0;j <= 9;j++){
				for(int k = 0;k <= 9;k++){
					f[i - 1][k][1][1][1] += f[i][j][1][1][1];
					f[i - 1][k][1][1][0] += f[i][j][1][1][1]; 
				}
			}
		}
		dfs(numb, 0, b, 0, bb, numb);
		int mtp = ans;
		ans = 0;
		dfs(numa, 0, a - 1, 0, aa, numa);
		printf("%d", mtp - ans);*/
		solve();//while(1);
		return 0;
	}
} 
int main(){
	freopen("windy.in", "r", stdin);
	freopen("windy.out", "w", stdout);
	return ac::main();
}//668KB
