#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int biao[1005]={0,
				1,
				2,
				3,
				4,
				6,
				6,
				9,
				11,
				14,
				16,
				20,
				23,
				27,
				31,
				35,
				43,
				47,
				55,
				61,
				70,
				78,
				88,
				98,
				111,
				123,
				136,
				152,
				168,
				187,
				204,
				225,
				248,
				271,
				296,
				325,
				356,
				387,
				418,
				455,
				495,
				537,
				581,
				629,
				678,
				732,
				787,
				851,
				918,
				986,
				1056,
				1133,
				1217,
				1307,
				1399,
				1498,
				1600,
				1708,
				1823,
				1950,
				2083,
				2218,
				2356,
				2506,
				2671,
				2842,
				3025,
				3211,
				3409,
				3610,
				3830,
				4067,
				4316,
				4568,
				4829,
				5105,
				5406,
				5722,
				6051,
				6393,
				6746,
				7112,
				7506,
				7928,
				8372,
				8821,
				9282,
				9770,
				10293,
				10845,
				11423,
				12013,
				12621,
				13255,
				13930,
				14653,
				15410,
				16176,
				16960,
				17785,
				18663,	
	};
	int n;
	unordered_map<int,int> tong;
	int lcm(int x,int y){
		return x*y/__gcd(x,y);
	}
	int ans;
	
	unordered_map<int,int>bj[1005];
	void dfs(int now,int sum,int last,int res){
		if(sum==n){
			if(tong[res])return;
			ans++;
			tong[res]=1;
			
			return;
		}	
		for(int i=last;i<=n-sum;i++){
			int now_l=lcm(res,i);
			if(bj[sum+i][now_l])continue;
			bj[sum+i][now_l]=1;
			dfs(now+1,sum+i,last,now_l);
		}			
	}
	int main(){
		freopen("game.in","r",stdin);
		freopen("game.out","w",stdout);			
		scanf("%d",&n);
		if(n<=100)
			cout<<biao[n]<<'\n';
		else{
			dfs(1,0,1,1);
			cout<<ans<<'\n';
		}
		return 0;
	}
}
int main(){
	ld::main();
	return 0;
}
