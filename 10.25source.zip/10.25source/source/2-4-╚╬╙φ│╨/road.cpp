#include<bits/stdc++.h>
using namespace std;
namespace FireBird{
	int n,t,mod=2009;
	struct edge{
		int to,next,val;
	}ed[10102];
	int head[10102],cnt=0;
	void add_edge(int x,int y,int w){
		ed[++cnt].next=head[x];
		ed[cnt].to=y;
		ed[cnt].val=w;
		head[x]=cnt;
	}
	int c[12][12],ans=0,a[1000002];
	bool b[1000005];
	void dfs(int u,int fa,int sum){
		if(sum>t){
			return ;
		}
		if(u==n&&sum==t){
			ans++;
			return ;
		}
		for(int i=head[u];i;i=ed[i].next){
			int v=ed[i].to;
			if(v==fa){
				continue;
			}
			dfs(v,u,sum+ed[i].val);
		}
	}
	int main(){
		string s;
		scanf("%d%d",&n,&t);
		for(int i=1;i<=n;i++){
			cin>>s;
			for(int j=1;j<=n;j++){
				add_edge(i,j,s[j-1]-'0');
			}
		}
		dfs(1,-1,0);
		printf("%d",ans%mod);
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	FireBird::main();
	return 0;
}
