#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const int INf=1e9+7;

namespace NoFive{
	const int N=5e6+7;
	int n,m;
	int arr[N],car[N];
	int G=0,B=0;
	int sumG[N],sumB[N];
	int f[1005][1005],pre1[1005][1005],pre2[1005][1005];
	signed main(){
		scanf("%d%d",&n,&m);
		for(register int i=1;i<=n;++i)
			scanf("%1d",&arr[i]),sumG[i]=sumG[i-1]+(arr[i]==0),sumB[i]=sumB[i-1]+(arr[i]==1);
//		cout<<G-B<<" "<<Anss<<endl;
		if(n<=1000){//40~50S
			for(register int i=1;i<=n;++i)
				f[1][i]=abs(sumG[i]-sumB[i]),pre1[1][i]=pre2[1][i]=0;
			for(register int i=2;i<=m;++i){
				for(register int j=i;j<=n;++j){
					f[i][j]=0x3f3f3f3f;
					for(register int k=i-1;k<j;++k){
						int val=max(f[i-1][k],abs((sumG[j]-sumG[k])-(sumB[j]-sumB[k])));
						if(f[i][j]==val){
							pre1[i][j]=k;
						}
						if(f[i][j]>val){
							pre1[i][j]=pre2[i][j]=k;
							f[i][j]=val;
						}
					}                           
				}
			}
			int now=n;car[0]=0;
			for(register int i=m;i>=1;i--){
				car[++car[0]]=now-pre2[i][now];
				now=pre2[i][now];
			}
			for(register int i=car[0];i>=1;i--)
				printf("%d ",car[i]);
			printf("\n");
			now=n;car[0]=0;
			for(register int i=m;i>=1;i--){
				car[++car[0]]=now-pre1[i][now];
				now=pre1[i][now];
			}
			for(register int i=car[0];i>=1;i--)
				printf("%d ",car[i]);
			printf("\n");
			return 0;
		}
		
		return 0;
	}
}
signed main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	NoFive::main();
	return 0;
}

