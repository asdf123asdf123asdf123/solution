#include<bits/stdc++.h>
using namespace std;
namespace Main {
	const int N = 1000 + 5;
	int n;
	set<int> f[N];
	int gcd(int x, int y) {
		return !y ? x : gcd(y, x % y);
	}
	int lcm(int x, int y) {
		if(!x || !y) return x | y;
		return x / gcd(x, y) * y;
	}
	//���˼������ļ��� 
	bool merge(set<int> &res, set<int> &x, int y) {
//		res.clear();
		bool flag = 0;
		for (auto &it: x) {
			if(res.find(lcm(it, y)) == res.end()) flag = 1;
			res.insert(lcm(it, y));
		}
		return flag;
	}
	int main() {
		scanf ("%d", &n);
		f[0].insert(0);
		for (int i = 1; i <= n; ++i) {
			f[i] = f[i - 1];
			if(i!=1)f[i].insert(i);
			cout << i << '\n';
			for (int j = i - 2; j >= 1; --j) {
				if(!merge(f[i], f[j], i - j))cout << j << ' ' <<i - j << '\n';
			}
		}
		cout << f[n].size() << '\n';
//		while(1);
		return 0;
	}
}
int main() {
//	int s=clock();
	freopen("game.in", "r", stdin);
//	freopen("game.out", "w", stdout);
	Main :: main();
//	int t=clock();
//	cerr<<(t-s);
	return 0;
} 
//meb:18mb
