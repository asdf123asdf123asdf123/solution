#include<bits/stdc++.h>
using namespace std;
namespace Main {
	const int N = 5000000 + 5; 
	int n, m;
	int a[N], s[N];
	int calc(int l, int r) {
		//����[l, r]����Ů����֮�� 
		int b = s[r] - s[l - 1];
		int g = r - l + 1 - b;
		return abs(b - g);
	}
	int f[1005][1005];
	int pre_f[1005][1005], pre_g[1005][1005];
	//ǰi����,���ֳ�����k�ε���С���� 
	vector<int> v;
	void print() {
		for (int i = 0; i < (int)v.size(); ++i) {
			printf("%d%c", v[i], i == (int)v.size() - 1 ? '\n' : ' ');
		}
	}
	void hyz() { 
		int x = n, y = m;
		while(y > 0) {
			int nx = pre_g[x][y];
			//[nx + 1, x]
			v.emplace_back(x - nx);
			x = nx;
			--y;
		} 
		reverse(v.begin(), v.end());
		print();
	}
	void yhy() {
		v.clear(); 
//		cout << f[n][m] << '\n';
		int x = n, y = m;
		while(y > 0) {
			int nx = pre_f[x][y];
			//[nx + 1, x]
			v.emplace_back(x - nx);
			x = nx;
			--y;
		} 
		reverse(v.begin(), v.end());
		for (int i = 0; i < (int)v.size(); ++i) {
			printf("%d", v[i]);
			if(i != (int)v.size() - 1) printf(" ");
		}
	}
	int main() {
		scanf ("%d%d", &n, &m);
		for (int i = 1; i <= n; ++i) {
			scanf ("%1d", &a[i]);
			s[i] = s[i - 1] + a[i];
		}
		for (int i = 1; i <= n; ++i) {
			for (int k = 1; k <= min(i, m); ++k) {
				f[i][k] = 1e9;
				for (int j = k; j <= i; ++j) {
					//[j, i]
					//1, j - 1 >= k - 1;
					//j >= k;
					int val = max(f[j - 1][k - 1], calc(j, i));
					if(val == 1e9) continue;
					if(f[i][k] > val) {
						f[i][k] = val;
						pre_f[i][k] = j - 1;
						pre_g[i][k] = j - 1;
					}
					else if(f[i][k] == val) {
						pre_f[i][k] = j - 1;
					}
				}
			}
		}
		hyz();
		yhy();
		return 0;
	}
}
int main() {
	freopen("villa.in", "r", stdin);
	freopen("villa.out", "w", stdout);
	Main::main();
	return 0;
} 
