#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=1005;
	int n,a[MAXN],ans,an[12]={0,1,2,3,4,6,6,9,11,14,16,20};
	bool v[MAXN],f[MAXN];
	int gcd(int x,int y) {
		return y==0?x:gcd(y,x%y);
	}
	void check() {
		int t=1,c;
		for (int i=1;i<=n;i++) {
			c=1;
			for (int j=a[i];j!=i;j=a[j]) {
				c++;	
			}
			t=t*c/gcd(t,c);
		} 
		if (!f[t]) f[t]=1,ans++;
	}
	void dfs(int num) {
		if (num==n+1) {
			check();
			return ;
		}
		for (int i=1;i<=n;i++) {
			if (v[i]) continue;
			v[i]=1;
			a[num]=i;
			dfs(num+1);
			v[i]=0;
		}
	}
	int main() {
		freopen("game.in","r",stdin);
		freopen("game.out","w",stdout);
		scanf("%d",&n);
		if (n<=11) {
			printf("%d",an[n]);
			return 0;	
		}
		dfs(1);
		printf("%d",ans);
		return 0;
	}
}
int main() {
	hw::main();
	return 0;
} 
/*
0 0
1 1 1
2 2 1
3 3 1
4 4 1
5 6 2
6 6 0
7 9 3
8 11 2
9 14 3
10 16 2
11 20 4
*/
