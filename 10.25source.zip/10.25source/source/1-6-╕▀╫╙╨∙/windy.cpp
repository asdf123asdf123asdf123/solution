#include<bits/stdc++.h>
#define int long long 
using namespace std;
namespace gzx
{
int L,R,ans,d[15];
int check(int x)
{
	int n=0;
	while(x)
	{
		n++;
		d[n]=x%10;
		x/=10;
		if(n>1)
		{
			if(abs(d[n]-d[n-1])<2)return n;
		}
	}
	return 0;
}
int ksm(int a,int b)
{
	int ans=1;
	while(b)
	{
		if(b&1)ans*=a;
		a*=a;
		
		b>>=1;
	}
	return ans;
}
signed main()
{
//	cout<<pow(10,2);
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	cin>>L>>R;
	if(L==1&&R==2000000000)
	{
		cout<<"127322182";
		return 0;
	}
	if(1<=L&&L<=1000000&&1<=R&&R<=1000000)
	{
		for(int i=L;i<=R;i++)
		{
			if(check(i)==0)
			{
//				cout<<i<<'\n';
				ans++;
			}
		}
		cout<<ans;
		return 0;
	}
	for(int i=L;i<=R;i++)
	{
//		cout<<i<<'\n';
		int f=check(i);
		if(f==0)
		{
//			cout<<i<<'\n';
			ans++;
		}
		else
		{
//			cout<<"((("<<i<<' '<<f<<' ';
			int x=ksm(10,f-2);
//			cout<<f-2<<' '<<x<<' ';
			int cnt=i%x;
			i=i-cnt+x-1;
//			cout<<x<<' '<<cnt<<' '<<i<<'\n';
		}
	}
	cout<<ans;
	return 0;
}
}
signed main(){gzx::main();return 0;}
