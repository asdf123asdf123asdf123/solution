#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int t,n,a[1001][1001],c[1001][1001],p=10007,f[1001],sz[1001],d[1001],v[1001];
	void dfs(int x){
		f[x]=1;
		sz[x]=1;
		for(int i=1;i<=a[x][0];i++){
			int y=a[x][i];
			dfs(y);
			sz[x]+=sz[y];
		//	cout<<x<<" "<<y<<" "<<sz[x]<<" "<<sz[y]<<endl;
			f[x]=(f[x]*f[y]%p)*max(1,c[sz[x]-2][sz[y]])%p;
		}
	}
	int main(){
		c[0][0]=1;
		for(int i=1;i<=1000;i++){
			c[i][0]=1;
			for(int j=1;j<=i;j++){
				c[i][j]=(c[i-1][j]+c[i-1][j-1])%p;
			}
		}
		scanf("%d",&t);
		while(t--){
			scanf("%d",&n);
			for(int i=1;i<=n;i++){
				scanf("%d",&a[i][0]);
//				if(a[i][0]>1){
//					printf("\\\\\\\\");
//					break;
//				}
				for(int j=1;j<=a[i][0];j++){
					scanf("%d",&a[i][j]);
				}
			}
			if(n>9){
				dfs(1);
	//			for(int i=1;i<=n;i++){
	//				cout<<f[i]<<" "; 
	//			}
	//			cout<<endl;
				printf("%d\n",f[1]);
				continue;	
			}
			int ans=0;
			for(int i=1;i<=n;i++){
				d[i]=i;
			}
			do{
				for(int i=1;i<=n;i++){
					v[d[i]]=i;
				}
				int f=0;
				for(int i=1;i<=n;i++){
					int ff=0;
					for(int j=1;j<=a[i][0];j++){
						if(j==1){
							if(v[i]>v[a[i][j]]){
								ff=1;
								break;
							}
						}else{
							if(v[a[i][j]]<v[a[i][j-1]]){
								ff=1;
								break;
							}
						}
					}
					if(ff){
						f=1;
						break;
					}
				}
				if(!f){
					ans++;
				}
			}while(next_permutation(d+1,d+1+n));
			printf("%d\n",ans);
		}
		return 0;
	}
}
int main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	ldm::main();
	return 0;
}
//8m 256m
