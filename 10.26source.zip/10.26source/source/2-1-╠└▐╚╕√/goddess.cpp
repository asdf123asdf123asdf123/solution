#include<cstdio>
#include<iostream>
typedef long long ll;
using namespace std;
namespace Zimu_Zhao{
	const int N = 1e4;
	int a[2 * N + 10];
	ll f[2][2];
	int n, m;
	inline int read(){
		int x = 0, f = 1;
		char ch = getchar();
		while(!isdigit(ch)){
			if(ch == '-')
				f = -1;
			ch = getchar();
		}
		while(isdigit(ch)){
			x = (x << 1) + (x << 3) + ch - '0';
			ch = getchar();
		}
		return x * f;
	}
	int main(){
		n = read(), m = read();
		for(int i = 1; i <= n; i++)
			a[i + n] = a[i] = read();
		ll ans = 0x7fffffffffffffff / 2;
		for(int i = 1; i <= n; i++){
			f[0][0] = f[0][1] = 0;
			for(int j = 1; j <= n; j++){
				if(a[i + j - 1] < a[i + j]){
					f[j & 1][0] = min(f[(j - 1) & 1][0] + 1ll * (a[i + j - 1] - a[i + j]) * (a[i + j - 1] - a[i + j]), f[(j - 1) & 1][1] + abs(a[i + j - 1] - a[i + j]) + m);
					f[j & 1][1] = min(f[(j - 1) & 1][0] + 1ll * (a[i + j - 1] - a[i + j]) * (a[i + j - 1] - a[i + j]) + m, f[(j - 1) & 1][1] + abs(a[i + j - 1] - a[i + j]));
				}
				else{
					f[j & 1][0] = min(f[(j - 1) & 1][1] + 1ll * (a[i + j - 1] - a[i + j]) * (a[i + j - 1] - a[i + j]) + m, f[(j - 1) & 1][0] + abs(a[i + j - 1] - a[i + j]));
					f[j & 1][1] = min(f[(j - 1) & 1][1] + 1ll * (a[i + j - 1] - a[i + j]) * (a[i + j - 1] - a[i + j]), f[(j - 1) & 1][0] + abs(a[i + j - 1] - a[i + j]) + m);
				}
			}
			ans = min(ans, min(f[n & 1][0], f[n & 1][1]));
		}
		printf("%lld", ans);
		return 0;
	}
}
int main(){
	freopen("goddess.in", "r", stdin);
	freopen("goddess.out", "w", stdout);
	return Zimu_Zhao::main();
}
//1MB
