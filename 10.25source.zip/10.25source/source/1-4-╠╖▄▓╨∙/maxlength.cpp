#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define N 35
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int n,m,t,f[N][N];
	char ch[N];
	bl s[N][N],vis[N][N];
	double ans;
	int data[4][2]{
	{
		1,0
	},
	{
		0,1
	},
	{
		-1,0
	},
	{
		0,-1
	}
	};
	struct node{
		int x,y,val;
		bl operator<(const node b)const{
			return val>b.val;
		}
	};
	priority_queue<node> q;
	il vd dij(int sx,int sy){
		memset(f,0x3f,sizeof f);
		memset(vis,0,sizeof vis);
		f[sx][sy]=s[sx][sy];
		q.push((node){
			sx,sy,f[sx][sy]
		});
		while(!q.empty()){
			int x=q.top().x,y=q.top().y;
			q.pop();
			if(vis[x][y]) continue;
			vis[x][y]=1;
			for(int i=0;i<4;i++){
				int dx=x+data[i][0],dy=y+data[i][1];
				if(!(dx>=1&&dx<=n&&dy>=1&&dy<=m)) continue;
				if(f[dx][dy]>f[x][y]+s[dx][dy]){
					f[dx][dy]=f[x][y]+s[dx][dy];
					if(!vis[dx][dy]){
						q.push((node){
							dx,dy,f[dx][dy]
						});
					}
				}
			}
		}
	}
	il vd get_ans(int x,int y,int i,int j){
		ans=max(ans,sqrt(1.0*(1ll*(i-x)*(i-x)+1ll*(y-j)*(y-j))));
	}
	signed main(){
		n=read(),m=read(),t=read();
		for(int i=1;i<=n;i++){
			scanf("%s",ch+1);
			for(int j=1;j<=m;j++){
				if(ch[j]=='1') s[i][j]=1;
				else s[i][j]=0;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				dij(i,j);
				for(int l=1;l<=n;l++){
					for(int r=1;r<=m;r++){
						if(f[l][r]<=t){
							get_ans(i,j,l,r);
						}
					}
				}
			}
		}
		printf("%.6lf",ans);
		return 0;
	}
}
signed main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	TYX_YNXK::main();
	return 0;
}
