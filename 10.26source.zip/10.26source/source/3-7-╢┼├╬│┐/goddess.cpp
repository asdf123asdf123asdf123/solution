#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	cout<<1<<'\n';
	return 0;
}
  
