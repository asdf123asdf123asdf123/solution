#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
int n,m;
bool cmp(int a[],int b[])
{
	for(int i=1;i<=m;i++)
	{
		if(a[i]>b[i])return 1;
		if(a[i]<b[i])return 0;
	}
	return -1;
}
int sum=0x7ffffff,ans1[105],ans2[105],a[105];
string s;
void dfs(int k,int cnt)
{
	if(k==m+1&&cnt!=0)return;
	if(k==m+1&&cnt==0)
	{
//		for(int i=1;i<=m;i++)
//		{
//			cout<<a[i]<<' ';
//		}
//		cout<<'\n';
		int x=0,maxn=0;
		for(int i=1;i<=m;i++)
		{
			int tmp=0;
//			cout<<x+1<<' '<<x+a[i]<<'\n';
			for(int j=x+1;j<=x+a[i];j++)
			{
				if(s[j]=='1')tmp++;
				else tmp--;
			}
			tmp=abs(tmp);
//			cout<<tmp<<" 00\n";
			maxn=max(maxn,tmp);
			x+=a[i];
		}
//		cout<<maxn<<'\n';
		if(maxn<sum)
		{
			sum=maxn;
			for(int i=1;i<=m;i++)ans1[i]=ans2[i]=a[i];
		}
		if(maxn==sum)
		{
			if(cmp(ans1,a)==1)
			{
				for(int i=1;i<=m;i++)ans1[i]=a[i];
			}
			if(cmp(ans2,a)==0)
			{
				for(int i=1;i<=m;i++)ans2[i]=a[i];
			}
		}
		return;
	}
//	if(k==m)
//	{
//		if(cnt)dfs(k+1,cnt);
//		return;
//	}
	for(int i=1;i<=cnt;i++)
	{
		a[k]=i;
		dfs(k+1,cnt-i);
	}
}
int main()
{
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	cin>>n>>m>>s;
	for(int i=n;i>=1;i--)s[i]=s[i-1];
	dfs(1,n);
//	cout<<sum<<'\n';
	for(int i=1;i<=m;i++)cout<<ans1[i]<<' ';
	cout<<'\n';
	for(int i=1;i<=m;i++)cout<<ans2[i]<<' ';
//	while(1);
	return 0;
}
}
int main(){gzx::main();return 0;}
//712kb
