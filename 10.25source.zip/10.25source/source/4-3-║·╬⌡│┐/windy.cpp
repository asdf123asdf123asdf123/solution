#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	int a , b , ans;
	
	bool check(int n)
	{
		int t0 = n%10 , t1;
		n /= 10;
		bool flag = 1;
		while(n)
		{
			t1 = n%10;
			if (abs(t1-t0) < 2){flag = 0;break;}
			n /= 10;
			t0 = t1;
		}
		return flag;
	}
	
	int main()
	{
		scanf("%d%d",&a,&b);
		for (int i = a;i <= b;i++)
			if (check(i))	ans++;
		cout<<ans<<'\n';
		return 0;
	}
}
int main()
{
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
//	while(1);
	hxc::main();
}
//8mb/256mb
