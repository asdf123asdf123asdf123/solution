/*
#include <bits/stdc++.h>
#define MAXN 15
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	
	template <typename T> inline void Read(T &in){
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	long long ina;
	long long inb;
	
	long long f[MAXN][15];
	long long g[MAXN][15];
	
	inline void Init(){
		for (int i=0;i<=9;i++) f[1][i]=1, g[1][i]=i;
		for (int i=2;i<=MAXN;i++){
			for (int j=0;j<=9;j++){
				for (int k=0;k<=j-2;k++) f[i][j]+=f[i-1][k];
				for (int k=j+2;k<=9;k++) f[i][j]+=f[i-1][k];
				g[i][j]=f[i][j]+g[i][j-1];
			}
		}
		return;
	}
	

	inline long long Ask(long long k){
		long long now=0;
		long long cnt=1;
		while (k){
			now+=g[cnt][k%10];
			cnt++;
			k/=10;
		}
		return now;
	}
	
	int main(){
		Init ();
		//cin>>ina>>inb;
		//cout<<Ask(1)<<" "<<Ask(2)<<endl;
		//printf ("%lld\n", Ask(inb)-Ask(ina-1));
		cout<<f[11][1]<<endl;
		return 0;
	}
}

int main(){
	return wzy::main();
}
369900588
*/
/*
#include <bits/stdc++.h>
#include <windows.h>
#define MAXN 20000005
using namespace std;

//char buf[1<<21];
//char* p1;
//char* p2;
//#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in){
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	long long ina;
	long long inb;
	
	struct node{
		long long a;
		long long b;
		long long c;
	};
	
	node list[MAXN];
	int l;
	int top;
	long long real[MAXN];
	int size;
	
	inline long long Qpow(long long a, long long b){
		long long now=1;
		while (b){
			if (b&1) now*=a;
			a*=a;
			b>>=1;
		}
		return now;
	}
	
	double _;
	
	
	
	int main(){
		for (int i=1;i<=9;i++) list[i+1]=(node){i, i, 1};
		l=1;
		top=10;
		while (top<9000000){
			node now=list[l];
			l++;
			for (int i=0;i<=9;i++){
				if (abs(i-now.b)>=2){
					list[++top]={now.a+i*Qpow(10, now.c), i, now.c+1};
				}
			}
		}
		for (int i=1;i<=top;i++) real[i]=list[i].a;
		sort (real+1, real+top+1);
		size=unique(real+1, real+top+1)-real;
		cout<<size<<endl<<clock()-_<<endl;
		cin>>ina>>inb;
		
		return 0;
	}
}

int main(){
	wzy::_=clock();
	return wzy::main();
}
*/
#include <bits/stdc++.h>
using namespace std;

namespace wzy{
	
	long long ina;
	long long inb;
	
	int f[2000005];
	
	bool Check(long long k){
		int las=15;
		while (k){
			if (abs(k%10-las)<2) return 0;
			las=k%10;
			k/=10;
		}
		return 1;
	}
		
	int main(){
		for (int i=1;i<=1000000;i++){
			f[i]=f[i-1]+Check(i);
		}
		cin>>ina>>inb;
		cout<<f[inb]-f[ina-1]<<endl;
		return 0;
	}
}

int main(){
	freopen ("windy.in", "r", stdin);
	freopen ("windy.out", "w", stdout);
	return wzy::main();
}
