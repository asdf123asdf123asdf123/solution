#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 100005;
	int n, sum, now, ans;
	int prime[MAXN], vis[MAXN], num;
	int main(){
		scanf("%d", &n);
		for(int i = 2;i <= 100000;i++){
			if(!vis[i]) prime[++num] = i;
			for(int j = 1;j <= num && 1ll * i * prime[j] <= n;j++){
				vis[i * prime[j]] = 1;
				if(i % prime[j] == 0) break;
			}
		}
		//printf("%d\n", num);
		//for(int i = 1;i <= num;i++) printf("%d ", prime[i]);
		for(int i = n + 1;i <= 10 * n * n;i++){
			sum = 0;
			int tmp = i;
			for(int j = 1;j <= num && tmp;j++){
				now = 1;
				//printf("%d %d\n", j, prime[j]);
				while(tmp % prime[j] == 0 && tmp){
					now *= prime[j];
					tmp /= prime[j];
				}
				sum += now == 1 ? 0 : now; 
			}
			if(sum <= n){
				//printf("%d %d\n", i, sum);
				ans++;
			} 
		}
		printf("%d", n + ans);//while(1);
		return 0;
	}
} 
int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	return ac::main();
}//1MB
