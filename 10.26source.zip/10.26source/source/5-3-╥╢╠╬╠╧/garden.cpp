#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	int A[100010];
	long long dis(long long x,long long y,long long a,long long b)
	{
		return abs(x-a)+abs(y-b);
	}
	int ef(int x,int n)
	{
		int l=0,r=n,ans;
		while(l<=r)
		{
			int mid=(l+r)>>1;
			if(A[mid]<x)
			{
				ans=mid;
				l=mid+1; 
			}
			else r=mid-1;
		}
		return ans;
	}
	int main()
	{
		int n;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&A[i]);
		}
		sort(A+1,A+1+n);
//		for(int i=1;i<=n;i++)
//		{
//			cout<<A[i]<<endl;
//		}
		A[0]=-1e9;
		int m;
		scanf("%d",&m);
		for(int i=1;i<=m;i++)
		{
			long long a,b,x,y;
			scanf("%lld%lld%lld%lld",&x,&y,&a,&b);
			
			if(y*b>0)cout<<dis(x,y,a,b)<<'\n';
			else
			{
				int l=ef(x,n);
				int r=l+1;
			//	if(i==1)cout<<l<<' '<<r<<endl;
				if(x>a)swap(a,x);
				if((A[l]>=x&&A[l]<=a)||(A[r]>=x&&A[r]<=a))cout<<dis(x,y,a,b)<<'\n';
				else
				{
					cout<<min(dis(A[l],0,x,y)+dis(A[l],0,a,b),dis(A[r],0,x,y)+dis(A[r],0,a,b))<<'\n';
				}
			}
		}
		return 0;
	}
}
int main()
{
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	akak::main();
	return 0;
} 
