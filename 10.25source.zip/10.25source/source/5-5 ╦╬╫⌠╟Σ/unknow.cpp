#include<bits/stdc++.h>
using namespace std;
int ans;
int n;
//bool bj[1005];
int fa[1005],to[1005];
int find(int u){
	if(fa[u] == u)return u;
	else return fa[u] = find(fa[u]);
}
void dfs(int x,int c){
	for(int i = 1; i <= n; i ++){
		int f_i = find(i);
		int f_x = find(x);
		if(x != i && f_i == i){
			fa[f_i] = f_x;
			
		}
	}
	return ;
}
namespace AK_IOI{
	int main(){
		cin >> n;
		for(int i =1; i <= n; i ++){
			fa[i] = i;
			to[i] = i;
		}
		dfs(1,1);
		cout <<ans;
		return 0;
	}
}
int main(){
//	freopen("game.in","r",stdin);
//	freopen("game.out","w",stdout);
	AK_IOI::main(); // I ak IOI!!!
	return 0;
}
/*
3
*/
