#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int n,m,s[5000001],k,d[5000001];
	char a[5000001];
	void js(int k){
		d[0]=0;
		int pre=0,cnt=0;
		for(int i=1;i<=n;i++){
			if(abs(abs(s[i])-abs(s[pre]))<=k&&ceil(double(abs(abs(s[n])-abs(s[i])))/double(m-cnt-1))<=k){
				cnt++;
				d[++d[0]]=i-pre;
				pre=i;
				if(cnt==m-1&&i!=n){
					d[++d[0]]=n-pre;
					return;
				}
			}
		}
	}
	int main(){
		scanf("%d%d%s",&n,&m,a+1);
		if(m==1){
			printf("%d\n%d",n,n);
			return 0;
		}
		for(int i=1;i<=n;i++){
			if(a[i]=='1'){
				s[i]=s[i-1]+1;
			}else{
				s[i]=s[i-1]-1;
			}
		}
		k=ceil(double(abs(s[n]))/double(m));
		js(k);
		if(k==0&&d[0]!=m){
			k++;
			js(k);
		}
		for(int i=1;i<=d[0];i++){
			printf("%d ",d[i]);
		}
		printf("\n");
		for(int i=1;i<=n/2;i++){
			swap(a[i],a[n-i+1]);
		}
		memset(s,0,sizeof(s));
		for(int i=1;i<=n;i++){
			if(a[i]=='1'){
				s[i]=s[i-1]+1;
			}else{
				s[i]=s[i-1]-1;
			}
		}
		js(k);
		for(int i=d[0];i>=1;i--){
			printf("%d ",d[i]);
		}
		return 0;
	}
}
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	ldm::main();
	return 0;
}
//44m 256m
