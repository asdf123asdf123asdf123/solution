#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
namespace Main {
	const int N = 100000 + 5;
	int n, Q;
	int x[N];
	int sign(int a) {
		if(a > 0) return 1;
		if(a < 0) return -1;
		return 0;
	}
	bool chk(int a) {
		return 1 <= a && a <= n;
	}
	ll dis(int a, int b, int c, int d) {
		if(sign(b) == sign(d)) {
			return abs(a - c) + abs(b - d);
		}
		int id1 = lower_bound(x + 1, x + 1 + n, a) - x;
		int id2 = id1 - 1;
		ll res = abs(b);
		ll minn = 9e18;
		if(chk(id1)) {
			minn = min(minn, (long long)abs(a - x[id1]) + abs(d) + abs(c - x[id1]));
		}
		if(chk(id2)) {
			minn = min(minn, (long long)abs(a - x[id2]) + abs(d) + abs(c - x[id2]));
		}
//		cout << "minn = " << minn << '\n';
		res += minn;
		return res;
	}
	int main() {
		scanf("%d", &n);
		for (int i = 1; i <= n; ++i) {
			scanf("%d", &x[i]); 
		}
		sort(x + 1, x + 1 + n);
		n = unique(x + 1, x + 1 + n) - x - 1;
		scanf ("%d", &Q);
		for (int ti = 1, a, b, c, d; ti <= Q; ++ti) {
			scanf("%d%d%d%d", &a, &b, &c, &d);
			printf("%lld\n", min(dis(a, b, c, d), dis(c, d, a, b)));
		}
//		while(1);
		return 0;
	}
}
int main() {
	freopen("garden.in", "r", stdin);
	freopen("garden.out", "w", stdout);
	Main::main();
	return 0;
} 
//meb:0.9mb
