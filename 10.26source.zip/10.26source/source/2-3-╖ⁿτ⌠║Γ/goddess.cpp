#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 10005;
	const long long inf = 0x7fffffffffffffff / 2;
	int n, m, h[2 * MAXN];
	long long f[2 * MAXN][2], ans; 
	int main(){
		scanf("%d%d", &n, &m);
		for(int i = 1;i <= n;i++){
			scanf("%d", &h[i]);
			h[n + i] = h[i];
		}
		ans = inf;
		for(int i = 1;i <= n;i++){
			f[i][0] = f[i][1] = 0;
			for(int j = i + 1;j <= i + n;j++){
				if(h[j] > h[j - 1]){
					f[j][0] = min(f[j - 1][0], f[j - 1][1] + m) + h[j] - h[j - 1];
					f[j][1] = min(f[j - 1][0] + m, f[j - 1][1]) + 1ll * (h[j] - h[j - 1]) * (h[j] - h[j - 1]);
				}
				else{
					f[j][0] = min(f[j - 1][0], f[j - 1][1] + m) + 1ll * (h[j] - h[j - 1]) * (h[j] - h[j - 1]);
					f[j][1] = min(f[j - 1][0] + m, f[j - 1][1]) + h[j - 1] - h[j];
				}
			}
			ans = min(ans, min(f[i + n][0], f[i + n][1]));
		}
		for(int i = 2 * n;i > n;i--){
			f[i][0] = f[i][1] = 0;
			for(int j = i - 1;j >= i - n;j--){
				if(h[j] > h[j + 1]){
					f[j][0] = min(f[j + 1][0], f[j + 1][1] + m) + h[j] - h[j + 1];
					f[j][1] = min(f[j + 1][0] + m, f[j + 1][1]) + 1ll * (h[j] - h[j + 1]) * (h[j] - h[j + 1]);
				}
				else{
					f[j][0] = min(f[j + 1][0], f[j + 1][1] + m) + 1ll * (h[j] - h[j + 1]) * (h[j] - h[j + 1]);
					f[j][1] = min(f[j + 1][0] + m, f[j + 1][1]) + h[j + 1] - h[j];
				}
			}
			ans = min(ans, min(f[i - n][0], f[i - n][1]));
		}
		printf("%lld", ans);//while(1); 
		return 0;
	}
} 
int main(){
	freopen("goddess.in", "r", stdin);
	freopen("goddess.out", "w", stdout);
	return ac::main();
}//1MB
