#include <bits/stdc++.h>
using namespace std;
int f[1005][1005];
int a[5000005];

int n,k;
int pre[5000005];
int ans_pre_max[1005][1005];
int ans_pre_min[1005][1005];
string s;
void print_min(int i,int j,int fa){
	if(!i){
		printf("%d ",fa-i);
		return;
	}
	print_min(ans_pre_min[i][j],j-1,i);
	if(i==n)return;
	printf("%d ",fa-i);
}
void print_max(int i,int j,int fa){
	if(!i){
		printf("%d ",fa-i);
		return;
	}
	print_max(ans_pre_max[i][j],j-1,i);
	if(i==n)return ;
	printf("%d ",fa-i);
}
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	memset(f,0x3f,sizeof f);
	memset (f[0],0,sizeof f[0]);
	cin>>n>>k;
	cin>>s;
	s='0'+s;
	for(int i=1;i<=n;i++){
		a[i]=s[i]-'0';
		if(a[i]==1)pre[i]=pre[i-1]+1;
		else pre[i]=pre[i-1]-1;
	} 
	for(int i=1;i<=n;i++){
		for(int j=1;j<=min(k,i);j++){
		//	int bji;
			for(int k=j-1;k<i;k++){
				if(max(f[k][j-1],abs(pre[i]-pre[k]))<f[i][j]){
					//bji=k;
					f[i][j]=max(f[k][j-1],abs(pre[i]-pre[k]));
					ans_pre_min[i][j]=ans_pre_max[i][j]=k;
				}
				if(max(f[k][j-1],abs(pre[i]-pre[k]))==f[i][j]){
					ans_pre_max[i][j]=k;
				} 
		//		f[i][j]=min(f[i][j],max(f[k][j-1],abs(pre[i]-pre[k])));
			
			}
		//	cout<<i<<' '<<j<<' '<<f[i][j]<<' '<<bji<<endl;
		}
	} 
//	cout<<f[n][k]<<endl;
	print_min(n,k,n);
	printf("\n");
	print_max(n,k,n);
	return 0;
//	cout<<f[n][k];
}
/*
8 3
11001100
*/
