#include<bits/stdc++.h>
using namespace std;
namespace Main {
	const int N = 5000000 + 5; 
	int n, m;
	int a[N], s[N], d[N];
	int calc(int l, int r) {
		//����[l, r]����Ů����֮�� 
		return abs(d[r] - d[l - 1]);
	}
	void ylz(vector<int> &v, int res) {
		reverse(a + 1, a + 1 + n);
		for (int i = 1; i <= n; ++i) {
			s[i] = s[i - 1] + a[i];
			d[i] = i - 2 * s[i];
		} 
		int cnt = 0;
		for (int i = 1; i <= n; ++i) {
			++cnt;
			int r = i;
			for (int j = n - m + cnt; j >= i; --j) {
				if(calc(i, j) <= res) {
					r = j;
					break;
				}
			}
			v.emplace_back(r - i + 1);
			i = r;
		}
	} 
	namespace hyz {
		vector<int> v;
		void solve(int res) {
			ylz(v, res);
			reverse(v.begin(), v.end());
			for (int i = 0; i < (int)v.size(); ++i) {
				printf("%d%c", v[i], i == (int)v.size() - 1 ? '\n' : ' ');
			}
		}
	}
	namespace yhy {
		vector<int> v;
		void solve(int res) {
			ylz(v, res);
			for (int i = 0; i < (int)v.size(); ++i) {
				printf("%d", v[i]);
				if(i != (int)v.size() - 1) printf(" ");
			}
		}
	}
	bool chk(int x) {
		int cnt = 0;
		for (int i = 1; i <= n; ++i) {
			int r = i;
			++cnt;
			for (int j = n - m + cnt; j >= i; --j) {
				if(calc(i, j) <= x) {
					r = j;
					break;
				}
			}
			i = r;
		}
		return cnt == m;
	}
	int main() {
		scanf ("%d%d", &n, &m);
		for (int i = 1; i <= n; ++i) {
			scanf ("%1d", &a[i]);
			s[i] = s[i - 1] + a[i];
			d[i] = i - 2 * s[i];
		} 
		int l = 0, r = n, ans = 0;
		while(l <= r) {
			int mid = (l + r) >> 1;
			if(chk(mid)) {
				r = mid - 1;
				ans = mid;
			}
			else {
				l = mid + 1;
			}
		}
		hyz::solve(ans);
		yhy::solve(ans);
//		while(1);
		return 0;
	}
}
int main() {
//	int s=clock();
	freopen("villa.in", "r", stdin);
	freopen("villa.out", "w", stdout);
	Main::main();
//	int t=clock();
//	cerr<<(t-s)<<'\n';
	return 0;
} 
//meb:39mb
