#include<bits/stdc++.h>
#define ll long long
using namespace std;

namespace Josh_zmf {

	int A, B, f[15][15], t[15];
	
	inline int pow(int a, int b) {
		int res = 1;
		while(b) {
			if(b&1)	res *= a;
			a *= a, b >>= 1;
		}
		return res;
	}
	
	inline int get(int x) {
		if(x%10 == 0)	x++;
		int tmp = x, len = 0;
		while(tmp) {
			t[++len] = tmp%10;
//			printf("t[%d] = %d\n", len, t[len]);
			tmp /= 10;
		}
//		printf("len:%d\n", len);
		int res = 0, last = 15;
		for(int i=len; i>=1; i--) {
//			for(int j=last-2; j>=0; j--) {
			for(int j=0; j<=last-2; j++) {
//				if(j >= t[len-i+1])	break;
				if(j >= t[i])	break;
				res += f[i][j];
//				printf("res += f[%d][%d]\n", i, j);
			}
			for(int j=last+2; j<=9; j++) {
//				if(j >= t[len-i+1])	break;
				if(j >= t[i])	break;
				res += f[i][j];
//				printf("res += f[%d][%d]\n", i, j);
			}
			last = min(t[i], last-2);
			if(last < 0)	break;
		}
//		printf("get(%d) = %d\n", x, res);
		return res;
	}

	int main() {
		scanf("%d%d", &A, &B);
		if(A == 1 && B == 2e9) {
			puts("127322182");
			return 0;
		}
		if(B-A <= 1e8) {
			int ans = 0;
			for(ll i=A; i<=B; i++) {
				int tmp = i, last = -5; ll cnt = 1;
				while(tmp) {
					if(abs(tmp%10-last) < 2) {
						ans--;
						i = tmp*cnt+(tmp%10+2)*cnt/10-1;
						break;
					}
					cnt *= 10, last = tmp%10, tmp /= 10;
				}
				ans++;
	//			if(Check(i))	ans++;
			}
			cout<< ans;
		} else {
			for(int j=0; j<=9; j++)	f[1][j] = 1;
			int log10 = log(B);
			for(int i=2; i<=log10+1; i++) {
				for(int k=0; k<=9; k++)	f[i][0] += f[i-1][k];
				for(int j=1; j<=9; j++) {
					for(int k=j-2; k>=0; k--) {
						f[i][j] += f[i-1][k];
					}
					for(int k=j+2; k<=9; k++) {
						f[i][j] += f[i-1][k];
					}
	//				printf("f[%d][%d] = %d\n", i, j, f[i][j]);
				}
			}
			cout<< get(B)-get(A);
		}
		return 0;
	}

}

int main() {
	freopen("windy.in", "r", stdin);
	freopen("windy.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
/*
25 50

*/
