#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=15;
	const int MAXM=105; 
	int n,t,head[MAXN],tot,ans;
	struct node {
		int to,next,val;
	}edge[MAXM];
	void add(int u,int v,int d) {
		tot++;
		edge[tot].to=v;
		edge[tot].val=d;
		edge[tot].next=head[u];
		head[u]=tot;
	}
	void dfs(int u,int an) {
		if (an>t) return ;
		if (an==t && u==n) {
			ans=(ans+1)%2009;
			return ;
		}
		int v,d;
		for (int i=head[u];i;i=edge[i].next) {
			v=edge[i].to,d=edge[i].val;
			dfs(v,an+d);
		}
	}
	int main() {
		freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);
		scanf("%d%d",&n,&t);
		char c;
		for (int i=1;i<=n;i++) {
			for (int j=1;j<=n;j++) {
				scanf(" %c",&c);
				if (c=='0') continue;
				add(i,j,c-'0');
			}
		}
		dfs(1,0);
		printf("%d",ans);
		return 0;
	}
}
int main() {
	hw::main();
	return 0;
} 
/*
2 2 
11 
00

5 30 
12045 
07105 
47805 
12024 
12345
*/
