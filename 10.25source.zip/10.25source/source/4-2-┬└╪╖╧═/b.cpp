#include<bits/stdc++.h>
using namespace std;
namespace Main {
	const int N = 1000 + 5;
	int n; 
	int a[N];
	bool vis[N];
	map<int, int> p;
	int gcd(int x, int y) {
		return !y ? x : gcd(y, x % y);
	}
	int lcm(int x, int y) {
		if(!x || !y) return x | y;
		return x / gcd(x, y) * y;
	}
	int bj[N]; 
	int calc() {
		for (int i = 1; i <= n; ++i) bj[i] = 0;
		int ans = 0;
		for (int i = 1; i <= n; ++i) {
			int cnt = 0;
			int x = i;
			while(bj[x] != i) {
				bj[x] = i;
				x = a[x];
				++cnt;
			}
			ans = lcm(ans, cnt);
		}
		return ans;
	}
	void dfs(int x) {
		if(x > n) {
			int res = calc();
			if(!p.count(res)) {
				p[res] = 1;
			}
			return;
		}
		for (int i = 1; i <= n; ++i) {
			if(!vis[i]) {
				vis[i] = 1;
				a[x] = i;
				dfs(x + 1);
				vis[i] = 0;
			}
		}
	}
	int main() {
		scanf ("%d", &n);
		dfs(1);
		cout << p.size() << '\n';
		return 0;
	}
}
int main() {
	freopen("game.in", "r", stdin);
	freopen("std.out", "w", stdout);
	Main :: main();
	return 0;
} 
