#include<bits/stdc++.h>
using namespace std;
int n,m;
long long a[20005];
long long dp[20005][5],ans = 1e18;
long long tl(int x,int zt,int jq){
	if(a[x] > a[x-jq]){
		if(zt == 1){ //shangsheng 
			return abs(a[x]-a[x-jq]);
		}
		else {
			return abs(a[x]-a[x-jq]) * abs(a[x]-a[x-jq]);
		}
	}
	else{
		if(zt == 0){
			return abs(a[x]-a[x-jq]);
		}
		else {
			return abs(a[x]-a[x-jq]) * abs(a[x]-a[x-jq]);
		}
	}
}
namespace No_AFO{
	int main(){
		cin >> n >> m;
		for(int i =1; i <= n; i ++){
			scanf("%lld",&a[i]);
			a[i+n] = a[i];
		}
//		for(int i =1; i <= 2*n; i ++){
//			cout << a[i] <<" ";
//		}
//		cout << endl;
		for(int i =1; i <= n; i ++){ //��� 
			dp[i][0] = 0;
			dp[i][1] = 0;
			for(int j = 1; j <= n; j ++){ // ���� 
			
				dp[i+j][1] = min(dp[i+j-1][0]+m+tl(i+j,1,1),dp[i+j-1][1]+tl(i+j,1,1));
				dp[i+j][0] = min(dp[i+j-1][1]+m+tl(i+j,0,1),dp[i+j-1][0]+tl(i+j,0,1));
		//cout << "f:" <<dp[i+j-1][0]<<" "<<m<<" " <<tl(j,1,1) << " " <<dp[i+j-1][1]+tl(j,1,1) <<"\n";
		//cout << "s:" <<dp[i+j-1][1]+m+tl(j,0,1) << " " <<dp[i+j-1][0]+tl(j,0,1) <<"\n";
				//cout << i <<  " " << dp[i+j][1] <<" " << dp[i+j][0] <<"\n";
			}
			ans = min(ans,min(dp[i+n][0],dp[i+n][1]));
			//cout << "now:" << dp[i+n][0] <<" " << dp[i+n][1] <<"\n";
			//cout << i <<" " <<ans <<"\n";
		}
		for(int i = 2*n; i  > n; i --){ //��� 
			dp[i][0] = dp[i][1] = 0;
			for(int j = 1; j <= n; j ++){ // ���� 
				dp[i-j][1] = min(dp[i-j+1][0]+m+tl(i-j,1,-1),dp[i-j+1][1]+tl(i-j,1,-1));
				dp[i-j][0] = min(dp[i-j+1][1]+m+tl(i-j,0,-1),dp[i-j+1][0]+tl(i-j,0,-1));
			}
			ans = min(ans,min(dp[i-n][0],dp[i-n][1]));
			//cout << i <<" " <<ans <<"\n";
		}
		cout << ans;
		return 0;
	}
}
int main() {
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	No_AFO::main(); 
	return 0;
}
/*
6 7
4 2 6 2 5 6
*/
