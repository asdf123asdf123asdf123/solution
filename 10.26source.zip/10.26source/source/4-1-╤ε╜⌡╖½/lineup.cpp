#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
namespace yjf{
	const int N=1010;
	const int Mod=10007;
	int h[N],ne[N],e[N],idx;
	int c[N][N];
	int f[N],size[N];
	void add(int x,int y){
		e[++idx]=y;
		ne[idx]=h[x];
		h[x]=idx;
	}
	void dfs(int u){
		f[u]=1;
		for(int i=h[u];i!=-1;i=ne[i]){
			dfs(e[i]);
			size[u]+=size[e[i]];
			f[u]=f[u]*f[e[i]]%Mod*c[size[e[i]]-1][size[u]-1]%Mod;
		}
		size[u]++;
	}
	int main(){
		for(int i=0;i<=1000;i++){
			c[0][i]=1;
		}
		for(int i=1;i<=1000;i++){
			for(int j=i;j<=1000;j++){
				c[i][j]=c[i-1][j-1]+c[i][j-1];
				c[i][j]%=Mod;
//				cout<<i<<" "<<j<<" "<<c[i][j]<<endl;
			}
//			cout<<endl;
		}
		int t;
		scanf("%d",&t);
		while(t--){
			memset(size,0,sizeof(size));
			memset(f,0,sizeof(f));
			memset(h,-1,sizeof(h));//ע����գ����� 
			idx=0;
			int n,s,y;
			scanf("%d",&n);
			for(int i=1;i<=n;i++){
				scanf("%d",&s);
				for(int j=1;j<=s;j++){
					scanf("%d",&y);
					add(i,y);
				}
			}
			dfs(1);
			printf("%d\n",f[1]);
		}
		return 0;
	}
}
int main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	return yjf::main();
}//9MB
