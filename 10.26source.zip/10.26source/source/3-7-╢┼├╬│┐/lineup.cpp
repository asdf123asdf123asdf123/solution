#include<bits/stdc++.h>
using namespace std;
const int maxn=1e2+5;
int n,t;
int c[maxn][maxn],a[maxn][maxn];
int s[maxn],f[maxn];
void dp(int x){
	int t;
	f[x]=1;
	s[x]=0;
	for(int i=a[x][0];i>=1;--i){
		t=a[x][i];
		dp(t);
		f[x]=(((f[x]*f[t])%10007)*(c[s[t]+s[x]-1][s[t]-1]))%10007;
		s[x]+=s[t];
	}
	s[x]++;
}
int main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	scanf("%d",&t);
	c[0][0]=1;
	for(int i=1;i<maxn;++i){
		c[i][0]=c[i][i]=1;
		for(int j=1;j<i;++j){
			c[i][j]=(c[i-1][j-1]+c[i-1][j])%10007;
		}
	}
	for(int i=1;i<=t;++i){
		scanf("%d",&n);
		for(int i=1;i<=n;++i){
			cin>>a[i][0];
			for(int j=1;j<=a[i][0];++j){
				cin>>a[i][j];
			}
		}
		dp(1);
		cout<<f[1]<<'\n';
	}
	return 0;
}
