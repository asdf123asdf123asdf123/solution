#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	long long a[100003];
	struct point{
		long long x,y;
	};
	long long dis(point x,point y){
		return abs(x.x-y.x)+abs(x.y-y.y);
	}
	int main(){
		int n,q,l,r,ans;
		point x,y;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		sort(a+1,a+1+n);
		scanf("%d",&q);
		while(q--){
			scanf("%lld%lld%lld%lld",&x.x,&x.y,&y.x,&y.y);
			if(!((x.y>0)^(y.y>0))){
				printf("%lld\n",dis(x,y));
				continue;
			}
			if(x.x>y.x)
				swap(x,y);
			if(y.x<a[1]){
				printf("%lld\n",dis(x,{a[1],0})+dis({a[1],0},y));
				continue;
			}
			if(x.x>a[n]){
				printf("%lld\n",dis(x,{a[n],0})+dis({a[n],0},y));
				continue;
			}
			l=1;
			r=n;
			ans=1;
			while(l<=r){
				int mid=(l+r)>>1;
				if(a[mid]<x.x){
					l=mid+1;
					ans=mid;
				}
				else
					r=mid-1;
			}
			if(x.x<=a[ans+1]&&y.x>=a[ans+1]){
				printf("%lld\n",dis(x,y));
				continue;
			}
			printf("%lld\n",min(dis(x,{a[ans],0})+dis({a[ans],0},y),dis(x,{a[ans+1],0})+dis({a[ans+1],0},y)));
		}
		return 0;
	}
}
int main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	estidi::main();
	return 0;
}
