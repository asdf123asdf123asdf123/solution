#include <bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ans=(ans<<1)+(ans<<3)+ch-'0';
		ch=getchar();
	}
	return w*ans;
}
int n;
int a[100005];
int m;
signed main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	} 
	sort(a+1,a+1+n);
	m=read();
	while(m--){
		int x1=read(),y1=read(),x2=read(),y2=read();
		if(x1>x2){
			swap(x1,x2);
			swap(y1,y2);
		}
		if((y1>=1&&y2>=1)||(y1<=-1&&y2<=-1)){
			printf("%lld\n",abs(x1-x2)+abs(y1-y2));
			continue;
		} 
		int minn=1e18;
		int L=1,R=n;
		while(L<R){
			int mid=L+R>>1;
			if(a[mid]>=x1){
				R=mid;
			}else{
				L=mid+1;
			}
		} 
	//	cout<<"*** "<<a[L]<<endl;
		minn=min(abs(x1-a[L])+abs(y1)+abs(x2-a[L])+abs(y2),minn);
		L=1,R=n;
		while(L<R){
			int mid=L+R+1>>1;
			if(a[mid]<=x2){
				L=mid;
			}else{
				R=mid-1;
			}
		} 
		minn=min(abs(x1-a[L])+abs(y1)+abs(x2-a[L])+abs(y2),minn);
		cout<<minn<<'\n';	
	}
	return 0;
} 
/*
2
2 -1
2
0 1 0 -1
1 1 2 2
*/
