#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
const int dx[]={0,0,1,-1},dy[]={1,-1,0,0};
int n,m,t,vis[35][35],g[35][35];
string s[35];
double ans;
struct node
{
	int x,y,step;
}a[905];
void clean()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			g[i][j]=0;
		}
	}
	return;
}
void dfs(int x,int y,int cnt)
{
	if(cnt>t)return;
	g[x][y]=vis[x][y]=1;
	for(int i=0;i<4;i++)
	{
		int xx=dx[i]+x,yy=dy[i]+y;
		if(xx<1||xx>n||yy<1||yy>m||vis[xx][yy])continue;
		if(s[xx][yy]=='1')
		{
			dfs(xx,yy,cnt+1);
		}
		else
		{
			dfs(xx,yy,cnt);
		}
	}
	vis[x][y]=0;
	return;
}
double calc(double x1,double y1,double x2,double y2)
{
	return sqrt(abs(x1-x2)*abs(x1-x2)+abs(y1-y2)*abs(y1-y2));
}
double query(int x,int y)
{
	double sum=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(g[i][j])
			{
				sum=max(sum,calc(double(x),double(y),double(i),double(j)));
			}
		}
	}
	return sum;
}
int main()
{
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	cin>>n>>m>>t;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i];
		for(int j=m;j>=1;j--)s[i][j]=s[i][j-1];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			clean();
			dfs(i,j,s[i][j]-'0');
			ans=max(ans,query(i,j));
		}
	}
	printf("%.6f",ans);
	return 0;
}
}
int main(){gzx::main();return 0;}
/*
30 30 30
101010110010010110010101100000
011111100101011111111110110001
111011000101110010110111111010
111101111100100110010101101111
011111110011110111000110111111
011101000111010110100111000011
011001000101111101011101110110
111001101111110101110101011001
111101000100001111101001111110
111010101100011010111110011110
111100101111101111001111110110
110111110010101111011011000101
111111001011101011101101110100
101001011110101001110001110010
101110011010111100011011011010
011101000110111011101100100111
001101111111110111010111110101
000101011001100010011001101110
010110111110111111011001011110
110110110110001111101000011100
110100110010111110011010101100
111101110110110010100000111011
101010111110101101011111101101
111110111011111101101111111000
111011111101010110001100011111
111011101010111101100010010001
111101101111011111011100011100
110001100110111011111110101011
001001101000111111111111111100
010111101111101111011001101011
*/
