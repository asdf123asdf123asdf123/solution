#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
typedef long long LL;
using namespace std;
namespace yjf{
	const int N=10010;
	const LL INF=0x3f3f3f3f3f3f3f3f;
	int n,m;
	LL a[N];
	LL f[N][2][2]; //f[][0][]��ʾ����ǰ״̬Ϊ���� 
					//f[][1][]��ʾ����ǰ״̬Ϊ���� 
					//f[][][0]��ʾ����ǰδ�л�״̬ 
					//f[][][1]��ʾ����ǰ�л���״̬ 
	void solve(){
		for(int i=2;i<=n+1;i++){
			//f[i][0][0]
			if(a[i-1]<a[i]){
				f[i][0][0]=min(f[i][0][0],f[i-1][0][0]+(a[i]-a[i-1])*(a[i]-a[i-1]));
			}
			else{
				f[i][0][0]=min(f[i][0][0],f[i-1][0][0]+abs(a[i]-a[i-1]));
			}
			
			//f[i][0][1]
			if(a[i-1]<a[i]){
				f[i][0][1]=min(f[i][0][1],f[i-1][0][1]+(a[i]-a[i-1])*(a[i]-a[i-1]));
				f[i][0][1]=min(f[i][0][1],f[i-1][1][1]+abs(a[i]-a[i-1])+m);
				f[i][0][1]=min(f[i][0][1],f[i-1][1][0]+abs(a[i]-a[i-1])+m);
			}
			else{
				f[i][0][1]=min(f[i][0][1],f[i-1][0][1]+abs(a[i]-a[i-1]));
				f[i][0][1]=min(f[i][0][1],f[i-1][1][1]+(a[i]-a[i-1])*(a[i]-a[i-1])+m);
				f[i][0][1]=min(f[i][0][1],f[i-1][1][0]+(a[i]-a[i-1])*(a[i]-a[i-1])+m);
			}
			
			//f[i][1][0]
			if(a[i-1]>a[i]){
				f[i][1][0]=min(f[i][1][0],f[i-1][1][0]+(a[i]-a[i-1])*(a[i]-a[i-1]));
			}
			else{
				f[i][1][0]=min(f[i][1][0],f[i-1][1][0]+abs(a[i]-a[i-1]));
			}
			
			//f[i][1][1]
			if(a[i-1]>a[i]){
				f[i][1][1]=min(f[i][1][1],f[i-1][1][1]+(a[i]-a[i-1])*(a[i]-a[i-1]));
				f[i][1][1]=min(f[i][1][1],f[i-1][0][1]+abs(a[i]-a[i-1])+m);
				f[i][1][1]=min(f[i][1][1],f[i-1][0][0]+abs(a[i]-a[i-1])+m);
			}
			else{
				f[i][1][1]=min(f[i][1][1],f[i-1][1][1]+abs(a[i]-a[i-1]));
				f[i][1][1]=min(f[i][1][1],f[i-1][0][1]+(a[i]-a[i-1])*(a[i]-a[i-1])+m);
				f[i][1][1]=min(f[i][1][1],f[i-1][0][0]+(a[i]-a[i-1])*(a[i]-a[i-1])+m);
			}
		}
	}
	int main(){
		LL minn=INF;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			scanf("%lld",&a[i]);
		}
		a[n+1]=a[1];
		//��ͨ
		memset(f,0x3f,sizeof(f));
		f[1][0][0]=f[1][1][0]=0;
		solve();
		minn=min(minn,f[n+1][0][0]);
		minn=min(minn,f[n+1][1][0]);
		minn=min(minn,f[n+1][0][1]);
		minn=min(minn,f[n+1][1][1]);
//		cout<<"!!!"<<minn<<endl;
		//���⣨�л��� 
		memset(f,0x3f,sizeof(f));
		f[1][0][0]=0;
		solve();
		minn=min(minn,f[n+1][0][1]-m);
		memset(f,0x3f,sizeof(f));
		f[1][1][0]=0;
		solve();
		minn=min(minn,f[n+1][1][1]-m);
		
		printf("%lld\n",minn);
		return 0;
	}
}
int main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	return yjf::main();
}//2MB
