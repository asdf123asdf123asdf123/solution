#include <bits/stdc++.h>
#define MAXN 40005
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in) {
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	int n;
	long long m;
	long long a[MAXN];
	long long f[MAXN][2];			//0 up 1 down
	long long ans=1e17;
	
	inline long long Abs(long long in){
		if (in>0) return in;
		return -in;
	}
	
	random_device R;
	mt19937 G(R());
	inline int Rand(int l, int r){
		return uniform_int_distribution<int>(l, r)(G);
	}
	
	int main(){
		Read (n);
		Read (m);
		for (int i=1;i<=n;i++){
			Read (a[i]);
			a[i+n]=a[i];
		}
		if (n<=7000){
			for (int i=1;i<=n;i++){
				f[i][0]=f[i][1]=0;
				for (int j=i+1;j<=i+n;j++){
					long long dis=Abs(a[j]-a[j-1]);
					if (a[j-1]<a[j]){
						f[j][0]=min(f[j-1][0]+dis, f[j-1][1]+dis*dis+m);
						f[j][1]=min(f[j-1][0]+dis+m, f[j-1][1]+dis*dis);
					}
					else{
						f[j][0]=min(f[j-1][0]+dis*dis, f[j-1][1]+dis+m);
						f[j][1]=min(f[j-1][0]+dis*dis+m, f[j-1][1]+dis);
					}
				}
				ans=min(ans, min(f[i+n][0], f[i+n][1]));
				f[i+n][0]=f[i+n][1]=0;
				for (int j=i+n-1;j>=i;j--){
					long long dis=Abs(a[j]-a[j+1]);
					if (a[j+1]<a[j]){
						f[j][0]=min(f[j+1][0]+dis, f[j+1][1]+dis*dis+m);
						f[j][1]=min(f[j+1][0]+dis+m, f[j+1][1]+dis*dis);
					}
					else{
						f[j][0]=min(f[j+1][0]+dis*dis, f[j+1][1]+dis+m);
						f[j][1]=min(f[j+1][0]+dis*dis+m, f[j+1][1]+dis);
					}
				}
				ans=min(ans, min(f[i][0], f[i][1]));
			}
			printf ("%lld\n", ans);
			return 0;
		}
		long long count=36000000/n;
		do{
			int i=Rand(1, n);
			f[i][0]=f[i][1]=0;
			for (int j=i+1;j<=i+n;j++){
				long long dis=Abs(a[j]-a[j-1]);
				if (a[j-1]<a[j]){
					f[j][0]=min(f[j-1][0]+dis, f[j-1][1]+dis*dis+m);
					f[j][1]=min(f[j-1][0]+dis+m, f[j-1][1]+dis*dis);
				}
				else{
					f[j][0]=min(f[j-1][0]+dis*dis, f[j-1][1]+dis+m);
					f[j][1]=min(f[j-1][0]+dis*dis+m, f[j-1][1]+dis);
				}
			}
			ans=min(ans, min(f[i+n][0], f[i+n][1]));
			f[i+n][0]=f[i+n][1]=0;
			for (int j=i+n-1;j>=i;j--){
				long long dis=Abs(a[j]-a[j+1]);
				if (a[j+1]<a[j]){
					f[j][0]=min(f[j+1][0]+dis, f[j+1][1]+dis*dis+m);
					f[j][1]=min(f[j+1][0]+dis+m, f[j+1][1]+dis*dis);
				}
				else{
					f[j][0]=min(f[j+1][0]+dis*dis, f[j+1][1]+dis+m);
					f[j][1]=min(f[j+1][0]+dis*dis+m, f[j+1][1]+dis);
				}
			}
			ans=min(ans, min(f[i][0], f[i][1]));
		}
		while (count --> 0);
		printf ("%lld\n", ans);
		return 0;
	}
}

int main(){
	freopen ("goddess.in", "r", stdin);
	freopen ("goddess.out", "w", stdout);
	return wzy::main();
}

/*
6 7
4 2 6 2 5 6
*/
