#include<cstdio>
using namespace std;
int n,vis[1005],arr[1005],brr[1005],crr[100005];
unsigned long long ans = 0;
unsigned long long a2[] = {0,1,2,3,4,6,6,9,11,14,16,20,23,27};
inline void dfs(int x){
	if(x >= n+1){
		for(int i = 1;i <= n;i++){
			brr[i] = i;
		}
		bool tmp;
		int cnt;
		for(cnt = 1;true;cnt++){
			for(int j = 1;j <= n;j++){
				brr[j] = arr[brr[j]];
			}
			tmp = true;
			for(int j = 1;j <= n;j++){
				if(brr[j] != j){
					tmp = false;
					break;
				}
			}
			if(tmp)break;
		}
		if(tmp && crr[cnt] == 0){
			crr[cnt] = 1;
			ans++;
		}
		return;
	}
	for(int i = 1;i <= n;i++){
		if(vis[i] == 0){
			vis[i] = 1;
			arr[x] = i;
			dfs(x+1);
			arr[x] = 0;
			vis[i] = 0;
		}
	}
} 
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d",&n);
	if(n <= 13){
		printf("%llu",a2[n]);
		return 0;
	}
	dfs(1);
	printf("%llu",ans);
	return 0;
}//30pts,TLE/MLE
