#include <bits/stdc++.h>
#include <random>
using namespace std;
random_device R;
mt19937 G(R());
int rd(int l,int r){
	return uniform_int_distribution<int>(l,r)(G);
} 
int main(){
	//freopen(".in","r",stdin);
	freopen("random_villa.in","w",stdout);
	cout<<1000<<' '<<30<<endl;
	for(int i=1;i<=1000;i++){
		cout<<rd(0,1);
	}
}
