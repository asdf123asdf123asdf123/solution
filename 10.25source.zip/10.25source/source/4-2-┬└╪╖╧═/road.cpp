#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
namespace Main {
	const int N = 10 + 5, maxN = 905 + 5;
	const int mod = 2009;
	struct Matrix {
		int r, c;
		ll a[maxN][maxN];
		Matrix() {
			r = c = 0;
		}
		Matrix(int n, int m) {
			r = n, c = m;
			for (int i = 0; i < r; ++i) {
				for (int j = 0; j < c; ++j) {
					a[i][j] = 0;
				}
			}
		}
		Matrix(int n, int m, char E) {
			r = n, c = m;
			if(E == 'E') {
				
				for (int i = 0; i < min(n, m); ++i) {
					a[i][i] = 1;
				}
			}
		}
		friend Matrix operator * (const Matrix &a, const Matrix &b) {
			Matrix c;
			c.r = a.r, c.c = b.c;
			for (int i = 0; i < a.r; ++i) {
				for (int j = 0; j < b.c; ++j) {
					c.a[i][j] = 0;
					for (int k = 0; k < a.c; ++k) {
						c.a[i][j] += a.a[i][k] * b.a[k][j];
					}
					c.a[i][j] %= mod;
				}
			}
			return c;
		}
	};
	Matrix A;
	int n;
	int T;
	Matrix power(Matrix a, int b) {
		Matrix res(a.r, a.c, 'E');
		while(b) {
			if(b & 1) res = res * a;
			a = a * a;
			b >>= 1;
		}
		return res;
	}
	int main() {
		scanf ("%d%d", &n, &T);
		int tot = n - 1;
		for (int i = 0, x; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				scanf ("%1d", &x);
				if(x) {
					int lst = i;
					for (int k = 1; k < x; ++k) {
						++tot;
						A.a[lst][tot] = 1;
						lst = tot;
					}
					A.a[lst][j] = 1;
				}
			}
		}
//		cerr << tot << '\n';
		A.r = tot + 1, A.c = tot + 1;
		A = power(A, T);
		printf("%lld\n", A.a[0][n - 1]); 
//		while(1);
		return 0;
	}
}
int main() {
//	int s=clock();
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	Main :: main();
//	int t=clock();
//	cerr<<(t-s)<<'\n';
	return 0;
}
//meb:26mb
