#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	int biao[13]={1,1,2,3,4,6,6,9,11,14,16};
	set<int>ans;
	int n,a[1003],b[1003];
	bool check(){
		for(int i=1;i<=n;i++)
			if(b[i]!=i)
				return true;
		return false;
	}
	int main(){
		int cnt;
		scanf("%d",&n);
		if(n<=10){
			printf("%d",biao[n]);
			return 0;
		}
		for(int i=1;i<=n;i++)
			a[i]=i;
		do{
			cnt=1;
			for(int i=1;i<=n;i++)
				b[i]=i;
			do{
				for(int i=1;i<=n;i++)
					b[i]=a[b[i]];
				cnt++;
			}while(check());
			ans.insert(cnt);
		}while(next_permutation(a+1,a+1+n));
		printf("%d",ans.size());
		return 0;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	estidi::main();
	return 0;
}
