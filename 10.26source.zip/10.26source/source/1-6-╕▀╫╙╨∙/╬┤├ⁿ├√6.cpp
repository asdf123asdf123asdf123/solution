#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
int n=1000,a[1005],b[1005];
int main()
{
	freopen("1.in","r",stdin);
//	freopen(".out","w",stdout);
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=b[i])
		{
			cout<<i<<'\n';
		}
	}
	cout<<"YES\n";
	return 0;
}
}
int main(){gzx::main();return 0;}

