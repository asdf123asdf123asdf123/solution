#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 15;

namespace EDGE {
	int sz, head[Maxn];
	struct Edge { int next, to, val; } edge[Maxn*Maxn];
	inline void memset_edge() { sz = 0; memset(head, 0, sizeof(head)); }
	inline void Add_edge(int u, int v, int w) {
//		printf("Add_edge(%d, %d, %d)\n", u, v, w);
		edge[++sz] = {head[u], v, w};
		head[u] = sz;
	}
} using namespace EDGE;

namespace Josh_zmf {

	const int MOD = 2009;
	int N, T, ans;
	char s[Maxn];
	
	inline void solve(int u, int time) {
		if(time > T)	return ;
		if(time == T) {
			if(u == N)	ans = (ans+1) %MOD;
			return ;
		}
		for(int i=head[u]; i; i=edge[i].next) {
			int v = edge[i].to, w = edge[i].val;
			solve(v, time+w);
		}
	}

	int main() {
		scanf("%d%d", &N, &T);
		for(int i=1; i<=N; i++) {
			scanf("%s", s+1);
			for(int j=1; j<=N; j++) {
				if(s[j] == '0')	continue;
				Add_edge(i, j, s[j]^48);
			}
		}
		solve(1, 0);
		cout<< ans;
		return 0;
	}

}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
/*
2 2
11
00

5 30
12045
07105
47805
12024
12345

*/ 






//#include<bits/stdc++.h>
//#define ll long long
//using namespace std;
//
//const int Maxn = 15;
//
//namespace EDGE {
//	int sz, head[Maxn];
//	struct Edge { int next, to, val; } edge[Maxn*Maxn];
//	inline void memset_edge() { sz = 0; memset(head, 0, sizeof(head)); }
//	inline void Add_edge(int u, int v, int w) {
//		printf("Add_edge(%d, %d, %d)\n", u, v, w);
//		edge[++sz] = {head[u], v, w};
//		head[u] = sz;
//	}
//} using namespace EDGE;
//
//namespace Josh_zmf {
//
//	int N, T;
//	int num, dfn[Maxn], low[Maxn], stk[Maxn], top;
//	bool in_stk[Maxn];
//	int belong[Maxn], SCC, val[Maxn];
//	vector <int> scc[Maxn];
//	
//	inline void tarjan(int u) {
//		dfn[u] = low[u] = ++num;
//		stk[++top] = u, in_stk[u] = 1;
//		for(int i=head[u]; i; i=edge[i].next) {
//			int v = edge[i].to;
//			if(!dfn[v]) {
//				tarjan(v);
//				low[u] = min(low[u], low[v]);
//			} else if(in_stk[v])	low[u] = min(low[u], dfn[v]);
//		}
//		if(low[u] == dfn[u]) {
//			SCC++;
//			do {
//				scc[SCC].push_back(stk[top]);
//				belong[stk[top]] = SCC;
//				in_stk[stk[top]] = 0;
//			} while(stk[top--] != u);
//		}
//	}
//	
//	bool vis[Maxn];
//	
//	inline int dfs(int u, int val, int find) {
//		vis[u] = 1;
//		for(int i=head[u]; i; i=edge[i].next) {
//			int v = edge[i].to, w = edge[i].val;
//			if(v == find)	return val+w;
//			if(vis[v])	continue; 
//			int tmp = dfs(v, val+w, find);
//			if(tmp)	return tmp;
//		}
//		vis[u] = 0;
//		return 0;
//	}
//
//	char s[Maxn][Maxn];
//	bool chk[Maxn][Maxn];
//	
//	inline void solve(int u, int time) {
//		
//		for(int i=head[u]; i; i=edge[i].next) {
//			int v = edge[i].to, w = edge[i].val;
//			for(int k=0; )
//		}
//	}
//
//	int main() {
//		scanf("%d%d", &N, &T);
//		for(int i=1; i<=N; i++) {
//			scanf("%s", s[i]+1);
//			for(int j=1; j<=N; j++) {
//				if(s[i][j] == '0')	continue;
//				Add_edge(i, j, s[i][j]^48);
//			}
//		}
//		Add_edge(N, N+1, 0);
//		tarjan(1);
//		for(int i=1; i<=N; i++)	printf("belong[%d] = %d\n", i, belong[i]);
//		for(int i=1; i<=SCC; i++) {
//			printf("scc[%d]:: ", i);
//			for(int j=0; j<(int)scc[i].size(); j++) {
//				printf("%d, ", scc[i][j]);
//			}
//			cout<< '\n';
//		}
//		for(int i=1; i<=SCC; i++) {
//			memset(vis, 0, sizeof(vis));
//			val[i] = dfs(scc[i][0], 0, scc[i][0]);
//			printf("val[%d] = %d\n", i, val[i]);
//		}
//		memset_edge();
//		for(int i=1; i<=N; i++) {
//			for(int j=1; j<=N; j++) {
//				if(s[i][j] == '0')	continue;
//				int u = belong[i], v = belong[j];
//				if(chk[u][v])	continue;
//				chk[u][v] = 1;
//				Add_edge(u, v, s[i][j]^48);
//			}
//		}
//		Add_edge(belong[N], belong[N+1], 0);
//		solve(belong[1], 0);
//		return 0;
//	}
//
//}
//
//int main() {
////	freopen("road.in", "r", stdin);
////	freopen("road.out", "w", stdout);
//	Josh_zmf::main();
//	return 0;
//}
///*
//2 2
//11
//00
//
//*/ 
