#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n,m,t;
	int a[35][35];
	int bj[35][35][35];
	int dx[4]={0,0,-1,1};
	int dy[4]={1,-1,0,0};

	double get_dis(int x1,int y1,int x2,int y2){
		return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	}
	double ans=0;
	void dfs(int sx,int sy,int x,int y,int lim){		
		if(lim>t)return;
		if(x<=0||x>n||y<=0||y>m)return;
		if(bj[x][y][lim])return;
		bj[x][y][lim]=1;	
		ans=max(ans,get_dis(sx,sy,x,y));	
		for(int i=0;i<4;i++){
			int tox=x+dx[i];
			int toy=y+dy[i];
			if(a[tox][toy]==1)
				dfs(sx,sy,tox,toy,lim+1);
			else dfs(sx,sy,tox,toy,lim);
		}
	} 
	int main(){
		freopen("maxlength.in","r",stdin);
		freopen("maxlength.out","w",stdout);
		
		scanf("%d%d%d",&n,&m,&t);
	    getchar();
		for(int i=1;i<=n;i++,getchar())
			for(int j=1;j<=m;j++){
				a[i][j]=getchar()-'0';
			} 
		
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++){
				memset(bj,0,sizeof(bj));
				if(a[i][j])dfs(i,j,i,j,1);
				else dfs(i,j,i,j,0);
			}
		printf("%.6f",ans);
		
		return 0;
	}
}
int main(){
	ld::main();
	return 0;
}
