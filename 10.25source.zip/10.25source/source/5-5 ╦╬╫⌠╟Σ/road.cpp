#include<bits/stdc++.h>
using namespace std;
const int mod = 2009;

int n,t;
int fl[15][15];
int dp[15][1000005]; // �ڵ� j ʱ��ʱ����� i �����·������ 
char d[15][15];
namespace florr{
	int main(){
		cin >> n >> t;
		for(int i = 1; i <= n; i ++){
			for(int j = 0; j <= n; j ++){
				scanf("%c",&d[i][j]);
				if(d[i][j] == '0'){
					fl[i][j] = 1e9;
				}
				else 
					fl[i][j] = d[i][j]-'0';
			}
		}
//		for(int i =1; i <= n; i ++){
//			for(int j =1;j<= n; j ++) {
//				cout << fl[i][j] <<" ";
//			}
//			cout << "\n";
//		}
//		for(int i =1; i <= n; i ++){
//			for(int j =1;j<= n; j ++) {
//				cout << d[i][j] <<" ";
//			}
//			cout << "\n";
//		}
		for(int k =1; k <= n; k ++){
			for(int i =1; i <= n; i ++){
				for(int j = 1; j <= n; j ++){
					fl[i][j] = min(fl[i][k]+fl[k][j],fl[i][j]);
				}
			}
		}
		if(fl[1][n] >= 1e9){
			printf("0");
			return 0;
		}
		if(t >= 1000005){
			printf("1");
			return 0;
		}
		dp[1][0] = 1;
//		for(int i =1; i <= n; i ++){
//			for(int j =1;j<= n; j ++) {
//				cout << d[i][j] <<" ";
//			}
//			cout << "\n";
//		}

		for(int k = 1; k <= t; k ++){
			for(int i = 1; i <= n; i ++){
				for(int j = 1; j <= n; j++){
					if(d[j][i] != '0' && k-d[j][i]+'0' >= 0){
						dp[i][k] += dp[j][(k-d[j][i]+'0')];
					}
					dp[i][k] = dp[i][k] % mod;
				}
			}
		}
//		for(int i = 1; i <= n; i ++){
//			for(int j = 1; j <= i; j++){
//				for(int k = 1; k <= t; k ++){
//					//cout << d[i][j] <<"\n";
//					if(d[j][i] != '0' && k-d[j][i]+'0' >= 0){
//						dp[i][k] += dp[j][(k-d[j][i]+'0')];
//					}
//					dp[i][k] = dp[i][k] % mod;
//				}
//			}
//		}
//		for(int i = 1; i <= n; i ++){
//			for(int k = 1; k <= t; k ++){
//				cout << dp[i][k] <<" ";
//			}
//			cout << endl;
//		}
		//cout << "a?";
		//while(1); //59356 kb
		cout << dp[n][t];
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	florr::main(); // florr.io
	return 0;
}
/*
2 2
11
00
AC
5 30
12045
07105
47805
12024
12345
AC
������
AC 
*/
