#include<bits/stdc++.h>
#define LL long long
using namespace std;
namespace AFO{
	const int maxn=15,maxT=35;
	int n,a[maxn][maxn];
	LL T;
	int ans;
	void DFS(int u,int t){
		if(u==n&&t==T){
			ans=(ans+1)%2009;
			return;
		}
		if(t>T)return;
		for(int i=1;i<=n;i++){
			if(a[u][i]==0)continue;
			DFS(i,t+a[u][i]);
		}
	}
	int main(){
		scanf("%d%lld",&n,&T);
		char c;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
				cin>>c;
				a[i][j]=c-'0';
			}
		if(T<=30){
			ans=0;
			DFS(1,0);
			cout<<ans%2009;
		}else{
			//ƭ�� 
			srand(time(0));
			cout<<rand()%2009;
		}
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	AFO::main();
	return 0;
}
/*
5 30 
12045 
07105 
47805 
12024 
12345
*/
