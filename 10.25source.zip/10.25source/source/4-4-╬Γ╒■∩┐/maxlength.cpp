#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int n,m,t;
	char c[40][40];
	vector<pair<int,int> >can;
	double ans;
	bool bj[40][40];
	double l;
	bool fl[40][40];
	queue<pair<int,int> >q;
	int addx[6]={0,-1,0,1,0};
	int addy[6]={0,0,1,0,-1};
	bool all[40][40];
	vector<pair<int,int> >vec;
	void getans(int x,int y){
		q.push({x,y});
		vec.clear();
		vec.push_back({x,y});
		fl[x][y]=1;
		int lx,ly,nx,ny;
		while(q.size()){
			lx=q.front().first;
			ly=q.front().second;
//			cout<<lx<<' '<<ly<<'\n';
			q.pop();
			for(int i=1;i<=4;i++){
				nx=lx+addx[i];
				ny=ly+addy[i];
				if((nx<=0)||(nx>n)||(ny<=0)||(ny>m)){
					continue;
				}
				if(bj[nx][ny]){
					continue;
				}
				if(fl[nx][ny]){
					continue;
				}
				q.push({nx,ny});
				vec.push_back({nx,ny});
				fl[nx][ny]=1;
			}
		}
		for(int i=0;i<vec.size();i++){
			for(int j=0;j<vec.size();j++){
				lx=vec[i].first;
				ly=vec[i].second;
				nx=vec[j].first;
				ny=vec[j].second;
				all[lx][ly]=1;
				l=max(sqrt((lx-nx)*(lx-nx)+(ly-ny)*(ly-ny)),l);
			}
		}
//		cout<<x<<' '<<y<<' '<<l<<'\n';
	}
	double check(){
		double ret=0;
		memset(all,0,sizeof(all));
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(bj[i][j]){
					continue;
				}
				if(all[i][j]){
					continue;
				}
				l=0;
				memset(fl,0,sizeof(fl));
//				cout<<"%\n";
				getans(i,j);
				ret=max(ret,l);
			}
		}
		return ret;
	}
	void dfs(int u){
		if(u>t){
			ans=max(ans,check());
			return;
		}
		for(int i=0;i<can.size();i++){
			int x=can[i].first;
			int y=can[i].second;
			if(!bj[x][y]){
				continue;
			}
			bj[x][y]=0;
			dfs(u+1);
			bj[x][y]=1;
		}
	}
	int main(){
		freopen("maxlength.in","r",stdin);
		freopen("maxlength.out","w",stdout);
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++){
			scanf("%s",c[i]+1);
			for(int j=1;j<=m;j++){
				if(c[i][j]=='1'){
					can.push_back({i,j});
					bj[i][j]=1;
				}
			}
		}
		dfs(1);
		printf("%.6lf\n",ans);
		return 0;
	}
}
int main(){
	return wzk::main();
}
