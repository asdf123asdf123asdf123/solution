#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int n,a[1001],d[1001],v[1001],nn;
	long long ans,f[1001];
	int main(){
		scanf("%d",&n);
//		for(int i=1;i<=n;i++){
//			a[i]=i;
//		}
//		do{
//			for(int i=1;i<=n;i++){
//					d[i]=i;
//				}
//			int k=1;
////			for(int i=1;i<=n;i++){
////				cout<<a[i]<<" ";
////			}
////			cout<<endl;
//			while(++k){
//				for(int i=1;i<=n;i++){
//					d[i]=a[d[i]];
//				}
////				for(int i=1;i<=n;i++){
////					cout<<d[i]<<" ";
////				}
////				cout<<endl;
//				int f=0;
//				for(int i=1;i<=n;i++){
//					if(d[i]!=i){
//						f=1;
//						break;
//					}
//				}
//				if(!f) break;
//			}
//			if(!v[k]){
//				ans++;
//				v[k]=1;
//			}
//		}while(next_permutation(a+1,a+1+n));
		for(int i=2;i<=n;i++){
			int f=0;
			for(int j=2;j<i;j++){
				if(i%j==0){
					f=1;
					break;
				}
			}
			if(!f){
				d[++nn]=i;
			}
		}
		f[0]=1;
		for(int i=1;i<=nn;i++){
			for(int j=n;j>=d[i];j--){
				for(int k=d[i];k<=j;k*=d[i]){
					f[j]+=f[j-k];
					
				}
		//		cout<<f[j]<<" ";
			}
		//	cout<<endl;
		}
		for(int i=1;i<=n;i++){
		//	cout<<i<<" "<<f[i]<<endl; 
			ans+=f[i];
		}
		printf("%lld",ans+1);
		return 0;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ldm::main();
	return 0;
}
//1 2 3 4 6 6 9 11 14 16 20
//1m 256m
