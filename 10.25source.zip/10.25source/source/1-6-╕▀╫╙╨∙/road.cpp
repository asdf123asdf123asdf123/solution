#include<bits/stdc++.h>
using namespace std;
namespace gzx
{
int n,T,vis[15],ans;
int edge[15][15];
void dfs(int u,int time)
{
//	cout<<u<<' '<<time<<'\n';
	if(time>T)return;
	if(u==n)
	{
		if(time==T)
		{
			ans=(ans+1)%2009;
			return;	
		}

	}
//	vis[u]=1;
	for(int i=1;i<=n;i++)
	{
//		cout<<u<<' '<<i<<' '<<edge[u][i]<<'\n';
		if(edge[u][i]/*&&!vis[i]*/)
		{
			dfs(i,time+edge[u][i]);
		}
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>T;
	for(int i=1;i<=n;i++)
	{
		string s;
		cin>>s;
		for(int j=n;j>=1;j--)
		{
			edge[i][j]=s[j-1]-'0';
		}
	}
//	for(int i=1;i<=n;i++)
//	{
//		for(int j=1;j<=n;j++)
//		{
//			cout<<edge[i][j];
//		}
//		cout<<'\n';
//	}
	dfs(1,0);
	cout<<ans;
	return 0;
}
}
int main(){gzx::main();return 0;}
