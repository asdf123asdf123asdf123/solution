#include<bits/stdc++.h>
using namespace std;
namespace FireBird{
	int n,m,t;
	struct nod{
		int x,y;
	};
	struct node{
		int fa,sz;
	}dsu[902];
	int a[32][32],c[32][32];
	void Init(){
		for(int i=1;i<=900;i++){
			dsu[i].fa=i;
			dsu[i].sz=1;
		}
	}
	int Belong(int x){
		if(dsu[x].fa!=x){
			dsu[x].fa=Belong(dsu[x].fa);
		}
		return dsu[x].fa;
	}
	void Union(int x,int y){
		int rt_x=Belong(x);
		int rt_y=Belong(y);
		if(rt_x==rt_y){
			return ;
		}
		if(dsu[rt_x].sz<dsu[rt_y].sz){
			swap(rt_x,rt_y);
		}
		dsu[rt_x].sz+=dsu[rt_y].sz;
		dsu[rt_y].fa=rt_x; 
	}
	queue<nod>q;
	int dx[6]={0,0,-1,1};
	int dy[6]={-1,1,0,0};
	bool b[32][32];
	void bfs(int x,int y){
		q.push({x,y});
		while(!q.empty()){
			int qx=q.front().x;
			int qy=q.front().y;
			for(int i=0;i<4;i++){
				int sx=qx+dx[i];
				int sy=qy+dy[i];
				if(sx<1||sy<1||sx>n||sy>m){
					continue;
				}
				if(b[sx][sy]){
					continue;
				}
				if(a[sx][sy]){
					continue;
				}
				b[sx][sy]=1;
				Union(c[qx][qy],c[sx][sy]);
				q.push({sx,sy});
			}
			q.pop();
		}
	}
	double mx(double a,double b){
		return a<b?b:a;
	}
	int main(){
		string s;
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++){
			cin>>s;
			for(int j=1;j<=m;j++){
				a[i][j]=s[j-1]-'0';
				c[i][j]=(i-1)*n+j;
			}
		}
		Init();
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i][j]){
					continue;
				}
				if(b[i][j]){
					continue;
				}
				bfs(i,j);
			}
		}
		double ans=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				for(int k=i;k<=n;k++){
					for(int l=j;l<=m;l++){
						if(i==k&&j==l){
							continue;
						}
						if(a[i][j]||a[k][l]){
							continue;
						}
						if(Belong(c[i][j])!=Belong(c[k][l])){
							continue;
						}
						ans=mx(ans,sqrt(1.0*(i-k)*(i-k)+1.0*(j-l)*(j-l)));
					}
				}
			}
		}
		printf("%.6f",ans);
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	FireBird::main();
	return 0;
}
