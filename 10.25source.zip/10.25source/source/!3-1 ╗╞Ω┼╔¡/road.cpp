#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	string s[13];
	struct m{
		int r,c,a[103][103];
		m(){
			r=0;
			c=0;
			memset(a,0,sizeof(a));
		}
	}st,mk;
	m operator * (m a,m b){
		m c;
		c.r=a.r;
		c.c=b.c;
		for(int i=1;i<=a.r;i++)
			for(int j=1;j<=a.c;j++)
				for(int k=1;k<=b.c;k++){
					c.a[i][k]+=a.a[i][j]*b.a[j][k];
					c.a[i][k]%=2009;
				}
		return c;
	}
	m powm(m a,long long b){
		m ans;
		ans.r=a.r;
		ans.c=a.c;
		for(int i=1;i<=ans.r;i++)
			ans.a[i][i]=1;
		while(b){
			if(b&1)
				ans=ans*a;
			a=a*a;
			b>>=1;
		}
		return ans;
	}
	int main(){
		int n;
		long long t;
		scanf("%d%lld",&n,&t);
		for(int i=1;i<=n;i++){
			cin>>s[i];
			s[i]=" "+s[i];
		}
		st.r=1;
		st.c=9*n;
		st.a[1][1]=1;
		mk.r=9*n;
		mk.c=9*n;
		for(int i=n+1;i<=9*n;i++)
			mk.a[i-n][i]=1;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(s[i][j]!='0')
					mk.a[(s[i][j]-'0'-1)*n+i][j]=1;
		st=st*powm(mk,t);
		printf("%d",st.a[1][n]);
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	estidi::main();
	return 0;
}
