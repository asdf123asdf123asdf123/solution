#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int n,t,ans,p=2009;
	char a[11][11];
	void dfs(int x,int v){
		if(v==t){
			if(x==n){
				ans++;
				ans%=p;
			}
			return;
		}
		if(v>t){
			return;
		}
		for(int i=1;i<=n;i++){
			if(a[x][i]>'0'){
				dfs(i,v+a[x][i]-'0');
			}
		}
	}
	int main(){
		scanf("%d%d",&n,&t);
		for(int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
		}
		dfs(1,0);
		printf("%d",ans);
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ldm::main();
	return 0;
}
//1m 256m
