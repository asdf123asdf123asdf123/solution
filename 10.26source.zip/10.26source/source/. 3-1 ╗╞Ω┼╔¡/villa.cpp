#include<bits/stdc++.h>
using namespace std;
namespace estidi{
//	int o[5000003],f[5000003],p[5000003];
	int o[1003],f[1003][1003],p[1003][1003],pp[1003][1003];
	void out(int x,int y){
		if(!x)
			return;
		out(x-1,p[x][y]);
		printf("%d ",y-p[x][y]);
	}
	void outt(int x,int y){
		if(!x)
			return;
		outt(x-1,pp[x][y]);
		printf("%d ",y-pp[x][y]);
	}
	int main(){
		int n,m;
		string s;
		scanf("%d%d",&n,&m);
		cin>>s;
		s=" "+s;
		for(int i=1;i<=n;i++)
			o[i]=o[i-1]+(s[i]=='1');
		for(int i=1;i<=m;i++)
			for(int j=1;j<=n;j++)
				f[i][j]=2147483647;
		for(int i=1;i<=n;i++)
			f[1][i]=abs(o[i]*2-i);
		for(int i=2;i<=m;i++)
			for(int j=1;j<=n;j++)
				for(int k=1;k<j;k++){
					if(max(f[i-1][k],abs(o[j]*2-o[k]*2-j+k))<=f[i][j]){
						if(max(f[i-1][k],abs(o[j]*2-o[k]*2-j+k))<f[i][j]){
							f[i][j]=max(f[i-1][k],abs(o[j]*2-o[k]*2-j+k));
//cerr<<i<<" "<<j<<" "<<k<<" "<<f[i][j]<<endl;
							p[i][j]=k;
						}
						pp[i][j]=k;
					}
				}
		out(m,n);
		printf("\n");
		outt(m,n);
		return 0;
	}
}
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	estidi::main();
	return 0;
}
