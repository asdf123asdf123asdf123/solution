#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ans=(ans<<1)+(ans<<3)+ch-'0';
		ch=getchar();
	}
	return w*ans;
}
int n,m,tt;
int a[105][105];
//int f[35][35][35][35][35];
//int d[35][35][35][35];
double ans;
int dx[4]={1,0,-1,0};
int dy[4]={0,-1,0,1};
/*
void dfs(int x,int y,int now,int yx,int yy){
	if(sqrt((x-yx)*(x-yx)+(y-yy)*(y-yy))<=ans)return ;
	ans=max(ans,sqrt((x-yx)*(x-yx)+(y-yy)*(y-yy)));
	for(int i=0;i<4;i++){
		int tx=x+dx[i];
		int ty=y+dy[i];
		if(tx<=0||tx>n||ty<=0||ty>m)continue;
		if(now+a[tx][ty]>tt)continue;
		dfs(tx,ty,now+a[tx][ty],yx,yy);
	}
}
*/
int d[35][35][35][35];
int dij[905];
bool st[905];
struct edge{
	int to;
	int next;
	int w;
}ed[100005];
int cnt;
int h[905];
struct node{
	int wz;
	int w;
};
void add(int x,int y,int w){
	ed[++cnt]={y,h[x],w};
	h[x]=cnt;
}
bool operator<(node a,node b){
	return a.w>b.w;
}
priority_queue<node>q;
void dijkstra(int x){//����֮�������0 
	memset(dij,0x3f,sizeof dij);
	memset (st,0,sizeof st);
	dij[x]=a[(x+m-1)/m][x-(x-1)/m*m];//ӳ�� 
	q.push({x,dij[x]});
	while(q.size()){
		node now=q.top();
		q.pop();
		int u=now.wz;
		if(st[u])continue;
		st[u]=1;
		for(int i=h[u];i;i=ed[i].next){
			int v=ed[i].to;
			if(dij[v]>dij[u]+ed[i].w){
				dij[v]=dij[u]+ed[i].w;
				q.push({v,dij[v]});
			}
		}
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	n=read();
	m=read();
	tt=read();
//	cout<<n<<' '<<m<<' '<<tt<<endl;
	/*
	for(int i=1;i<=n;i++){
		string s;
		cin>>s;
		for(int j=0;j<m;j++){
			a[i][j+1]=s[j];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int t=0;t<=tt;t++){
				for(int p=1;p<=i;p++){
					for(int q=1;q<=j;q++){
						if(a[i][j]==0){
							if(!a[i-1][j]&&i-1>0){
								f[i][j][t][p][q]=max(f[i][j][t][p][q],f[i-1][j][t][p][q]);
							}
							if(!a[i][j-1]&&j-1>0){
								f[i][j][t][p][q]=max(f[i][j][t][p][q],f[i][j-1][t][p][q]);
							}
						} else{
							if(t==0)continue;
							if(!a[i-1][j]&&i-1>0){
								f[i][j][t][p][q]=max(f[i][j][t][p][q],f[i-1][j][t-1][p][q]);
							}
							if(!a[i][j-1]&&j-1>0){
								f[i][j][t][p][q]=max(f[i][j][t][p][q],f[i][j-1][t-1][p][q]);
							}
						}
					}
				}
			}
		}
	} 
	for(int i=1;i<=n;i++){
		for(int )
	}
	*/
	for(int i=1;i<=n;i++){
		string s;
		cin>>s;
		for(int j=0;j<m;j++){
			a[i][j+1]=s[j]-'0';
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(j-1>0){
				add((i-1)*m+j,(i-1)*m+j-1,a[i][j-1]);//ӳ�� �ӱ� 
			}
			if(j+1<=m){
				add((i-1)*m+j,(i-1)*m+j+1,a[i][j+1]);
			}
			if(i-1>0){
				add((i-1)*m+j,(i-2)*m+j,a[i-1][j]);
			}
			if(i+1<=n){
				add((i-1)*m+j,i*m+j,a[i+1][j]);
			} 
		}
	}
	/*
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int p=i;p<=n;p++){
				for(int q=j;q<=m;q++){
				//	cout<<i<<' '<<j<<' '<<p<<' '<<q<<endl;
					if(p==i&&q==j){
						d[i][j][p][q]=a[i][j];
						continue;
					}
					if(p==i){
						d[i][j][p][q]=d[i][j][p][q-1]+a[p][q];
						continue;
					}
					if(q==j){
						d[i][j][p][q]=d[i][j][p-1][q]+a[p][q];
						continue;
					}
					d[i][j][p][q]=min(d[i][j][p-1][q],d[i][j][p][q-1])+a[p][q];
				//	cout<<i<<' '<<j<<' '<<p<<' '<<q<<' '<<d[i][j][p][q]<<'\n';
				}
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int p=i;p<=n;p++){
				for(int q=j;q<=m;q++){
					if(d[i][j][p][q]<=tt){
					//	cout<<i<<' '<<j<<' '<<p<<' '<<q<<endl;
				//		cout<<i<<' '<<j<<' '<<p<<' '<<q<<' '<<sqrt((p-i)*(p-i)+(q-j)*(q-j))<<endl;;
						if(sqrt((p-i)*(p-i)+(q-j)*(q-j))>=ans){
							cout<<i<<' '<<j<<' '<<p<<' '<<q<<endl;
						}
						ans=max(ans,sqrt((p-i)*(p-i)+(q-j)*(q-j)));
					}
				}
			}
		}
	}
	*/
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			dijkstra((i-1)*m+j);
			for(int p=1;p<=n;p++){
				for(int q=1;q<=m;q++){
					d[i][j][p][q]=dij[(p-1)*m+q];
					
					if(d[i][j][p][q]<=tt){
		//				cout<<d[i][j][p][q]<<' '<<i<<' '<<j<<' '<<p<<' '<<q<<endl;
						ans=max(ans,sqrt((p-i)*(p-i)+(q-j)*(q-j)));
						//cout<<ans<<' '<<i<<' '<<j<<' '<<p<<' '<<q<<endl;
					}
				}
			}
		}
	}
	printf("%.6lf",ans);
	return 0;
} 
/*
3 3 0
001
001
110
*/
/*
4 3 0
001 
001 
011
000
*/
/*
3 3 1
001
001
001
*/
