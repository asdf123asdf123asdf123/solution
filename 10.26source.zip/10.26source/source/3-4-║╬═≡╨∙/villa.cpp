#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=1005;
	int n,m,pre1[MAXN],pre0[MAXN],a[MAXN],mn=1;
	char s[MAXN];
	bool dfs1(int num,int now) {
		if (num==m+1) return (now==n+1);
		int t1,t0;
		for (int i=now;i<=n;i++) {
			t0=pre0[i]-pre0[now-1],t1=pre1[i]-pre1[now-1];
			if (abs(t0-t1)<=mn) {
				a[num]=i-now+1;
				if (dfs1(num+1,i+1)) return 1;
			}
		}
	}
	bool dfs2(int num,int now) {
		if (num==m+1) return (now==n+1);
		int t1,t0;
		for (int i=now;i>=a[num-1];i--) {
			t0=pre0[i]-pre0[now-1],t1=pre1[i]-pre1[now-1];
			if (abs(t0-t1)<=mn) {
				a[num]=i-a[num-1];
				if (dfs1(num+1,n-(m-num))) return 1;
			}
		}
	}
	int main() {
		freopen("villa.in","r",stdin);
		freopen("villa.out","w",stdout);
		scanf("%d%d",&n,&m);
		scanf("%s",&s+1);
		for (int i=1;i<=n;i++) {
			pre1[i]=pre1[i-1]+(s[i]=='1');
			pre0[i]=pre0[i-1]+(s[i]=='0');
		}
		dfs1(1,1);
		for (int i=1;i<=m;i++) printf("%d ",a[i]);
		printf("\n");
		dfs2(1,n-m);
		for (int i=1;i<=m;i++) printf("%d ",a[i]);
		printf("\n");
		return 0;
	}
}
int main() {
	hw::main();
	return 0;
} 
/*
8 3 
11001100
*/
