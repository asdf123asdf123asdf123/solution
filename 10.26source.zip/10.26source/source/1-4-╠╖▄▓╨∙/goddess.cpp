#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define N 10005
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int n;
	ll m,a[N],s[N],f[N][2],ans=0x3f3f3f3f3f3f3f3f;
	il ll dp(){
//		for(int i=1;i<=n+1;i++) cout<<s[i]<<' ';
//		putchar(10);
		memset(f,0x3f,sizeof f);
		f[1][0]=f[1][1]=0;
		for(int j=2;j<=n+1;j++){
			if(s[j]>s[j-1]){
				f[j][0]=min(f[j-1][0]+s[j]-s[j-1],f[j-1][1]+(s[j]-s[j-1])*(s[j]-s[j-1])+m);
				f[j][1]=min(f[j-1][0]+s[j]-s[j-1]+m,f[j-1][1]+(s[j]-s[j-1])*(s[j]-s[j-1]));
			}else{
				f[j][1]=min(f[j-1][1]+s[j-1]-s[j],f[j-1][0]+(s[j]-s[j-1])*(s[j]-s[j-1])+m);
				f[j][0]=min(f[j-1][1]+s[j-1]-s[j]+m,f[j-1][0]+(s[j]-s[j-1])*(s[j]-s[j-1]));
			}
//			f[j][0]=min(f[j][0],f[j][1]+m);
//			f[j][1]=min(f[j][1],f[j][0]+m);
		}
//		for(int i=1;i<=n+1;i++){
//			cout<<f[i][0]<<' '<<f[i][1]<<'\n';
//		}
//		putchar(10);
		return min(f[n+1][0],f[n+1][1]);
	}
	signed main(){
		n=read(),m=read();
		for(int i=1;i<=n;i++) a[i]=read();
		for(int i=1;i<=n;i++){
			for(int j=i,cnt=1;cnt<=n;j=(j==n)?(1):(j+1),cnt++) s[cnt]=a[j];
			s[n+1]=s[1];
			ans=min(ans,dp());
		}
		printf("%lld",ans);
		return 0;
	}
}
signed main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	TYX_YNXK::main();
	return 0;
}
