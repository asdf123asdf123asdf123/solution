#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<cstring>
using namespace std;
namespace maxlength{
	struct dot{
		int x,y;
	}now;
	inline double max_d(double a,double b){
		return a < b ? b : a;
	}
	inline double dis(double a,double b,double c,double d){
		return sqrt((a-c)*(a-c)+(b-d)*(b-d));
	}
	int tx[] = {-1,0,1,0},nx;
	int ty[] = {0,-1,0,1},ny;
	char str[35][35];
	int n,m,t,tot = 1,dp[35][35][35][35];
	double ans = 0.0,tmp,arr[100005];
	queue<dot> que;
	int main(){
		scanf("%d %d %d",&n,&m,&t);
		for(int i = 1;i <= n;i++){
			scanf("%s",str[i]+1);
		}
		memset(dp,0x3f,sizeof(dp));
		for(int i = 1;i <= n;i++){
			for(int j = 1;j <= m;j++){
				dp[i][j][i][j] = str[i][j]-'0';
				que.push({i,j});
				while(!que.empty()){
					now = que.front();
					que.pop();
					for(int k = 0;k < 4;k++){
						nx = now.x+tx[k];
						ny = now.y+ty[k];
						if(nx >= 1 && ny >= 1 && nx <= n && ny <= m && dp[i][j][now.x][now.y]+str[nx][ny]-'0' < dp[i][j][nx][ny]){
							dp[i][j][nx][ny] = dp[i][j][now.x][now.y]+str[nx][ny]-'0';
							que.push({nx,ny});
						}
					}
				}
				for(int k = 1;k <= n;k++){
					for(int l = 1;l <= m;l++){
						tmp = dis(i,j,k,l);
						if(tmp > ans && dp[i][j][k][l] <= t)ans = tmp;
					}
				}
			}
		}
		printf("%lf",ans);
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	maxlength::main();
	return 0;
}//100pts
/*
3 3 1
001
001
001
*/
