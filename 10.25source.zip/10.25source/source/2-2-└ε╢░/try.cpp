#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n;
	int node[2050];
	int tong[2050];
	
	int lcm(int x,int y){
		return x*y/__gcd(x,y);
	}
	int ans;
	void dfs(int now,int sum,int last){
		if(sum==n){
			int res=1;
			for(int i=1;i<now;i++){
				res=lcm(res,node[i]);
			}
			if(tong[res])return;
			ans++;
			tong[res]=1;
			cout<<res<<'\n';
		}
		for(int i=last;i<=n-sum;i++){
			node[now]=i;
			dfs(now+1,sum+i,last);
			node[now]=0;
		}	
	}
	int main(){
		scanf("%d",&n);
		dfs(1,0,1);
		cout<<ans<<'\n';
		return 0;
	}
}
int main(){
	ld::main();
	return 0;
}
