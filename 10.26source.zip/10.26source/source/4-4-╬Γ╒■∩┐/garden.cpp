#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int n,m;
	int a[120000],x1,y1,x2,y2;
	long long ans;
	int l,r,mid,bj,an,val;
	int main(){
		freopen("garden.in","r",stdin);
		freopen("garden.out","w",stdout);
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+1+n);
		scanf("%d",&m);
		for(int i=1;i<=m;i++){
			scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
			ans=0;
			if(((y1>0)&&(y2>0))||((y1<0)&&(y2<0))){
				ans=1ll*abs(y1-y2)+abs(x1-x2);
				printf("%lld\n",ans);
				continue;
			}
			if(x1>x2){
				swap(x1,x2);
			}
			ans=1ll*abs(y1-y2);
			l=1;
			r=n;
			mid=0;
			bj=0;
			an=2e9+114;
			val=0;
			while(l<=r){
				mid=(l+r)/2;
				val=a[mid];
//				cout<<"$"<<mid<<' '<<val<<'\n';
				if((x1<=val)&&(val<=x2)){
					bj=1;
					break;
				}else if((x1<val)&&(x2<val)){
					r=mid-1;
					an=min(an,abs(val-x1)+abs(val-x2));
				}else{
					l=mid+1;
					an=min(an,abs(val-x1)+abs(val-x2));
				}
			}
//			cout<<bj<<":\n";
			if(bj==1){
				ans+=1ll*abs(x1-x2);
				printf("%lld\n",ans);
			}else{
				ans+=1ll*an;
				printf("%lld\n",ans);
			}
		}
		return 0;
	}
}
int main(){
	return wzk::main();
}
