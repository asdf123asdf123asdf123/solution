#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
namespace yjf{
	const int N=10010;
	const int INF=0x3f3f3f3f;
	int n,m;
	char a[N];
	int sum[N];
	int mx=-INF,mn=INF;
	bool f[N][N];
	int tmp;
	
	bool check(int x){
		//memset(f,0,sizeof(f));
		f[0][0]=true;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				f[i][j]=false;
				for(int k=0;k<i;k++){
					if(abs(sum[i]-sum[k])<=x && f[k][j-1]){
						f[i][j]=true;
						break;
					}
				}
			}
		}
		return f[n][m];
	}
	int rf(int l,int r){
		while(l<r){
			int mid=(l+r)>>1;
			if(check(mid)){
				r=mid;
			}
			else{
				l=mid+1;
			}
		}
		return l;
	}
	void print_min(int i,int j){
		if(i==n+1) return ;
		for(int k=i+1;k<=n+1;k++){
			if(abs(sum[k-1]-sum[i-1])<=tmp && f[k][j-1]){
				printf("%d ",k-i);
				print_min(k,j-1);
				break;
			}
		}
	}
	void print_max(int i,int j){
		if(i==n+1) return ;
		for(int k=n+1;k>i;k--){
			if(abs(sum[k-1]-sum[i-1])<=tmp && f[k][j-1]){
				printf("%d ",k-i);
				print_max(k,j-1);
				break;
			}
		}
	}
	int main(){
		scanf("%d%d",&n,&m);
		scanf("%s",a+1);
		for(int i=1;i<=n;i++){
			sum[i]=sum[i-1];
			if(a[i]=='1') sum[i]++;
			else sum[i]--;
			mx=max(mx,sum[i]);
			mn=max(mn,sum[i]);
		}
		tmp=rf(0,n);
		//cout<<tmp<<endl;///////////////////////////
		//memset(f,0,sizeof(f));
		f[n+1][0]=true;
		for(int i=n;i>=1;i--){
			for(int j=1;j<=m;j++){
				f[i][j]=false;
				for(int k=n+1;k>i;k--){
					if(abs(sum[k-1]-sum[i-1])<=tmp && f[k][j-1]){
						f[i][j]=true;
						break;
					}
				}
			}
		}
		print_min(1,m);
		printf("\n");
		print_max(1,m);
		return 0;
	}
}
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	return yjf::main();
}//100MB
