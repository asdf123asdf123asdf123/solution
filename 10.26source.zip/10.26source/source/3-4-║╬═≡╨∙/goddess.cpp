#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=10005;
	int n,m,h[2*MAXN];
	long long p[2*MAXN][2],f[2*MAXN][2],ans=0x7f7f;
	void fs(int l,int r) {
		memset(f,0x7f7f,sizeof(f));
		f[l][0]=f[l][1]=0;
		for (int i=l;i<=r+1;i++) {
			f[i][0]=p[i][0]-p[l-1][0];
			f[i][1]=p[i][1]-p[l-1][1];
			for (int j=l;j<=i+1;j++) {
				f[i][0]=min(f[i][0],f[j-1][1]+m+(p[i][0]-p[j-1][0]));
				f[i][1]=min(f[i][1],f[j-1][1]+m+(p[i][1]-p[j-1][1]));
			}
		}
		ans=min(ans,min(f[r+1][0],f[r+1][1]));
		//printf("%lld\n",min(f[r+1][0],f[r+1][1]));
	}
	int main() {
		freopen("goddess.in","r",stdin);
		freopen("goddess.out","w",stdout);
		scanf("%d%d",&n,&m);
		for (int i=1;i<=n;i++) {
			scanf("%d",&h[i]);
			h[i+n]=h[i];
		}
		for (int i=2;i<=2*n;i++) {
			if (h[i-1]<h[i]) {
				p[i][0]=1ll*(h[i]-h[i-1])*(h[i]-h[i-1]);
				p[i][1]=1ll*(h[i]-h[i-1]);
			} else {
				p[i][0]=1ll*(h[i-1]-h[i]);
				p[i][1]=1ll*(h[i-1]-h[i])*(h[i-1]-h[i]);
			}
			p[i][0]+=p[i-1][0];
			p[i][1]+=p[i-1][1];
		}
		for (int i=2;i<=n;i++) {
			fs(i,i+n-1);
		}
		printf("%lld",ans);
		return 0;
	}
}
int main() {
	hw::main();
	return 0;
} 
/*
6 7 
4 2 6 2 5 6
*/
