#include<bits/stdc++.h>
#define LL long long
using namespace std;
namespace last_context{
	const int maxn=100005;
	LL a[maxn];
	int n,m;
	LL move_to(LL x1,LL y1,LL x2,LL y2){
		return abs(x1-x2)+abs(y1-y2);
	}
	int find(LL x){
		int l=1,r=n,ans=n+1;
		while(r-l>=0){
		//	cout<<l<<' '<<r<<'\n';
			int mid=(l+r)>>1;
			if(a[mid]>=x){
				ans=min(ans,mid);
				r=mid-1;
			}else l=mid+1;
		}
		return ans;
	}
	int find2(LL x){
		int l=1,r=n,ans=0;
		while(r-l>=0){
			int mid=(l+r)>>1;
			if(a[mid]<=x){
				ans=max(ans,mid);
				l=mid+1;
			}else r=mid-1;
		}
		return ans;
	}
	int main(){
		LL x1,x2,y1,y2,ans;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		sort(a+1,a+n+1);
		scanf("%d",&m);
		for(int i=1;i<=m;i++){
			scanf("%lld%lld%lld%lld",&x1,&y1,&x2,&y2);
			if(y1<=0&&y2<=0){//no
				ans=move_to(x1,y1,x2,y2);
			}else if(y1>=0&&y2>=0){//no
				ans=move_to(x1,y1,x2,y2);
			}else{//yes
				if(x1>x2)swap(x1,x2),swap(y1,y2);
				if(x1>a[n]){
					ans=move_to(a[n],0,x1,y1)+move_to(a[n],0,x2,y2);
		//			cout<<"#1! \n";
				}else if(x2<a[1]){
					ans=move_to(a[1],0,x1,y1)+move_to(a[1],0,x2,y2);
		//			cout<<"#2! \n";
				}else{
					int wz=find(x1);
					if(a[wz]<=x2){
						ans=move_to(x1,y1,x2,y2);
		//			cout<<"#3! \n";
		//			cout<<x1<<' '<<x2<<' '<<wz<<' '<<a[wz]<<'\n';
					}else{
						int L=find2(x1),R=find(x2);
						LL ansz1,ansz2;
						ansz1=move_to(a[L],0,x1,y1)+move_to(a[L],0,x2,y2);
						ansz2=move_to(a[R],0,x1,y1)+move_to(a[R],0,x2,y2);
						ans=min(ansz1,ansz2);
		//			cout<<"#4! \n";
					}
				}
			}
			printf("%lld\n",ans);
		}
		return 0;
	}
}
int main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	last_context::main();
//	while(1);
	return 0;
}
/*
2 
2 -1
2
0 1 0 -1
1 1 2 2 
*/
//1324KB=1.3MB
