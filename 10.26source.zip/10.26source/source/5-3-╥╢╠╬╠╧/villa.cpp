#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	int n,m;
	char A[5000010];
	int	dp[1010][1010],Q[1010],pre[1010][1010],Q2[1010];
//	bool cheak(int k)
//	{
//		
//	}
	void pans2(int u,int c)
	{
		if(!c)return ;
		pans2(pre[u][c],c-1);
		cout<<u-pre[u][c]<<' ';
	}
	void bl()
	{
		memset(dp,127,sizeof(dp));
		dp[0][0]=0;
//		dp[1][1]=1;
		for(int i=1;i<=n;i++)
		{
			dp[i][1]=abs(Q2[i]-i+Q2[i]);
			
		//	cout<<dp[i][1]<<endl;
			for(int j=2;j<=min(i,m);j++)
			{
				for(int k=0;k<i;k++)
				{
					
					if(dp[i][j]>=max(dp[k][j-1],abs(Q2[i]-Q2[k]-i+k+Q2[i]-Q2[k])))
					{
						pre[i][j]=k;
						dp[i][j]=max(dp[k][j-1],abs(Q2[i]-Q2[k]-i+k+Q2[i]-Q2[k]));
					}
				}
			}
			
		}
		pans2(n,m);
	
		
		
		
		memset(dp,127,sizeof(dp));
		dp[0][0]=0;
//		dp[1][1]=1;
		for(int i=1;i<=n;i++)
		{
			dp[i][1]=abs(Q[i]-i+Q[i]);
			
		//	cout<<dp[i][1]<<endl;
			for(int j=2;j<=min(i,m);j++)
			{
				for(int k=0;k<i;k++)
				{
					
					if(dp[i][j]>=max(dp[k][j-1],abs(Q[i]-Q[k]-i+k+Q[i]-Q[k])))
					{
						pre[i][j]=k;
						dp[i][j]=max(dp[k][j-1],abs(Q[i]-Q[k]-i+k+Q[i]-Q[k]));
					}
				}
			}
			
		}
		pans2(n,m);
	}
	int main()
	{
		scanf("%d%d%s",&n,&m,A+1);
		for(int i=1;i<=n;i++)
		{
			Q[i]=Q[i-1]+(A[i]=='1');
			
		}
		for(int i=n;i;i--)
		{
			Q2[i]=Q2[i+1]+(A[i]=='1');
			
		}
		bl();
//		int l=0,r=n,ans=0;
//		while(l<=r)
//		{
//			int mid=(l+r)>>1;
//			if(cheak(mid))
//			{
//				ans=mid;
//				r=mid-1;
//			}
//			else l=mid+1;
//		}
	//	cout<<ans<<endl;
//		tx(0,ans);
		return 0;
	}
}
int main()
{
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	akak::main();
	return 0;
} 
