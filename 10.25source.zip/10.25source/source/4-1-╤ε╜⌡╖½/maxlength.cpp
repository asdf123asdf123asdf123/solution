#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
using namespace std;
namespace yjf{
	const int N=40;
	const int M=910;
	int n,m,t;
	struct node{int x,y;};
	char a[N][N];
	node tmp[M];
	int idx;
	long double maxx;
	bool fl[M],b[N][N];
	int p[M];
	int zh(int x,int y){return (x-1)*m+y;}
	int find(int x){
		if(p[x]!=x) p[x]=find(p[x]);
		return p[x];
	}
	void add(int x,int y){
		int px=find(x);
		int py=find(y);
		if(px!=py){
			p[py]=px;
		}
	}
	bool check(int x,int y){
		int px=find(x);
		int py=find(y);
		if(px!=py) return false;
		else return true;
	}
	long double d(int x1,int y1,int x2,int y2){
		return sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
	}
	void dfs(int u,int cnt){
		if(u==idx+1){
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(a[i][j]=='1') b[i][j]=true;
					else b[i][j]=false;
				}
			}
			for(int i=1;i<=idx;i++){
				if(fl[i]){
					b[tmp[i].x][tmp[i].y]=false;
				}
			}
			for(int i=1;i<=n*m;i++){
				p[i]=i;
			}
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(b[i][j]==false){
						int x,y;
						x=i-1,y=j;
						if(x>=1){
							if(b[x][y]==false){
								add(zh(i,j),zh(x,y));
							}
						}
						x=i,y=j-1;
						if(y>=1){
							if(b[x][y]==false){
								add(zh(i,j),zh(x,y));
							}
						}
					}
				}
			}
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(b[i][j]==false){
						for(int k=1;k<=n;k++){
							for(int l=1;l<=m;l++){
								if(b[k][l]==false && check(zh(i,j),zh(k,l))){
									maxx=max(maxx,d(i,j,k,l));
								}
							}
						}
					}
				}
			}
//			cout<<maxx<<endl;
			return ;
		}
		if(cnt<t){
			fl[u]=true;
			dfs(u+1,cnt+1);
			fl[u]=false;
		}
		if(idx-u>=t-cnt){
			dfs(u+1,cnt);
		}
	}
	int main(){
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
			for(int j=1;j<=m;j++){
				if(a[i][j]=='1'){
					tmp[++idx]={i,j};
				}
			}
		}
		dfs(1,0);
		printf("%.6Lf\n",maxx);
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	return yjf::main();
}
