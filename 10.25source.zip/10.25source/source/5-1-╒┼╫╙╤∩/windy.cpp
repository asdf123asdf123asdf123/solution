#include <iostream>
#include <cstdio>
#include <cmath>
#define ll long long
using namespace std;
namespace zzy{
	const int maxn=100;
	ll sum[maxn][maxn][maxn];
	ll dp[maxn][maxn];
	int n[maxn];
	ll get(ll a){
		ll x=a;
		int l=0;
		n[0]=-2;
		while(x!=0){l++;x/=10;}
		int m=l;
		x=a;
		while(x!=0){n[m--]=x%10;x/=10;}
		int f=1;
		ll cnt=0;
		for(int i=1;i<l;i++){
			for(int x=1;x<=9;x++)cnt+=dp[x][i];
		}
		for(int i=1;i<=l;i++){
			if(f==0)break;
			if(abs(n[i]-n[i-1])<2)f=0;
			int start;
			if(i==1){
				start=1;
			}else{
				start=0;
			}
			for(int x=start;x<n[i];x++){
				if(abs(x-n[i-1])>=2){
					cnt+=dp[x][l-i+1];
				}
			}
		}
		return cnt;
	}
	int main(){
		freopen("windy.in","r",stdin);
		freopen("windy.out","w",stdout);
		ll a,b;
		scanf("%lld%lld",&a,&b);
		for(int i=0;i<=9;i++)sum[i][i][1]=1,dp[i][1]=1;
		for(int k=0;k<=9;k++){
			for(int i=2;i<=10;i++){
				for(int j=0;j<=9;j++){
					for(int x=0;x<=j-2;x++){
						sum[k][j][i]+=sum[k][x][i-1];
					}
					for(int x=j+2;x<=9;x++){
						sum[k][j][i]+=sum[k][x][i-1];
					}
					dp[k][i]+=sum[k][j][i];
				}
			}
		}
		ll s1=get(a);
		ll s2=get(b+1);
		printf("%lld",s2-s1);

		return 0;
	}
}
int main(){
	zzy::main();
	return 0;
}
//8544 KB
