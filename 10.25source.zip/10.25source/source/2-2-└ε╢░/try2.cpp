#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n;
	int tong[2050];
	int lcm(int x,int y){
		return x*y/__gcd(x,y);
	}
	int ans;
	
	int bj[1005][1005];
	void dfs(int now,int sum,int last,int res){
		if(sum==n){
			if(tong[res])return;
			ans++;
			tong[res]=1;
		}
		
		for(int i=last;i<=n-sum;i++){
			int now_l=lcm(res,i);
			if(bj[sum+i][now_l])continue;
			bj[sum+i][now_l]=1;
			dfs(now+1,sum+i,last,now_l);
		}			
	}
	int main(){
		scanf("%d",&n);
		dfs(1,0,1,1);
		cout<<ans<<'\n';
		return 0;
	}
}
int main(){
	ld::main();
	return 0;
}
