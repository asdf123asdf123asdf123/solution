#include<bits/stdc++.h>
using namespace std;
int n,m,t;
int a[55][55],l[100005][4];
int dis[55][55][55][55];
int dx[5],dy[5];
double ans;
bool f[55][55];
char ch[1005];
double node(double x,double y,double xx,double yy){
	return sqrt((x-xx)*(x-xx)+(y-yy)*(y-yy));
}
void spfa(int x,int y){
	int h(0),t(1),xx,yy;
	memset(f,false,sizeof(f));
	dis[x][y][x][y]=a[x][y];
	f[x][y]=true;
	l[t][1]=x;
	l[t][2]=y;
	while(h<=t){
		int p=l[++h][1],q=l[h][2];
		f[p][q]=false;
		for(int i=1;i<=4;++i){
			xx=p+dx[i];
			yy=q+dy[i];
			int num_1=dis[x][y][xx][yy];
			int num_2=dis[x][y][p][q]+a[xx][yy];
			if(xx>=1&&xx<=n&&yy>=1&&yy<=m&&num_1>num_2){
				dis[x][y][xx][yy]=dis[x][y][p][q];
				if(!f[xx][yy]){
					l[++t][1]=xx;
					l[t][2]=yy;
					f[xx][yy]=true;
				}
			}
		}
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	scanf("%d%d%d",&n,&m,&t);
	for(int i=1;i<=n;++i){
		scanf("%*c%s",&ch);
		for(int j=0;j<strlen(ch);++j){
			a[i][j+1]=ch[j]-'0';
		}
	}
	dx[1]=-1;
	dx[2]=0;
	dx[3]=1;
	dx[4]=0;
	dy[1]=0;
	dy[2]=-1;
	dy[3]=0;
	dy[4]=1;
	memset(dis,127/3,sizeof(dis));
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			spfa(i,j);
		}
	}
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			for(int k=1;k<=n;++k){
				for(int p=1;p<=m;++p){
					if(dis[i][j][k][p]<t){
						ans=max(ans,node((double)i,(double)j,double(k),double(p)));
					}
				}
			}
		}
	}
	printf("%.6lf",ans);
	return 0;
} 
