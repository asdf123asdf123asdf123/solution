#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	bool is(int x){
		int last=-10,xx;
		while(x){
			xx=x%10;
			x/=10;
			if(abs(xx-last)<2)
				return false;
			last=xx;
		}
		return true;
	}
	int main(){
		int a,b,ans=0;
		scanf("%d%d",&a,&b);
		for(int i=a;i<=b;i++)
			if(is(i))
				ans++;
		printf("%d",ans);
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("wingding.out","w",stdout);
	estidi::main();
	return 0;
}
