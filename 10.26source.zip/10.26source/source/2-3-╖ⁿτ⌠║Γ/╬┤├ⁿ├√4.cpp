#include<bits/stdc++.h>
using namespace std;
namespace ac{
	
	int main(){
		srand(time(0));
		printf("%d %d\n", 100, 10);
		for(int i = 1;i <= 100;i++) printf("%d", (rand() ^ rand()) & 1);
		return 0;
	}
} 
int main(){
	//freopen("villa.in", "r", stdin);
	//freopen("villa.out", "w", stdout);
	return ac::main();
} 
