#include<bits/stdc++.h>
using namespace std;
namespace Main {
	random_device R;
	mt19937 G(R());
	int main() {
		int n = 8; 
		cout << n << ' ' << G() << '\n';
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j <= n; ++j) {
				cout << G() % 9 + 1;
			}
			cout << '\n';
		}
		return 0;
	}
}
int main() {
//	freopen(".in", "r", stdin);
	freopen("road.in", "w", stdout);
	Main :: main();
	return 0;
} 
