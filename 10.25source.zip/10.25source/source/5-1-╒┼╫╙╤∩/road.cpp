#include <iostream>
#include <cstdio>
using namespace std;
namespace zzy{
	int n,t;
	const int maxn=500;
	const int mod=2009;
	struct Edge{
		int v,w,next;
	}edge[maxn];
	int head[maxn],tot;
	void add_edge(int u,int v,int w){
		edge[++tot].v=v;
		edge[tot].w=w;
		edge[tot].next=head[u];
		head[u]=tot;
	}
	int ans=0;
	void dfs(int u,int x){
		if(u==n&&x==t){
			ans++;
			if(ans>=mod)ans-=mod;
			return ;
		}
		if(x>=t)return ;
		for(int i=head[u];i;i=edge[i].next){
			int v=edge[i].v;
			int w=edge[i].w;
			dfs(v,x+w);
		}
	}
	int main(){
		freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);
		scanf("%d%d",&n,&t);
		for(int i=1;i<=n;i++){
			char s[maxn];
			scanf("%s",s+1);
			for(int j=1;j<=n;j++){
				if(s[j]>='1'){
					add_edge(i,j,s[j]-'0');
				}
			}
		}
		dfs(1,0);
		cout<<ans;

		return 0;
	}
}
int main(){
	zzy::main();
	return 0;
}
//568 KB 
