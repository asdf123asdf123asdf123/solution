#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;
inline int read(){
	int ans = 0;
	char c = getchar();
	while(c < '0' || c > '9')c = getchar();
	while('0' <= c && c <= '9'){
		ans = (ans<<3)+(ans<<1)+c-'0';
		c = getchar();
	}
	return ans;
}
inline void write(int x){
	if(x == 0)return;
	write(x/10);
	putchar(x%10+'0');
}
const int mod = 10007;
int t,n,a,b,ans,arr[1005],vis[1005],fa[1005];
vector<int> vt[1005];
inline int dfs(int x){
	if(x >= n+1){
for(int i = 1;i <= n;i++)printf("%d ",arr[i]);
printf("\n");
		return 1;
	}
	int anss = 0;
	for(int i = 1;i <= n;i++){
		if(vis[i] == 0 && vis[fa[i]] == 1){
			vis[i] = 1;
arr[x] = i;
			anss = (anss+dfs(x+1))%mod;
			vis[i] = 0;
		}
	}
	return anss;
}
int main(){
	//freopen("lineup.in","r",stdin);
	//freopen("lineup.out","w",stdout);
	t = read();
	for(int i = 1;i <= t;i++){
		n = read();
		memset(fa,0,sizeof(fa));
		fa[1] = 1;
		for(int j = 1;j <= n;j++){
			vt[j].clear();
			a = read();
			for(int k = 1;k <= a;k++){
				b = read();
				fa[b] = j;
				vt[j].push_back(b);
			}
		}
		vis[1] = 1;
arr[1] = 1;
		ans = dfs(2);
		if(ans == 0)putchar('0');
		else write(ans);
		putchar('\n');
	}
	return 0;
}
/*
2
5
2 2 3
2 4 5
0
0
0
7
2 2 3
2 4 5
2 6 7
0
0
0
0
*/
