#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
namespace Hualong_Li{
	long long f[15][15];
	inline long long getsum(string a){
		int n = a.length() - 1;
		long long sum = 0;
		for(int i = 1; i < n; i++)
			sum += f[i][1] + f[i][2] + f[i][3] + f[i][4] + f[i][5] + f[i][6] + f[i][7] + f[i][8] + f[i][9];
		for(char i = '1'; i < a[n]; i++)
			sum += f[n][i - '0'];
		for(int i = n - 1; i >= 2; i--){
			for(char j = '0'; j < a[i]; j++)
				if(abs(j - a[i + 1]) >= 2)
					sum += f[i][j - '0'];
			if(abs(a[i] - a[i + 1]) < 2)
				return sum;
		}
		for(char i = '0'; i <= a[1]; i++)
			if(abs(i - a[2]) >= 2)
				sum += f[1][i - '0'];
		return sum;
	}
	int main(){
		f[1][0] = f[1][1] = f[1][2] = f[1][3] = f[1][4] = f[1][5] = f[1][6] = f[1][7] = f[1][8] = f[1][9] = 1;
		for(int i = 2; i <= 10; i++)
			for(int j = 0; j <= 9; j++)
				for(int k = 0; k <= 9; k++)
					if(abs(j - k) >= 2)
						f[i][j] += f[i - 1][k];
		int a, b;
		string x = " ", y = " ";
		scanf("%d%d", &a, &b), a--;
		while(a)
			x += char(a % 10 + '0'), a /= 10;
		while(b)
			y += char(b % 10 + '0'), b /= 10;
		printf("%lld", getsum(y) - getsum(x));
		return 0;
	}
}
int main(){
	freopen("windy.in", "r", stdin);
	freopen("windy.out", "w", stdout);
	return Hualong_Li::main();
}
//1MB
