#include<bits/stdc++.h>
using namespace std;
int dp[1005]; // ǰ i ������ 
int n;
namespace CCF{
	int main(){
		dp[0] = 1;
		dp[1] = 1; 
		dp[2] = 2;
		cin >> n;
		for(int i = 3; i <= n; i ++){
			for(int j = 1; j <= i; j ++){
//				cout << dp[j] <<" " << dp[i-j] <<"\n";
//				cout <<i <<" " << j <<" "<<(dp[j]*dp[i-j])-1 <<"\n";
				dp[i] += (dp[j]*dp[i-j])-1;
			}
		}
		//cout << dp[1] <<" " << dp[2] << " ";
		cout << dp[n];
		return 0;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	CCF::main(); // CCF
	return 0;
}
/*
3
*/
