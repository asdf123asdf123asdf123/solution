#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n,m,t;
	struct edge{
		int from;
		int next;
		int to;
		int w;
	}ed[900050];int ed_cnt;
	int h[200050];
	void add_edge(int x,int y,int w)
	{
		ed[++ed_cnt]={x,h[x],y,w};
		h[x]=ed_cnt;
	}
	
	struct node{
		int pos;
		long long dis;
		int bj;
		bool operator < (const node& b)const {
			return dis>b.dis;
		}
	};
	long long d[200050][2];
	int vis[200050][2];
	priority_queue<node> q;
	void dij(int s){
		for(int i=1;i<=n;i++)
			d[i][0]=d[i][1]=1e18 ,vis[i][0]=vis[i][1]=0;
		
		d[s][0]=0;
		q.push({s,0,0});
		while(!q.empty()){
			int u=q.top().pos;
			int bj=q.top().bj;
			q.pop();
			if(vis[u][bj])continue;
			vis[u][bj]=1;
			for(int i=h[u];i;i=ed[i].next){
				int v=ed[i].to;
				int w=ed[i].w;
				if(i==m){
					if(d[v][1]>d[u][bj]+w){
						d[v][1]=d[u][bj]+w;
						q.push({v,d[v][1],1});
					}
				}
				else {
					if(d[v][bj]>d[u][bj]+w){
						d[v][bj]=d[u][bj]+w;
						q.push({v,d[v][bj],bj});						
					}
				}
			}
		}
	}
	int main(){
		freopen("monogatari.in","r",stdin);
		freopen("monogatari.out","w",stdout);
		
		scanf("%d%d%d",&n,&m,&t);
		t--;
		for(int i=1;i<=m;i++){
			int x,y,w;
			scanf("%d%d%d",&x,&y,&w);
			add_edge(x,y,w);
			add_edge(y,x,w);
		}
		
		int ori=ed[ed_cnt].w;
		int lx=ed[ed_cnt].from;
		int ly=ed[ed_cnt].to;
		
		dij(1);
		long long notpass=d[n][0];
		
		if(d[n][0]==d[n][1]&&d[n][0]==1e18){
			for(int i=1;i<=t+1;i++)
				cout<<"+Inf"<<'\n';
			return 0;
		}
		
		long long tox=d[lx][0];
		long long toy=d[ly][0];
		
		dij(lx);
		long long xto=d[n][0];
		dij(ly);
		long long yto=d[n][0];
		cout<<min(notpass,min(tox+ori+yto, toy+ori+xto))<<'\n';
		
		
		while(t--){
			int now;
			scanf("%d",&now);		
			cout<<min(notpass,min(tox+now+yto, toy+now+xto))<<'\n';
		}
		
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}
