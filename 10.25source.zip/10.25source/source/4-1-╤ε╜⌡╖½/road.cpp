#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
namespace yjf{
	const int N=15;
	const int M=1010;
	const int Mod=2009;
	char a[N][N];
	int idx;
	struct node{
		int n,m;
		int a[M][M];
	};
	node c;
	void operator*(node a,node b){
		c.n=a.n,c.m=b.m;
		for(int i=1;i<=c.n;i++){
			for(int j=1;j<=c.m;j++){
				c.a[i][j]=0;
				for(int k=1;k<=a.m;k++){
					c.a[i][j]+=a.a[i][k]*b.a[k][j]%Mod;
					c.a[i][j]%=Mod;
				}
			}
		}
	}
	node f,d;
	node quick_pow(node ans,node a,int b){ //ans*=a^b
		node tmp=a;
		while(b){
			if(b&1){
				ans*tmp;
				ans=c;
			}
			b>>=1;
			tmp*tmp;
			tmp=c;
		}
		return ans;
	}
	int main(){
		int n,t;
		scanf("%d%d",&n,&t);
		idx=n;
		for(int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
		}
//		cout<<"!!!"<<endl;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a[i][j]!='0'){
					int tmp=i;
					for(int k=1;k<a[i][j]-'0';k++){
						d.a[tmp][++idx]=1;
						//cout<<tmp<<" "<<idx<<endl;
						tmp=idx;
					}
					d.a[tmp][j]=1;
					//cout<<tmp<<" "<<j<<endl;
				}
			}
		}
//		cout<<"!!!";
		f.n=1,f.m=idx;
		f.a[1][1]=1;
		d.n=idx,d.m=idx;
		f=quick_pow(f,d,t);
		/*
		for(int i=1;i<=t;i++){
			f=f*d;
			for(int j=1;j<=f.n;j++){
				for(int k=1;k<=f.m;k++){
					cout<<f.a[j][k]<<" ";
				}
				cout<<endl;
			}
			cout<<endl;
		}
		*/
		printf("%d\n",f.a[1][n]);
		return 0;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	return yjf::main();
}
/*
3 10
023
001
000
*/
