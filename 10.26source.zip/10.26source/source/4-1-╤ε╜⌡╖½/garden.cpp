#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
namespace yjf{
	const int N=100010;
	const int INF=0x3f3f3f3f;
	int a[N];
	int d(int x1,int y1,int x2,int y2){
		return abs(x1-x2)+abs(y1-y2);
	}
	int rf(int l,int r,int x){ //�Ҵ��ڵ���x�� 
		while(l<r){
			int mid=(l+r)>>1;
			if(a[mid]<x){
				l=mid+1;
			}
			else{
				r=mid;
			}
		}
		return l;
	}
	int main(){
		int n;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+1+n);
		a[0]=-INF,a[n+1]=INF,a[n+2]=INF;
		int m,x1,x2,y1,y2;
		scanf("%d",&m);
		for(int i=1;i<=m;i++){
			scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
			if(y1>0 && y2>0){
				printf("%d\n",d(x1,y1,x2,y2));
			}
			else if(y1<0 && y2<0){
				printf("%d\n",d(x1,y1,x2,y2));
			}
			else{
				if(y1<0){
					swap(x1,x2);
					swap(y1,y2);
				}
				int tmp=rf(1,n+1,min(x1,x2));
				int minn=min(d(x1,y1,a[tmp-1],0)+d(a[tmp-1],0,x2,y2),min(d(x1,y1,a[tmp],0)+d(a[tmp],0,x2,y2),d(x1,y1,a[tmp+1],0)+d(a[tmp+1],0,x2,y2)));
				printf("%d\n",minn);
			}
		}
		return 0;
	}
}
int main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	return yjf::main();
}//2MB
