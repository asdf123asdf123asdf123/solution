#include<bits/stdc++.h>
using namespace std;

namespace akak
{
	
	int main()
	{
		
		return 0;
	}
} 
int main()
{
//	freopen("road.in","r",stdin);
//	freopen("road.out","w",stdout);
	akak::main();
	return 0;
}
