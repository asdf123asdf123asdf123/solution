#include<bits/stdc++.h>
using namespace std;
int main(){
	int xx;
	freopen("windy.in","r",stdin);
	cin>>xx>>xx;
	fclose(stdin);
	freopen("windy.in","w",stdout);
	srand(time(0)*xx);
	int x=rand();
	cout<<x<<" "<<x+rand()<<endl;
	return 0;
}
