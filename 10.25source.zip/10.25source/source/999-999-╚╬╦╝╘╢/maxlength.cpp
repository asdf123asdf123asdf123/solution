/*
��ȫ��֪����ô����G��
�ڶ�������Ϊʲô��3.6�� 
����һ�£�������13��ŶŶһ�������ϵ����� 
�Ǿ���sqrt(3^2+2^2)
ΪʲôҪ��t<=2,�ȿ���t<=2
����ÿһ���㣬��ö��һ��
�Ǿ���n^2*m^2���㷨�����Թ���
ֱ�ӹ��ѣ� 
*/ 

#include <bits/stdc++.h>

using namespace std;

namespace rsy{
	
	const int N = 50;
	
	struct node {
		int x, y, cnt;
		bool operator > (const node &w) const {
			return cnt > w.cnt;
		}
	};
	
	bool st[N][N];
	int dx[] = {0, 1, 0, -1};
	int dy[] = {1, 0, -1, 0};
	int n, m, M;
	vector<int> a[N];
	
	double bfs(int i, int j) {
		double cnt = 0;
		priority_queue<node,vector<node>,greater<node>> q;
		q.push(node{i, j, a[i][j]});
		while (q.size()) {
			node t = q.top(); q.pop();
//			if (i == 0 && j == 0)
//				cout << t.x << ' ' << t.y << ' ' << t.cnt << '\n'; 
			cnt = max(cnt, sqrt((t.x - i) * (t.x - i) + (t.y - j) * (t.y - j)));
//			if (fabs(sqrt((t.x - i) * (t.x - i) + (t.y - j) * (t.y - j)) - 11.401754) <= 0.01)
//				cout << i << ' ' << j << ' ' << t.x << ' ' << t.y << ' ' << t.cnt << '\n';
			for (int tmp = 0; tmp < 4; tmp++) {
				int x = dx[tmp] + t.x, y = dy[tmp] + t.y;
				if (x < 0 || y < 0 || x >= n || y >= m) continue;
				if ((t.cnt == M && a[x][y] == 1) || st[x][y]) continue;
				int s = t.cnt + a[x][y];
				q.push(node{x, y, s}), st[x][y] = 1;
			}
		}
		return cnt;
	}
	
	void solve() {
		double res = 0;
		cin >> n >> m >> M;
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++) {
				char s; cin >> s;
				a[i].emplace_back(s - '0');
			} 
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++) {
				if (a[i][j] && !M) continue;
				memset (st, 0, sizeof st);
				st[i][j] = 1;
				res = max(res, bfs(i, j));
			}
		cout << fixed << setprecision(6) << res << '\n';
//		while (1);
//		cout << sqrt(12 * 12 + 10 * 10) << '\n';
	}

	int main(){
		int T = 1;
		while (T -- ) solve();
		return 0;
	}
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	return rsy::main();
}
// 0.5 Mb
