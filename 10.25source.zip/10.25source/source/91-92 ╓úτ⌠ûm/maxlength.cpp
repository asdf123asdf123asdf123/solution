#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

namespace Wyy{
	const int N=33;
	int n,m,T;
	int c[N][N],vis[N][N][N];
	struct dot{
		double x,y;
	};
	dot d[N][N];
	template <typename TP> inline TP pf(TP x){return x*x;}
	inline double dis(dot a,dot b){
		return sqrt(pf(a.x-b.x)+pf(a.y-b.y));
	}
	int dx[4]={1,0,-1,0};
	int dy[4]={0,1,0,-1};
	int sx,sy,tx,ty;
	bool DFS(int nx,int ny,int yu){
		if(yu<0)return false;
		if(nx==tx&&ny==ty)return true;
		for(int i=0,xx,yy;i<4;++i){
			xx=nx+dx[i],yy=ny+dy[i];
			if(xx<1||xx>n||yy<1||yy>m)continue; 
			if(vis[xx][yy][yu-c[xx][yy]])continue;
			for(int j=0;j<=yu-c[xx][yy];++j)
				vis[xx][yy][j]=1;
			if(DFS(xx,yy,yu-c[xx][yy])){return true;}
		}
		return false;
	}
	int fa[1145];
	int gf(int x){
		if(fa[x]==x)return x;
		return fa[x]=gf(fa[x]);
	}
	signed main(){//60S~100S
		scanf("%d%d%d",&n,&m,&T);
		for(register int i=1;i<=n;++i){
			for(register int j=1;j<=m;++j){
				scanf("%1d",&c[i][j]);
				d[i][j].x=i-0.5,d[i][j].y=j-0.5;
				fa[(i-1)*n+j]=(i-1)*n+j;
			}
		}
		if(T==0){//20pts
			for(register int i=1;i<=n;++i)
				for(register int j=1;j<=m;++j){
					if(c[i][j])continue;
					for(register int k=0,xx,yy;k<4;++k){
						xx=i+dx[k],yy=j+dy[k];
						if(xx<1||xx>n||yy<1||yy>m)continue; 
						if(c[xx][yy])continue;
						int fx=gf((i-1)*n+j),fy=gf((xx-1)*n+yy);
						fa[fx]=fa[fy];
					}
				}
			double Ans=0;
			for(register int i=1;i<=n;++i)
				for(register int j=1;j<=m;++j)
					for(register int k=1;k<=n;++k)
						for(register int l=1;l<=m;++l){
							//cout<<i<<" "<<j<<" "<<k<<" "<<l<<endl;
							if(c[i][j]||c[k][l])continue;
							int fx=gf((i-1)*n+j),fy=gf((k-1)*n+l);
							if(fx!=fy)continue;
							Ans=max(Ans,dis(d[i][j],d[k][l]));
						}
			printf("%.6f",Ans);				
			return 0;
		}
		double Ans=0;
		for(register int i=1;i<=n;++i){
			for(register int j=1;j<=m;++j){
				for(register int k=i;k<=n;++k){
					for(register int l=1;l<=m;++l){
						double lo=dis(d[i][j],d[k][l]);
						if(lo<=Ans)continue;
						memset(vis,0,sizeof(vis));
						sx=i,sy=j,tx=k,ty=l;
						for(register int tmp=0;tmp<=T;++tmp)
							vis[sx][sy][tmp]=1;
						if(DFS(sx,sy,T-c[sx][sy])){
							Ans=lo;
						}
					}
				}
			}
		}
		printf("%.6f",Ans);
		return 0;
	}
}
signed main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	Wyy::main();
	return 0;
}

