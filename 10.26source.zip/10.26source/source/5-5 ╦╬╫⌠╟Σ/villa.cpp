#include<bits/stdc++.h>
using namespace std;
string s;
int n,m;
int ns; // �������� 
int gs,m_g;
int gil,boy; // ���������� 
int zs;
namespace No_AFO{
	int main(){
		cin >> n >> m;
		cin >> s;
		for(int i = 0; i < n; i ++){
			if(s[i] == '1'){
				ns ++;
			}
		}
		m_g = ns / m;
		for(int i = 0; i < n; i ++){
			//cout << i <<" " << boy <<" " << gil <<"\n";
			if(s[i] == '1'){
				boy ++;
			}
			if(s[i] == '0'){
				gil++;
			}
			if((gil>m_g||boy > m_g)){
				if(s[i] == '1'){
					boy--;
				}
				else{
					gil--;
				}
				printf("%d ",boy + gil);
				gil = 0;
				boy = 0;
				if(s[i] == '1'){
					boy = 1;
				}
				else{
					gil = 1;
				}
				zs ++;
				if(zs >= m-1){
					//cout <<"?" << i <<"\n";
					printf("%d\n",n-i);
					break;
				}
			}
		}
		gil = 0;
		zs = 0;
		boy = 0;
		for(int i = n-1; i >= 0; i --){
			if(s[i] == '1'){
				boy ++;
			}
			if(s[i] == '0'){
				gil++;
			}
			if((gil>m_g||boy > m_g)){
				if(s[i] == '1'){
					boy--;
				}
				else{
					gil--;
				}
				printf("%d ",boy + gil);
				gil = 0;
				boy = 0;
				if(s[i] == '1'){
					boy = 1;
				}
				else{
					gil = 1;
				}
				zs ++;
				if(zs >= m-1){
					//cout <<"?" << i <<"\n";
					printf("%d ",n-i);
					break;
				}
			}
		}
		return 0;
	}
}
int main() {
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	No_AFO::main(); 
	return 0;
}
/*
8 3
11001100
*/
