#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

namespace Wyy{
	const int N=10+7;
	const int mod=2009;
	int n,Ans=0;ll T;
	int d[N][N];
	void DFS(int now,int Use){
		if(Use>T)return;
		if(Use==T&&now==n){
			Ans=(Ans+1)%2009;
			return;
		}
		for(register int i=1;i<=n;++i){
			if(!d[now][i])continue;
			DFS(i,Use+d[now][i]);
		}
		return;
	}
	signed main(){
		scanf("%d%lld",&n,&T);
		for(register int i=1;i<=n;++i){
			for(register int j=1;j<=n;++j){
				scanf("%1d",&d[i][j]);
			}
		}
		if(T<=100){//30S
			DFS(1,0);
			printf("%d\n",Ans);
			return 0;
		}
		return 0;
	}
}
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	Wyy::main();
	return 0;
}

