#include<cstdio>
using namespace std;
inline int read(){
	int ans = 0;
	char c = getchar();
	while(c < '0' || c > '9')c = getchar();
	while('0' <= c && c <= '9'){
		ans = (ans<<3)+(ans<<1)+c-'0';
		c = getchar();
	}
	return ans;
}
inline void write(int x){
	if(x == 0)return;
	write(x/10);
	putchar(x%10+'0');
}
int n,m;
char arr[5000005];
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	n = read();
	m = read();
	scanf("%s",arr+1);
	printf("%d\n%d",n,n);
	return 0;
}
