#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
using namespace std;
namespace yjf{
	const int N=1010;
	int ans[N]={0,1,2,3,4,6,6,9,11,14,16,20};
	int main(){
		int n;
		scanf("%d",&n);
		printf("%d\n",ans[n]);
		return 0;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	return yjf::main();
}
