#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=35;
	int n,m,t,x1,y1,f[MAXN][MAXN];
	double ans;
	bool mp[MAXN][MAXN],v[MAXN][MAXN];
	int dx[4]={1,0,-1,0};
	int dy[4]={0,1,0,-1};
	void dfs(int x,int y,int cnt) {
		if (cnt>t) return ;
		ans=max(ans,sqrt(double((x-x1)*(x-x1)+(y-y1)*(y-y1))));
		int tx,ty;
		for (int i=0;i<4;i++) {
			tx=x+dx[i],ty=y+dy[i];
			if (tx<1 || ty<1 || tx>n || ty>m) continue;
			if (v[tx][ty]) continue;
			v[tx][ty]=1;
			if (mp[tx][ty]) dfs(tx,ty,cnt+1);
			else dfs(tx,ty,cnt);
			v[tx][ty]=0;
		}
	}
	int main() {
		freopen("maxlength.in","r",stdin);
		freopen("maxlength.out","w",stdout);
		scanf("%d%d%d",&n,&m,&t);
		char c;
		for (int i=1;i<=n;i++) {
			for (int j=1;j<=m;j++) {
				scanf(" %c",&c);
				mp[i][j]=(c=='1');
			}
		}
		for (x1=1;x1<=n;x1++) {
			for (y1=1;y1<=m;y1++) {
				v[x1][y1]=1;
				if (mp[x1][y1]) dfs(x1,y1,1);
				else dfs(x1,y1,0);
				v[x1][y1]=0;
			}
		}
		printf("%.6lf",ans);
		return 0;
	}
}
int main() {
	//1M
	hw::main();
	return 0;
} 
/*
3 3 0 
001 
001 
110

4 3 0 
001 
001 
011 
000

3 3 1 
001 
001 
001
*/
