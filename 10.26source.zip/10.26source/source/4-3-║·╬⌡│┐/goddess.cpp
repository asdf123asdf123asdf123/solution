#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	int n , m;
	int h[10005];
	long long f[10005][2];
	
	int main()
	{
		scanf("%d%d",&n,&m);
		for (int i = 1;i <= n;i++)	scanf("%d",&h[i]);
		h[n+1] = h[1];
		
		//˳ʱ��
		for (int i = 2;i <= n+1;i++)
		{
			if (h[i] > h[i-1])
			{
				int num = h[i]-h[i-1];
				f[i][1] = min(f[i-1][1]+num,f[i-1][0]+num+m);
				f[i][0] = min(f[i-1][1]+num*num+m,f[i-1][0]+num*num);
			}
			if (h[i] < h[i-1])
			{
				int num = h[i-1]-h[i];
				f[i][1] = min(f[i-1][1]+num*num,f[i-1][0]+num*num+m);
				f[i][0] = min(f[i-1][1]+num+m,f[i-1][0]+num);
			}
		}
		long long ans1 = min(f[n+1][1],f[n+1][0]);
		
		//��ʱ��
		memset(f,0,sizeof(f));
		for (int i = n;i >= 1;i--)
		{
			if (h[i] > h[i+1])
			{
				int num = h[i]-h[i+1];
				f[i][1] = min(f[i+1][1]+num,f[i+1][0]+num+m);
				f[i][0] = min(f[i+1][1]+num*num,f[i+1][0]+num*num);
			}
			if (h[i] < h[i+1])
			{
				int num = h[i+1]-h[i];
				f[i][1] = min(f[i+1][1]+num*num,f[i+1][0]+num*num+m);
				f[i][0] = min(f[i+1][1]+num+m,f[i+1][0]+num);
			}
		}
		long long ans2 = min(f[1][1],f[1][0]);

		cout<<min(ans1,ans2)<<'\n';		
		return 0;
	}
}
int main()
{
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
//	while(1);
	hxc::main();
}
