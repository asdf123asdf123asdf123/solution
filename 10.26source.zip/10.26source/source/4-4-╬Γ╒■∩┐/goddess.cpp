#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int n,m;
	int h[24000];
	long long f[24000][3];//j:ȥi��ʱ0����,1�½� 
	long long ans=1e18;
	int main(){
		freopen("goddess.in","r",stdin);
		freopen("goddess.out","w",stdout);
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			scanf("%d",&h[i]);
			h[i+n]=h[i];
		}
		//���� 
		for(int s=1;s<=n;s++){//��ʼ�� 
			for(int i=1;i<=2*n;i++){
				f[i][0]=f[i][1]=1e18;
			}
			f[s][0]=0ll;
			f[s][1]=0ll;
			for(int i=s+1;i<=s+n;i++){
				if(h[i]>h[i-1]){
					f[i][0]=f[i-1][0]+abs(h[i]-h[i-1]);
					f[i][0]=min(f[i][0],f[i-1][1]+m+abs(h[i]-h[i-1]));
					f[i][1]=f[i-1][1]+1ll*(h[i]-h[i-1])*(h[i]-h[i-1]);
					f[i][1]=min(f[i][1],f[i-1][0]+m+1ll*(h[i]-h[i-1])*(h[i]-h[i-1]));
				}else{
					f[i][1]=f[i-1][1]+abs(h[i]-h[i-1]);
					f[i][1]=min(f[i][1],f[i-1][0]+m+abs(h[i]-h[i-1]));
					f[i][0]=f[i-1][0]+1ll*(h[i]-h[i-1])*(h[i]-h[i-1]);
					f[i][0]=min(f[i][0],f[i-1][1]+m+1ll*(h[i]-h[i-1])*(h[i]-h[i-1]));
				}
			}
			ans=min(ans,min(f[s+n][1],f[s+n][0]));
//			for(int i=s+1;i<=s+n;i++){
//				cout<<f[i][0]<<' '<<f[i][1]<<'\n';
//			}
//			cout<<'\n';
		}
		//���� 
//		cout<<"&\n";
		for(int s=n+1;s<=2*n;s++){//��ʼ�� 
			for(int i=1;i<=2*n;i++){
				f[i][0]=f[i][1]=1e18;
			}
			f[s][0]=0ll;
			f[s][1]=0ll;
			for(int i=s-1;i>=s-n;i--){
				if(h[i]>h[i+1]){
					f[i][0]=f[i+1][0]+abs(h[i]-h[i+1]);
					f[i][0]=min(f[i][0],f[i+1][1]+m+abs(h[i]-h[i+1]));
					f[i][1]=f[i+1][1]+1ll*(h[i]-h[i+1])*(h[i]-h[i+1]);
					f[i][1]=min(f[i][1],f[i+1][0]+m+1ll*(h[i]-h[i+1])*(h[i]-h[i+1]));
				}else{
					f[i][1]=f[i+1][1]+abs(h[i]-h[i+1]);
					f[i][1]=min(f[i][1],f[i+1][0]+m+abs(h[i]-h[i+1]));
					f[i][0]=f[i+1][0]+1ll*(h[i]-h[i+1])*(h[i]-h[i+1]);
					f[i][0]=min(f[i][0],f[i+1][1]+m+1ll*(h[i]-h[i+1])*(h[i]-h[i+1]));
				}
			}
			ans=min(ans,min(f[s-n][1],f[s-n][0]));
//			for(int i=s-1;i>=s-n;i--){
//				cout<<f[i][0]<<' '<<f[i][1]<<'\n';
//			}
//			cout<<'\n';
		}
		printf("%lld\n",ans);
		return 0;
	}
}
int main(){
	return wzk::main();
}

