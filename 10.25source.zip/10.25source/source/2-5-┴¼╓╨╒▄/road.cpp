#include<cstdio>
#include<queue>
#include<vector> 
#define ll long long
using namespace std;
struct node{
	ll x,data;
	friend bool operator < (const node a,const node b){
		return a.data > b.data;
	}
}now;
priority_queue<node> que;
const int mod = 2009;
int n,ans = 0;
vector<node> vt[15];
char arr[15][15];
ll t;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d %lld",&n,&t);
	for(int i = 1;i <= n;i++){
		scanf("%s",arr[i]+1);
		for(int j = 1;j <= n;j++){
			if(arr[i][j] != '0'){
				vt[i].push_back({j,arr[i][j]-'0'});
			}
		}
	}
	que.push({1,0});
	while(!que.empty()){
		now = que.top();
		que.pop();
		if(now.data == t){
			if(now.x == n){
				ans++;
				while(ans >= mod)ans -= mod;
			}
			continue;
		}
		for(int i = 0;i < vt[now.x].size();i++){
			if(vt[now.x][i].data+now.data <= t)que.push({vt[now.x][i].x,vt[now.x][i].data+now.data});
		}
	}
	printf("%d",ans);
	return 0;
}//50pts,others:MLE/TLE
/*
10 60
1204512045
0710507105
4780547805
1202412024
1234512345
1204512045
0710507105
4780547805
1202412024
1234512345
*/
