#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int Maxn = 1005, MAX = 1e4+5;

namespace Josh_zmf {

	int N;
//	unorderde_map <int, bool> bj;
	map <int, bool> bj;
	vector <ll> have[Maxn];
//	bool f[Maxn][MAX];
	
	inline int gcd(int a, int b) {
//		if(b == 0)	puts("fdssfd");
		if(a%b == 0)	return b;
		else	return gcd(b, a%b);
	}

	int main() {
		scanf("%d", &N);
		for(int i=1; i<=N; i++) {
//		for(int i=1; i<=1000; i++) {
			bj.clear();
			bj[i] = 1;
			have[i].push_back(i);
//			printf("%d have %d\n", i, i);
			for(int j=1; j<i; j++) {
				for(ll k=0; k<(ll)have[j].size(); k++) {
					ll p = (i-j)*have[j][k]/gcd(have[j][k], i-j);
//					printf("i:%d, p:%d, j:%d, q:%d\n", i, p, j, have[j][k]);
					if(bj[p])	continue;
					bj[p] = 1;
					have[i].push_back(p);
//					printf("%d have %d\n", i, p);
				}
			}
//			printf("%lld,", have[i].size());
		}
		cout<< have[N].size();
		return 0;
	}

}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
//	freopen("game_dabiao.out", "w", stdout);
	Josh_zmf::main();
	return 0;
}
