#include<bits/stdc++.h>
using namespace std;
namespace ld{
	int n,m;
	string s;
	int f[105][105]; 
	int ans=0;
	
	int Cnt(int i,int j){
		int zcnt=0;
		int ocnt=0;
		for(int k=i;k<=j;k++){
			if(s[k]=='0')zcnt++;
			if(s[k]=='1') ocnt++;
		}
		return abs(zcnt-ocnt);
	}
	
	int bj=0;
	void Print_s(int now,int step){
		for(int j=1;j<now;j++){
			int cnt=Cnt(j+1,now);
			if(cnt<=ans){
				Print_s(j,step+1);
				if(bj){
					cout<<now-j<<' ';
					return;
				}
			}
		}
		if(step==m-1){
			int cnt=Cnt(0,now);
			if(cnt<=ans){
				cout<<now<<' ';
				bj=1;				
			}
			return;
		}
	}
	void Print_b(int now,int step){
		for(int j=now-1;j>=1;j--){
			int cnt=Cnt(j+1,now);
			if(cnt<=ans){
				Print_b(j,step+1);
				if(bj){
					cout<<now-j<<' ';
					return;
				}
			}
		}
		if(step==m-1){
			int cnt=Cnt(0,now);
			if(cnt<=ans){
				cout<<now<<' ';
				bj=1;				
			}
			return;
		}
	}	
	int main(){	
		freopen("villa.in","r",stdin);
		freopen("villa.out","w",stdout);
		scanf("%d%d",&n,&m);
		cin>>s;
		s+=" ";
		for(int i=s.length();i>=1;i--){
			s[i]=s[i-1];
		}
		s[0]='2';	
		
		memset(f,0x3f,sizeof(f));
		f[0][0]=1; 
		for(int i=1;i<=n;i++){
			for(int k=1;k<=m;k++){
				for(int j=0;j<i;j++){
					int cnt=Cnt(j+1,i);
					if(cnt<f[j][k-1])f[i][k]=min(f[i][k],f[j][k-1]);
					else f[i][k]=min(f[i][k],cnt);
				}				
			}
		}
		ans=f[n][m];
		Print_s(n,0); 
		bj=0;
		cout<<'\n';
		Print_b(n,0); 
		
		return 0;
	}
} 
int main(){
	ld::main();
	return 0;
}
