#include<bits/stdc++.h>
using namespace std;
namespace Main {
	const int N = 1000 + 5, mod = 10007;
	int Test;
	void add(int &x, int y) {
		x += y;
		if(x >= mod) x -= mod;
	}
	int n;
	vector<int> edges[N];
	struct edge {
		int nxt, to;
	} e[(N * N) << 1];
	int h[N], num;
	int deg[N];
	vector<int> gb[N];
	void addedge(int x, int y) {
		e[++num].nxt = h[x];
		e[num].to = y;
		h[x] = num;
		gb[y].emplace_back(x);
		++deg[y];
	}
	int sz[N], dfnnum;
	int id[N], dfn[N];
	void dfs(int u, int prt) {
		sz[u] = 1;
		id[u] = ++dfnnum;
		dfn[dfnnum] = u;
		for (int i = 0; i < (int)edges[u].size(); ++i) {
			int v = edges[u][i];
			if(v == prt) continue;
			addedge(u, v);
			dfs(v, u);
			sz[u] += sz[v];
			for (int j = 0; j < i; ++j) {
				addedge(edges[u][j], v);
			}
		}
	}
	int q[N];
	int pos[N];
	int ans;
	bool vis[N];
	int lim;
	int xnt;
	void dfs(int x) {
		++xnt;
		if(xnt >= lim) return;
		if(x > n) {
			++ans;
			return;
		}
		
		int maxx = 0;
		for (int v: gb[q[x]]) maxx = max(maxx, pos[v]);
		for (int i = maxx + 1; i <= n; ++i) {
			if(!vis[i]) {
				vis[i] = 1;
				pos[q[x]] = i;
				dfs(x + 1);
				vis[i] = 0;
				pos[q[x]] = 0;
			}
		} 
	}
	int main() {
		scanf ("%d", &Test);
		lim = ceil(6e7 / Test);
		while (Test--) {
			ans = 0;
			scanf("%d", &n);
			dfnnum = 0;
			num = 1;
			xnt = 0;
			for (int i = 1; i <= n; ++i) {
				deg[i] = 0;
			}
			for (int i = 1; i <= n; ++i) edges[i].clear(), edges[i].shrink_to_fit(), h[i] = 0, gb[i].clear(), gb[i].shrink_to_fit();
			for (int i = 1, k; i <= n; ++i) {
				scanf ("%d", &k);
				for (int j = 1, x; j <= k; ++j) {
					scanf ("%d", &x);
					edges[i].emplace_back(x);
				}
			}
			dfs(1, 0);
			int l = 1, r = 0;
			for (int i = 1; i <= n; ++i) {
				if(!deg[i]) q[++r] = i;
			}
			while(l <= r) {
				int x = q[l++];
//				cout << x << '\n';
				for (int i = h[x]; i; i = e[i].nxt) {
					int y = e[i].to;
					--deg[y];
					if(!deg[y]) q[++r] = y;
				}
			}
			dfs(1);
			printf("%d\n", ans % mod);
		}
//		while(1);
		return 0;
	}
}
int main() {
//	int s=clock();
	freopen("lineup.in", "r", stdin);
	freopen("lineup.out", "w", stdout);
	Main::main();
//	int t=clock();
//	cerr<<(t-s)<<'\n';
	return 0;
} 
//meb:16mb
