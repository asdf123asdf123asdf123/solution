#include<bits/stdc++.h>
using namespace std;
namespace AFO{
	const int maxn=1005;
	int n;
	int tmp[maxn],ans;
	map<int,bool>mp;
	int GCD(int a,int b){
		if(a%b==0)return b;
		return GCD(b,a%b);
	}
	int LCM(int a,int b){
		return a/GCD(a,b)*b;
	}
	void DFS(int now,int h,int last){
		if(h==0){
			int x=1;
			for(int i=1;i<now;i++)
				x=LCM(x,tmp[i]);
			if(mp[x])return;
			ans++;
			mp[x]=1;
			return;
		}
		for(int i=last;i<=h;i++){
			tmp[now]=i;
			DFS(now+1,h-i,i);
			tmp[now]=0;
		}
	}
	void clean(){
		memset(tmp,0,sizeof(tmp));
		map<int,bool>no;
		swap(no,mp);		
	}
	int main(){
	//	int n;
	//	scanf("%d",&n);
		for(n=95;n<=1000;n++){
			clean();
			ans=0;
			DFS(1,n,1);
			cout<<ans<<',';
			cerr<<"OK : "<<n<<' '<<ans<<'\n';
		}
		return 0;
	}
}
int main(){
//	freopen("game.in","r",stdin);
	freopen("biao.out","w",stdout);
	AFO::main();
	return 0;
}
