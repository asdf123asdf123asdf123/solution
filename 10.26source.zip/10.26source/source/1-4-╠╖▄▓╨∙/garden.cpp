#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define N 100005
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int n,m;
	ll a[N];
	const ll INF=0x3f3f3f3f3f3f3f3f;
	signed main(){
		n=read();
		a[0]=-INF;
		a[1]=-INF;
		for(int i=2;i<=n+1;i++) a[i]=read();
		a[n+2]=INF;
		a[n+3]=INF;
		sort(a+1,a+1+n+2);
		n+=2;
		m=read();
		while(m--){
			ll x=read(),y=read(),l=read(),r=read();
			ll ans=0x3f3f3f3f3f3f3f3f;
			if((y>0&&r>0)||(y<0&&r<0)){
				printf("%lld\n",abs(y-r)+abs(x-l));
				continue;
			}
			if(x>l) swap(x,l);
			int pos1=lower_bound(a+1,a+1+n,x)-a-1,pos2=upper_bound(a+1,a+1+n,l)-a;
			if(a[pos1+1]<=l||a[pos2-1]>=x){
				printf("%lld\n",abs(y-r)+abs(x-l));
				continue;
			}
			if(pos1!=1) ans=min(ans,abs(x-a[pos1])+abs(l-a[pos1]));
			if(pos2!=n) ans=min(ans,abs(x-a[pos2])+abs(l-a[pos2]));
			ans+=abs(y-r);
			printf("%lld\n",ans);
		}
		return 0;
	}
}
signed main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	TYX_YNXK::main();
	return 0;
}
