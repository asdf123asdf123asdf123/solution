#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define N 100005
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	vector<string> v1,v2;
	string s;
	signed main(){
		freopen("lineup.out","r",stdin);
		getline(cin,s);
		while(s!="*"){
			v1.push_back(s);
			getline(cin,s);
		}
		freopen("lineup6.out","r",stdin);
		getline(cin,s);
		while(s!="*"){
			v2.push_back(s);
			getline(cin,s);
		}
		if(v1.size()!=v2.size()){
			cout<<"WA be too short"<<' '<<v1.size()<<' '<<v2.size()<<'\n';
			return 0;
		}
		int cnt=v1.size();
		for(int i=0;i<cnt;i++){
			if(v1[i]!=v2[i]){
				cout<<"WA on i: "<<v1[i]<<' '<<v2[i]<<'\n';
				putchar(10);
			}
		}
		cout<<"AC";
		return 0;
	}
}
signed main(){
	TYX_YNXK::main();
	return 0;
}
