#include<bits/stdc++.h>
using namespace std;
int n,m;
int tu,tv;
long long tw,ans;
long long a[1000005];
int main(){
	cin >> n;
	for(int i = 1; i <= n; i++){
		scanf("%lld",&a[i]);
	}
	cin >> m;
	for(int i = 1; i <= m; i ++){
		scanf("%d%d%lld",&tu,&tv,&tw);
		a[tu] += tw;
		a[tv] += tw; 
		ans -= tw;
	}
	for(int i = 1; i <= n; i ++){
		if(a[i] > 0){
			ans += a[i];
		}
	}
	cout << ans;
	return 0;
} 
