#include<cstdio>
#include<iostream>
#include<queue>
#include<cmath>
using namespace std;
namespace Hualong_Li{
	const int N = 30, inf = 0x7fffffff / 2;
	const int dx[] = {0, 0, -1, 1}, dy[] = {1, -1, 0, 0};
	int a[N + 10][N + 10];
	int dis[N + 10][N + 10], vis[N + 10][N + 10];
	int n, m, K;
	double ans;
	struct node{
		int dis, x, y;
	};
	priority_queue<node> q;
	bool operator < (node x, node y){
		return x.dis > y.dis;
	}
	inline void dijkstra(int x, int y){
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= n; j++)
				dis[i][j] = inf, vis[i][j] = 0;
		dis[x][y] = a[x][y];
		q.push({dis[x][y], x, y});
		while(q.size()){
			int ux = q.top().x, uy = q.top().y;
			q.pop();
			if(vis[ux][uy])
				continue;
			vis[ux][uy] = 1;
			for(int i = 0; i < 4; i++){
				int vx = ux + dx[i], vy = uy + dy[i];
				if(vx < 1 || vy < 1 || vx > n || vy > m)
					continue;
				if(dis[vx][vy] > dis[ux][uy] + a[vx][vy]){
					dis[vx][vy] = dis[ux][uy] + a[vx][vy];
					q.push({dis[vx][vy], vx, vy});
				}
			}
		}
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= n; j++)
				if(dis[i][j] <= K)
					ans = max(ans, sqrt((x - i) * (x - i) + (y - j) * (y - j)));
	}
	int main(){
		scanf("%d%d%d", &n, &m, &K);
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= m; j++)
				scanf("%1d", &a[i][j]);
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= m; j++)
				dijkstra(i, j);
		printf("%.6lf", ans);
		return 0;
	}
}
int main(){
	freopen("maxlength.in", "r", stdin);
	freopen("maxlength.out", "w", stdout);
	return Hualong_Li::main();
}
//1MB
