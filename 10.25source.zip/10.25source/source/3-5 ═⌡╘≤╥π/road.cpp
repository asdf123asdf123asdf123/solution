#include <bits/stdc++.h>
using namespace std;

namespace wzy{
	int main(){
		puts ("1");
		return 0;
	}
}

int main(){
	freopen ("road.in", "r", stdin);
	freopen ("road.out", "w", stdout);
	return wzy::main();
}
