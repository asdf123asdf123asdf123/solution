#include<bits/stdc++.h>
#define int long long
using namespace std;
namespace F1{
	int n,X1,Y1,X2,Y2;
	int a[100002];
	bool check0(int mid){
		if(a[mid]>=X1){
			return 1;
		}
		return 0;
	}
	bool check1(int mid){
		if(a[mid]>X1){
			return 1;
		}
		return 0;
	}
	bool check2(int mid){
		if(a[mid]<X2){
			return 1;
		}
		return 0;
	}
	signed main(){
		scanf("%lld",&n);
		for(int i=1;i<=n;i++){
			scanf("%lld",&a[i]);
		}
		sort(a+1,a+n+1);
		a[0]=-1e9,a[n+1]=1e9;
		int m;
		scanf("%lld",&m);
		for(int i=1;i<=m;i++){
			scanf("%lld%lld%lld%lld",&X1,&Y1,&X2,&Y2);
			if(X1>X2){
				swap(X1,X2);
				swap(Y1,Y2);
			}
			if(Y1*Y2>=0){
				printf("%lld\n",abs(X1-X2)+abs(Y1-Y2));
				continue;
			}
			bool flag=0;
			int l=0,r=n+1;
			while(l<r){
				int mid=(l+r)>>1;
				if(a[mid]<=X2&&a[mid]>=X1){
					flag=1;
					break;
				}
				if(check0(mid)){
					r=mid;
				}else{
					l=mid+1;
				}
			}
			if(flag){
				printf("%lld\n",abs(X1-X2)+abs(Y1-Y2));
				continue;
			}
			int p=-1;
			l=0,r=n+1;
			while(l<r){
				int mid=(l+r)>>1;
				if(check1(mid)){
					r=mid;
					p=mid-1;
				}else{
					l=mid+1;
				}
			}
			int min1,min2;
			if(p!=-1){
				min1=X1-a[p];
			}else{
				min1=2e18;
			}
			int q=-1;
			l=1,r=n;
			while(l<r){
				int mid=(l+r)>>1;
				if(check2(mid)){
					l=mid+1;
					q=mid+1;
				}else{
					r=mid;
				}
			}
			if(q!=-1){
				min2=a[q]-X2;
			}else{
				min2=2e18;
			}
			int ans=0;
			if(min1<min2){
				ans=X2-a[p]+X1-a[p];
			}else{
				ans=a[q]-X2+a[q]-X1;
			}
			printf("%lld\n",ans+abs(Y1-Y2));
		}
		return 0;
	}
}
signed main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	F1::main();
	return 0;
}
/*
2
2 -1
2
0 1 0 -1
1 1 2 2
*/
