#include <bits/stdc++.h>
#define MAXN 35
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in){
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	int n;
	int m;
	int t;
	bool paper[MAXN][MAXN];
	//bool f[MAXN][MAXN][MAXN];
	char chin;
	double ans;
	
	inline double Dis(int x1, int y1, int x2, int y2){
		int x3=x1-x2;
		int y3=y1-y2;
		return sqrt(x3*x3+y3*y3);
	}
	
	bool tag[MAXN][MAXN][MAXN];
	bool Dfs(int x, int y, int endx, int endy, int lim){
		//cout<<x<<" "<<y<<endl;
		if (x<1 || n<x || y<1 || m<y) return 0;
		if (paper[x][y]) lim--;
		if (lim<0) return 0;
		if (x==endx && y==endy) return 1;
		if (tag[x][y][lim]) return 0;
		tag[x][y][lim]=1;
		if (Dfs(x+1, y, endx, endy, lim)) return 1;
		if (Dfs(x-1, y, endx, endy, lim)) return 1;
		if (Dfs(x, y+1, endx, endy, lim)) return 1;
		if (Dfs(x, y-1, endx, endy, lim)) return 1;
		return 0;
	}
	
	inline void Clean(){
		for (int i=0;i<=n;i++){
			for (int j=0;j<=m;j++){
				for (int k=0;k<=t;k++){
					tag[i][j][k]=0;
				}
			}
		}
		return;
	}
	
	int main(){
		Read (n);
		Read (m);
		Read (t);
		for (int i=1;i<=n;i++){
			while (chin=getchar(), !isdigit(chin) && chin!=EOF);
			for (int j=1;j<=m;j++){
				paper[i][j]=(chin=='1');
				chin=getchar();
			}
		}
		/*
		for (int i=1;i<=n;i++){
			for (int j=1;j<=m;j++){
				cout<<paper[i][j];
			}
			cout<<endl;
		}
		*/
		for (int x=1;x<=n;x++){
			for (int y=1;y<=m;y++){
				/*
				Clean ();
				if (!paper[x][y]){
					f[x][y][0]=1;
					for (int i=x;i<=n;i++){
						for (int j=y;j<=m;j++){
							if (i==x && j==y) continue;
							if (!paper[i][j]) f[i][j][0]|=f[i-1][j][0] || f[i][j-1][0];
							if (f[i][j][0]) ans=max(ans, Dis(x, y, i, j));
						}
					}
				}
				for (int k=1;k<=t;k++){
					f[x][y][k]=1;
					for (int i=x;i<=n;i++){
						for (int j=y;j<=m;j++){
				//cout<<"###"<<endl;
							if (i==x && j==y) continue;
							f[i][j][k]|=f[i][j][k-1];
							if (paper[i][j]) f[i][j][k]|=f[i-1][j][k-1] || f[i][j-1][k-1];
							else f[i][j][k]|=f[i-1][j][k] || f[i][j-1][k];
							if (f[i][j][k]) ans=max(ans, Dis(x, y, i, j));
				//			cout<<x<<" "<<y<<" "<<i<<" "<<j<<" "<<k<<" "<<f[i][j][k]<<endl;
						}
					}
				}
				*/
				for (int i=x;i<=n;i++){
					for (int j=1;j<=m;j++){
						if (i==x && j==y) continue;
						Clean ();
						if (Dfs(x, y, i, j, t)) ans=max(ans, Dis(x, y, i, j));
					}
				}
			}
		}
		printf ("%.6f\n", ans);
		return 0;
	}
}

int main(){
	freopen ("maxlength.in", "r", stdin);
	freopen ("maxlength.out", "w", stdout);
	return wzy::main();
}

/*
3 3 0
001
001
110

4 3 0
001
001
011
000

3 3 1
001
001
001
*/
