#include<bits/stdc++.h>
using namespace std;
namespace estidi{
	vector<int>sons[1003];
	int ins[1003][1003],si[1003],f[1003];
//int sss;
//void sp(int x){
//	while(x--)
//		cerr<<" ";
//}
	void get(int x){
//sp(sss);
//cerr<<"|-"<<x<<endl;
		si[x]=1;
//sss++;
		for(int i=0;i<sons[x].size();i++){
			get(sons[x][i]);
			si[x]+=si[sons[x][i]];
		}
//sss--;
	}
	void getans(int x){
		f[x]=1;
		int y=1;
		for(int i=sons[x].size()-1;i>=0;i--){
			getans(sons[x][i]);
			f[x]=ins[y][si[sons[x][i]]-1]*f[x]%10007*f[sons[x][i]]%10007;
			y+=si[sons[x][i]];
		}
//cerr<<x<<" "<<f[x]<<endl;
	}
	int main(){
		int t,n,k,x;
		for(int i=0;i<=1000;i++){
			ins[1][i]=1;
			ins[i][0]=1;
		}
		for(int i=2;i<=1000;i++)
			for(int j=1;j<=1000;j++)
				ins[i][j]=(ins[i][j-1]+ins[i-1][j])%10007;
//for(int i=1;i<=1000;i++){
//	for(int j=1;j<=1000;j++)
//		cerr<<ins[i][j]<<" ";
//	cerr<<endl;
//}
		scanf("%d",&t);
		while(t--){
			scanf("%d",&n);
			for(int i=1;i<=n;i++){
				scanf("%d",&k);
				while(k--){
					scanf("%d",&x);
					sons[i].push_back(x);
				}
			}
			get(1);
			getans(1);
			printf("%d\n",f[1]);
//cerr<<"-------------------------------\n";
			for(int i=1;i<=n;i++)
				sons[i].clear();
		}
		return 0;
	}
}
int main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	estidi::main();
	return 0;
}
