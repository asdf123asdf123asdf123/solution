#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	int n;
	long long T;
	long long d[15][15],s[15][15],g[15][15];
	int ans;
	int cnt;
	void dfs(int u,int t)
	{
		if(u==n&&t==T)
		{
			ans++;
			ans%=2009;
			return ;
		}
		if(t+s[u][n]>T)return;
		if(t+s[u][n]==T)
		{
			ans=(ans+g[u][n])%2009;
			return ;
		}
		for(int v=1;v<=n;v++)
		{
			if(d[u][v]==1e18)continue;
			dfs(v,t+d[u][v]);
		}
	} 
	int main()
	{
		freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);
		scanf("%d%lld",&n,&T);
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				char w;
				cin>>w;
				d[i][j]=w-'0';
				if(w=='0')d[i][j]=1e18;
				else g[i][j]=1;
				s[i][j]=d[i][j];
				
			}
		}
		for(int k=1;k<=n;k++)
		{
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=n;j++)
				{
					if(s[i][j]==s[i][k]+s[k][j])
					{
						g[i][j]+=g[i][k]*g[k][j]%2009;
					}
					if(s[i][j]>s[i][k]+s[k][j])
					{
						s[i][j]=s[i][k]+s[k][j];
						g[i][j]=g[i][k]*g[k][j]%2009;
					}
					
				}
			}
		}
		
		dfs(1,0);
		printf("%d",ans);
		return 0;
	}
}
int main()
{
	return lzz::main();
}
