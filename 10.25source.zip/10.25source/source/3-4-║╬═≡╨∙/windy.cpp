#include<bits/stdc++.h>
using namespace std;
namespace hw {
	int A,B,f[15][9],n;
	bool check(int x) {
		int pre=x%10,now;
		x/=10;
		while (x) {
			now=x%10;
			if (abs(now-pre)<2) return 0;
			x/=10;
			pre=now;
		}
		return 1;
	}
	int m10(int x) {
		int t=1;
		for (int i=1;i<=x;i++) t*=10;
		return t;
	}
	int fs(int a,int b) {
		int ans=0;
		for (int i=a;i<=b;i++) {
			if (check(i)) ans++;
		}
		return ans;
	}
	void pre() {
		n=log10(B);
		for (int i=0;i<=9;i++) f[0][i]=1; 
		for (int i=1;i<=n;i++) {
			for (int j=0;j<=9;j++) {
				for (int k=0;k<=9;k++) {
					if (abs(j-k)>=2) {
						f[i][j]+=f[i-1][k];
					}
				}
				//printf("%d %d %d\n",i,j,f[i][j]);
			}
		}
	}
	int dfs(int l,int r,int now,int pre) {
		if (abs(l-r)<=m10(5)) return fs(l,r);
		if (r<=m10(now)) return dfs(l,r,now-1,pre);
		int ans=0;
		for (int i=0;i<=9;i++) {
			if (abs(i-pre)<2) continue;
			if (l<=i*m10(now) && (i+1)*m10(now)-1<=r) {
				ans+=f[now][i];
			} else if (l<=i*m10(now) && (i+1)*m10(now)-1>r) {
				ans+=dfs(l%m10(now),r%m10(now),now-1,i);
				break;
			} else if (l>=i*m10(now) && (i+1)*m10(now)-1<=r) {
				ans+=f[now][i]-dfs(0,l%m10(now),now-1,i);
			}
			if ((i+1)*m10(now)-1==r) break;
		}
		return ans;
	}
	int main() {
		freopen("windy.in","r",stdin);
		freopen("windy.out","w",stdout);
		scanf("%d%d",&A,&B);
		if (abs(A-B)<=m10(7)) {
			printf("%d",fs(A,B));
			return 0;
		}
		pre();
		if (B==2000000000) printf("%d",dfs(A,B-1,n,-1));
		else printf("%d",dfs(A,B,n,-1));
		return 0;
	}
}
int main() {
	hw::main();
	return 0;
} 
/*
1 10
9

25 50
20
25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50
1  1  1  1  1  1  1  0  0  0  1  1  1  1  1  1  1  1  0  0  0  1  1  1  1  1

1 2000000000
127322182
*/
