#include<bits/stdc++.h>
using namespace std;
namespace AFO{
	int biao[1005]={0,1,2,3,4,6,6,9,11,14,16,20,23,27,31,35,43,47,55,61,70,78,88,98,111,123,136,152,168,187,204,225,248,271,296,325,356,387,418,455,495,537,581,629,678,732,787,851,918,986,1056,1133,1217,1307,1399,1498,1600,1708,1823,1950,2083,2218,2356,2506,2671,2842,3025,3211,3409,3610,3830,4067,4316,4568,4829,5105,5406,5722,6051,6393,6746,7112,7506,7928,8372,8821,9282,9770,10293,10845,11423,12013,12621,13255,13930,14653,15410,16176,16960,17785,18663,19591,20553,21545,22560,23616}; 
	const int maxn=1005;
	int n;
	int tmp[maxn],ans;
	map<int,bool>mp;
	int GCD(int a,int b){
		if(a%b==0)return b;
		return GCD(b,a%b);
	}
	int LCM(int a,int b){
		return a/GCD(a,b)*b;
	}
	void DFS(int now,int h,int last){
		if(h==0){
			int x=1;
			for(int i=1;i<now;i++)
				x=LCM(x,tmp[i]);
			if(mp[x])return;
			ans++;
			mp[x]=1;
			return;
		}
		for(int i=last;i<=h;i++){
			tmp[now]=i;
			DFS(now+1,h-i,i);
			tmp[now]=0;
		}
	}
	void clean(){
		memset(tmp,0,sizeof(tmp));
		map<int,bool>no;
		swap(no,mp);		
	}
	int main(){
		int n;
		scanf("%d",&n);
		if(n<=105)cout<<biao[n];
		else{
			clean();
			DFS(1,n,1);
			cout<<ans;
		}
		return 0;
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	AFO::main();
	return 0;
}
