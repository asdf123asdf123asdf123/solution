#include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

namespace Wyy{
	const int N=1005;
	int n,Ans=0;
	int arr[N];
	map<int,bool>vis;
	int gcd(int x,int y){return !y?x:gcd(y,x%y);}
	int lcm(int x,int y){return x*y/gcd(max(x,y),min(x,y));}
	void DFS(int now,int next,int yu){
		if(!yu){
			int flowing_boat=1;
			for(register int i=1;i<now;++i){
//				cout<<arr[i]<<" ";
				flowing_boat=lcm(flowing_boat,arr[i]);
//				cout<<flowing_boat<<endl;
			}
//			cout<<endl;
			if(vis[flowing_boat])return;
//			cout<<flowing_boat<<endl;
//			if(flowing_boat>=300000){
//				for(register int i=1;i<now;++i)
//					cout<<arr[i]<<" ";
//				cout<<endl;
//				cout<<flowing_boat<<endl;
//			}
			vis[flowing_boat]=true;
			++Ans;
			return;
		}
		for(register int i=next;i<=yu;++i){
			arr[now]=i;
			DFS(now+1,i,yu-i);
		} 
		return;
	}
//	struct ZY{
//		vector<pair<int,int> >Prime;
//		ZY(){Prime.clear();return;}
//	};
//	ZY num;
//	int f[N];
	signed main(){
		scanf("%d",&n);
		//if(n<=60){//30S
			DFS(1,1,n);
			printf("%d\n",Ans);
			//return 0;
		//}
		return 0;
	}
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	Wyy::main();
	return 0;
}

