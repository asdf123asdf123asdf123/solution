#include<bits/stdc++.h>
using namespace std;
namespace Main {
	
	int main() {
		int T = 0;
		while(1) {
			system("gen_d.exe");
			system("road.exe");
			int s = clock();
			system("test_d.exe");
			int t = clock();
			if(t - s > 1000) {
				cout << "Time Out\n";
				break;
			}
			if(system("fc road2.out road.out")) {
				cout << "Faild\n";
				break; 
			}
			cout << (++T) << '\n';
		}
		return 0;
	}
}
int main() {
//	freopen(".in", "r", stdin);
//	freopen(".out", "w", stdout);
	Main :: main();
	return 0;
} 
