#include <bits/stdc++.h>
using namespace std;
namespace hxc
{
	int t , n , k , ans;
	
	struct edge{int next,to;}ed[1000005];
	int head[1005] , cnt;
	void add(int u,int v)
	{
		cnt++;
		ed[cnt].to = v;
		ed[cnt].next = head[u];
		head[u] = cnt;
		return;
	}//u->v uӦ��v֮�� 
	
	bool bj[1005];int pos[1005] , tot;
	bool check()
	{
		int q[1005];
		for (int i = 1;i <= n;i++)	q[pos[i]] = i;
		for (int u = 1;u <= n;u++)
		{
			for (int i = head[u];i;i = ed[i].next)
			{
				int v = ed[i].to;
				if (q[v] > q[u])	return 0;
			}
		}
		return 1;	
	}
	void dfs(int now)
	{
		if (now == n+1)
		{
			if (check())	ans++;
			return;
		}
		for (int i = 1;i <= n;i++)
		{
			if (bj[i] == 0)
			{
				bj[i] = 1;
				pos[++tot] = i;
				dfs(now+1);
				bj[i] = 0;
				tot--;
			}
		}
		return;
	}
	
	
	int main()
	{
		scanf("%d",&t);
		while (t--)
		{
			for (int i = 0;i <= 1000000;i++)	ed[i] = {0,0};
			memset(head,0,sizeof(head)); cnt = 0;
			
			memset(bj,0,sizeof(bj));
			memset(pos,0,sizeof(pos)); tot = 0;
			ans = 0;
			
			scanf("%d",&n);
			int m;
			for (int i = 1;i <= n;i++)
			{
				scanf("%d",&k);
				int x[1005];
				for (int j = 1;j <= k;j++)
				{
					scanf("%d",&x[j]);
					if (i==1 && j == 1)	m = x[j];
					add(x[j],i);
					for (int l = 1;l < j;l++)	add(x[j],x[l]);
				}
			}
			
			pos[++tot] = 1;
			pos[++tot] = m;
			bj[1] = 1;bj[m] = 1;
			dfs(3);
			cout<<ans<<'\n';
		}
		
		return 0;
	}
}
int main()
{
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	hxc::main();
}
//11mb/256mb
