 #include<bits/stdc++.h>

#define ll long long
#define mp make_pair
#define pb emplace_back
#define Sort stable_sort

using namespace std;

const int INF=2e9+7;

namespace NoFive{
	const int N=1e5+7;
	int n,m;
	int arr[N];
	int bound(int num){
		int L=0,R=n+1,res=-1;
		while(L<=R){
			int mid=(L+R)>>1;
			if(arr[mid]<=num){
				L=mid+1;
				res=mid;
			}else{
				R=mid-1;
			}
		}
		return res;
	}
	signed main(){
		scanf("%d",&n);
		for(register int i=1;i<=n;++i){
			scanf("%d",&arr[i]);
		}
		Sort(arr+1,arr+n+1);
		scanf("%d",&m);
		arr[0]=-INF,arr[n+1]=INF;
		for(register int i=1,x1,x2,y1,y2;i<=m;++i){
			scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
			if((y1>0&&y2>0)||(y1<0&&y2<0)){
				printf("%d\n",abs(x1-x2)+abs(y1-y2));
			}else{
				if(x1>x2)swap(x1,x2);
				int tmp=bound(x1);
//				cout<<tmp<<endl;
				if(x1<=arr[tmp]&&arr[tmp]<=x2){
					printf("%d\n",abs(x1-x2)+abs(y1-y2)); 
				}else if(x1<=arr[tmp+1]&&arr[tmp+1]<=x2){
					printf("%d\n",abs(x1-x2)+abs(y1-y2)); 
				}else{
					int L=arr[tmp],R=arr[tmp+1];
					if(x1-L<=R-x2){
						printf("%d\n",abs(x1-x2)+abs(y1-y2)+2*(x1-L));
					}else{
						printf("%d\n",abs(x1-x2)+abs(y1-y2)+2*(R-x2));
					}
				}
			}
		}
		return 0;
	}
}
signed main(){
	freopen("garden.in","r",stdin);
	freopen("garden.out","w",stdout);
	NoFive::main();
	return 0;
}

