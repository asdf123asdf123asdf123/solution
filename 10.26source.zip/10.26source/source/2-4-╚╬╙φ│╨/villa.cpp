#include<bits/stdc++.h>
using namespace std;
namespace F1{
	string s;
	int n,m,a[100002],minn=1e9,ans[100002];
	bool b[100002];
	void dfs1(int step,int la,int sum){
		if(sum==n&&step==m){
			int cnt=0;
			for(int i=1;i<=m;i++){
				for(int j=a[i-1]+1;j<=a[i];j++){
					if(s[j-1]=='1'){
						cnt++;
					}else{
						cnt--;
					}
				}
			}
			cnt=abs(cnt);
			if(minn>cnt){
				minn=cnt;
				for(int i=1;i<=m;i++){
					ans[i]=a[i];
				}
			}
			return ;
		}
		for(int i=la;i<=n-sum;i++){
			a[step+1]=i;
			dfs1(step+1,i,sum+i);
			a[step+1]=0;
		}
	}
	void dfs2(int step,int la,int sum){
		if(sum==n&&step==m){
			int cnt=0;
			for(int i=1;i<=m;i++){
				for(int j=a[i-1]+1;j<=a[i];j++){
					if(s[i]=='1'){
						cnt++;
					}else{
						cnt--;
					}
				}
			}
			cnt=abs(cnt);
			if(minn>cnt){
				minn=cnt;
				for(int i=1;i<=m;i++){
					ans[i]=a[i];
				}
			}
			return ;
		}
		for(int i=la;i>=n-sum;i--){
			a[step+1]=i;
			dfs2(step+1,i,sum+i);
			a[step+1]=0;
		}
	}
	int main(){
		scanf("%d%d",&n,&m);
		cin>>s;
		if(n==m){
			for(int i=1;i<=n;i++){
				printf("1 ");
			}
			puts("");
			for(int i=1;i<=n;i++){
				printf("1 ");
			}
			return 0;
		}
		if(m==1){
			printf("%d\n%d",n,n);
			return 0;
		}
		if(n%m==0&&n>50){
			for(int i=1;i<=m;i++){
				printf("%d ",n/m);
			}
			puts("");
			for(int i=1;i<=m;i++){
				printf("%d ",n/m);
			}
			return 0;
		}
		dfs1(0,1,0);
		for(int i=1;i<=m;i++){
			printf("%d ",ans[i]);
		}
		puts("");
		minn=1e9;
		dfs2(0,1,0);
		for(int i=1;i<=m;i++){
			printf("%d ",ans[i]);
		}
		return 0;
	}
}
signed main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	F1::main();
	return 0;
}
