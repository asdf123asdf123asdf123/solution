#include<cstdio>
#include<iostream>
using namespace std;
namespace Zimu_Zhao{
	const int N = 1e3, mod = 10007;
	struct edge{
		int nxt, to;
	} e[N + 10];
	int head[N + 10], cnt;
	inline void add(int u, int v){
		e[++cnt] = {head[u], v};
		head[u] = cnt;
	}
	int f[N + 10], size[N + 10];
	int c[N + 10][N + 10];
	int n;
	void dfs(int u){
		size[u] = 0;
		f[u] = 1;
		for(int i = head[u]; i; i = e[i].nxt){
			int v = e[i].to;
			dfs(v);
			f[u] = f[u] * f[v] % mod;
			int sum = 0;
			for(int j = 0; j < size[v] && j <= size[u]; j++)
				sum = (sum + c[size[u]][j] * c[size[v] - 1][j] % mod) % mod;
			f[u] = f[u] * sum % mod;
			size[u] += size[v];
		}
		size[u]++;
	}
	inline void solve(){
		cnt = 0;
		scanf("%d", &n);
		for(int i = 1, j, v; i <= n; i++){
			head[i] = 0;
			scanf("%d", &j);
			while(j--){
				scanf("%d", &v);
				add(i, v);
			}
		}
		dfs(1);
		printf("%d\n", f[1]);
	}
	int main(){
		for(int i = 0; i <= N; i++){
			c[i][0] = 1;
			for(int j = 1; j <= i; j++)
				c[i][j] = (c[i - 1][j - 1] + c[i - 1][j]) % mod;
		}
		int T;
		scanf("%d", &T);
		while(T--)
			solve();
		return 0;
	}
}
int main(){
	freopen("lineup.in", "r", stdin);
	freopen("lineup.out", "w", stdout);
	return Zimu_Zhao::main();
}
//4MB
