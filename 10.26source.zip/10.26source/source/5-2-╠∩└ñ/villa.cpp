#include<bits/stdc++.h>
using namespace std;
namespace last_context{
	const int maxn=1005;
	int f[maxn][maxn];
	char ch[100005];
	int pre[100005];
	int maxx[maxn][maxn];
	int minn[maxn][maxn];
	int n,m;
	void Init(){
		pre[0]=0;
		for(int i=1;i<=n;i++)
			pre[i]=pre[i-1]+ch[i-1]-'0';
	}
	int work(int l,int r){
		int men=pre[r]-pre[l-1];
		int women=r-l+1-men;
		return abs(men-women);
	}
	void print_minn(int i,int j){
		//len:minn[i][j]
		if(minn[i][j]>0)print_minn(minn[i][j],j-1);
		cout<<i-minn[i][j]<<' ';
	}
	void print_maxx(int i,int j){
		//len:minn[i][j]
		if(maxx[i][j]>0)print_maxx(maxx[i][j],j-1);
		cout<<i-maxx[i][j]<<' ';
	}
	int main(){
		scanf("%d%d",&n,&m);
		scanf("%s",ch);
		Init();
		memset(f,0x3f,sizeof f);
		f[0][0]=0;
		for(int i=1;i<=n;i++){
		//	if(i%500==0)cerr<<i<<'\n';
			f[i][1]=work(1,i);
			for(int j=2;j<=min(m,i);j++){
				//f[i][j]
				f[i][j]=1e9;
				for(int k=0;k<i;k++){
					if(max(f[k][j-1],work(k+1,i))<f[i][j])minn[i][j]=k;
					if(max(f[k][j-1],work(k+1,i))<=f[i][j])maxx[i][j]=k;
					f[i][j]=min(f[i][j],max(f[k][j-1],work(k+1,i)));
				}
		//		cout<<i<<' '<<j<<' '<<f[i][j]<<'\n';
			}
		}
	//	cout<<"Ans : "<<f[n][m]<<'\n';
		print_minn(n,m);
		cout<<'\n';
		print_maxx(n,m);
		return 0;
	}
}
int main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	last_context::main();
//	while(1);
	return 0;
}
//12924KB=12MB
