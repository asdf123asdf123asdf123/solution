#include<bits/stdc++.h>
using namespace std;
namespace ldm{
	int n,m,t,v[31][31],l,r,dxx[5]={-1,1,0,0},dyy[5]={0,0,-1,1};
	char a[31][31];
	double ans;
	struct node{
		int x,y,v;
	}q[1000001];
	double js(double x,double y,double i,double j){
		return sqrt((x-i)*(x-i)+(y-j)*(y-j));
	}
	void bfs(int x,int y){
		if(t==0&&a[x][y]=='1') return;
		memset(v,0x3f,sizeof(v));
		l=1;
		r=0;
		q[++r].x=x;
		q[r].y=y;
		if(a[x][y]=='1'){
			q[r].v=1;
		}else{
			q[r].v=0;
		}
		while(l<=r){
			int dx=q[l].x;
			int dy=q[l].y;
			int dv=q[l].v;
			l++;
			if(v[dx][dy]<=dv) continue;
			ans=max(ans,js(x,y,dx,dy));
			v[dx][dy]=dv;
			for(int i=0;i<4;i++){
				int fx=dx+dxx[i];
				int fy=dy+dyy[i];
				if(fx>=1&&fx<=n&&fy>=1&&fy<=m){
					if(a[fx][fy]=='0'){
						q[++r].x=fx;
						q[r].y=fy;
						q[r].v=dv;
					}else if(dv+1<=t){
						q[++r].x=fx;
						q[r].y=fy;
						q[r].v=dv+1;
					}
				}
			}
		}
	}
	int main(){
		scanf("%d%d%d",&n,&m,&t);
		for(int i=1;i<=n;i++){
			scanf("%s",a[i]+1);
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				bfs(i,j);
			}
		}
		printf("%.6lf",ans);
		return 0;
	}
}
int main(){
	freopen("maxlength.in","r",stdin);
	freopen("maxlength.out","w",stdout);
	ldm::main();
	return 0;
}
//12m 256m
