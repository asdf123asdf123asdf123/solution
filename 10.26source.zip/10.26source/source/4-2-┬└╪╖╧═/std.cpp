#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
namespace Main {
	const int N = 20000 + 5;
	int n, m;
	int a[N];
	ll f[N][2];
	mt19937 G(time(0));
	//0:������1���½� 
	void solve1(int j, int i) {
		int h = abs(a[j] - a[i]);
//		if(j == 5 && i == 4)cout << h <<' ' << f[i][1] << '\n';
		f[j][0] = f[i][0] + h;
		f[j][1] = f[i][1] + 1ll * h * h;
		f[j][0] = min(f[j][0], f[j][1] + m);
		f[j][1] = min(f[j][1], f[j][0] + m);
	}
	void solve2(int j, int i) {
		int h = abs(a[j] - a[i]);
		f[j][0] = f[i][0] + 1ll * h * h;
		f[j][1] = f[i][1] + h;
		f[j][0] = min(f[j][0], f[j][1] + m);
		f[j][1] = min(f[j][1], f[j][0] + m);
	}
	int main() {
		scanf ("%d%d", &n, &m);
		for (int i = 1; i <= n; ++i) {
			scanf ("%d", &a[i]);
			a[i + n] = a[i];
			//�ϻ����� 
		}
		bool test = 1;
		if(n <= 1000 || test) {
			ll ans = 9e18;
			for (int s = 1; s <= n; ++s) {
				f[s][0] = f[s][1] = 0;
				int t = s + n;
				for (int j = s + 1; j <= t; ++j) {
					f[j][0] = f[j][1] = 1e18;
					if(a[j] > a[j - 1]) {
						solve1(j, j - 1);
					}
					else {
						solve2(j, j - 1);
					}
				}
				ans = min(ans, min(f[t][0], f[t][1]));
			}
			memset(f, 0x3f, sizeof(f));
			for (int s = n + 1; s <= 2 * n; ++s) {
				f[s][0] = f[s][1] = 0;
				int t = s - n;
				for (int j = s - 1; j >= t; --j) {
					f[j][0] = f[j][1] = 1e18;
					if(a[j] > a[j + 1]) {
						solve1(j, j + 1);
					}
					else {
						solve2(j, j + 1);
					}
				}
				ans = min(ans, min(f[t][0], f[t][1]));
			}
			printf("%lld\n", ans);
		}
		else {
			G.seed(n ^ m);
			ll ans = 9e18;
			int Test = 1000;
			while (Test--) {
				int s = G() % n + 1;
				f[s][0] = f[s][1] = 0;
				int t = s + n;
				for (int j = s + 1; j <= t; ++j) {
					f[j][0] = f[j][1] = 1e18;
					if(a[j] > a[j - 1]) {
						solve1(j, j - 1);
					}
					else {
						solve2(j, j - 1);
					}
				}
				ans = min(ans, min(f[t][0], f[t][1]));
			}
			Test = 1000;
			while(Test--) {
				int s = G() % n + n + 1;
				f[s][0] = f[s][1] = 0;
				int t = s - n;
				for (int j = s - 1; j >= t; --j) {
					f[j][0] = f[j][1] = 1e18;
					if(a[j] > a[j + 1]) {
						solve1(j, j + 1);
					}
					else {
						solve2(j, j + 1);
					}
				}
				ans = min(ans, min(f[t][0], f[t][1]));
			}
			printf("%lld\n", ans);
		}
//		while(1);
		return 0;
	}
}
int main() {
	freopen("goddess.in", "r", stdin);
	freopen("std.out", "w", stdout);
	Main::main();
	return 0;
} 
///0.9mb
