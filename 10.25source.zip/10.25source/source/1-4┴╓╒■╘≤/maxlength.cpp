#include<bits/stdc++.h>
using namespace std;
namespace lzz
{
	int n,m,T;
	int a[32][32];
	int d[2005][2005];
	int p[1005];
	double ans;
	int main()
	{
		freopen("maxlength.in","r",stdin);
		freopen("maxlength.out","w",stdout);
		scanf("%d%d%d",&n,&m,&T);
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				char b;
				cin>>b;
				a[i][j]=b-'0';
				p[(i-1)*m+j]=a[i][j];	
			}
		}
		for(int i=1;i<=n*m;i++)
		{
			for(int j=1;j<=n*m;j++)
			{
				d[i][j]=1e9;
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				int x=(i-1)*m+j;
				if(j<m)d[x][x+1]=a[i][j+1];
				if(j>1)d[x][x-1]=a[i][j-1];
				if(i<n)d[x][x+m]=a[i+1][j];
				if(i>1)d[x][x-m]=a[i-1][j];
				
				d[x][x]=a[i][j];
			}
			
		}
		
		for(int k=1;k<=n*m;k++)
		{
			for(int i=1;i<=n*m;i++)
			{
				if(i==k)continue;	
				for(int j=1;j<=n*m;j++)
				{
					d[i][j]=min(d[i][j],d[i][k]+d[k][j]+p[i]);
				}
			}
		}
		for(int x1=1;x1<=n;x1++)
		{
			for(int y1=1;y1<=m;y1++)
			{
				for(int x2=1;x2<=n;x2++)
				{
					for(int y2=1;y2<=m;y2++)
					{
						int x=(x1-1)*m+y1;
						int y=(x2-1)*m+y2;
						if(d[x][y]<=T)
						{
							
							double w=1.0*sqrt(1.0*(x1-x2)*(x1-x2)+1.0*(y1-y2)*(y1-y2));
							ans=max(ans,w);
						}
					}
				}
			}
		}
		printf("%.6lf",ans);
		return 0;
	}
}
int main()
{
	return lzz::main();
} 
