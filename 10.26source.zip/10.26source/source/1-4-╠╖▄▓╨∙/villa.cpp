#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define N 5000005
	#define M 1005
//	#define N 1005
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int n,m,f[M],s[N],ans=0x7fffffff;
	ll cnt;
	const ll top=1000000;
	char ch[N];
	struct node{
		int s[M];
		node(){
			memset(s,0,sizeof s);
		}
		bl operator<(const node b)const{
			for(int i=1;i<=m;i++){
				if(s[i]<b.s[i]) return 1;
				else if(s[i]>b.s[i]) return 0;
			}
			return 0;
		}
	};
	set<node> st;
	vd dfs(int k,int sum,int mx){
		cnt++;
		if(cnt>=top) return;
		if(k>m){
			if(sum!=n) return;
//			for(int i=1;i<=m;i++) cout<<f[i]<<' ';
//			putchar(10);
			if(mx<ans){
				ans=mx;
				st.clear();
				node t;
				for(int i=1;i<=m;i++) t.s[i]=f[i];
				st.insert(t);
			}else if(mx==ans){
				node t;
				for(int i=1;i<=m;i++) t.s[i]=f[i];
				st.insert(t);
			}
			return;
		}
		if(m-k+1+sum>n) return;
		int all=0;
		for(int i=1;sum+i<=n;i++){
			cnt++;
			if(cnt>=top) return;
			all+=s[sum+i];
			f[k]=i;
			dfs(k+1,sum+i,max(mx,abs(all)));
		}
	}
	signed main(){
		n=read(),m=read();
		scanf("%s",ch+1);
		for(int i=1;i<=n;i++){
			cnt++;
			if(ch[i]=='1') s[i]=1;
			else s[i]=-1;
//			s[i]+=s[i-1];
		}
		dfs(1,0,0);
//		cout<<st.size()<<'\n';
		set<node>::iterator it=st.begin(),ti=st.end();
		ti--;
		for(int i=1;i<=m;i++){
			printf("%d ",it->s[i]);
		}
		putchar(10);
		for(int i=1;i<=m;i++){
			printf("%d ",ti->s[i]);
		}
		return 0;
	}
}
signed main(){
	freopen("villa.in","r",stdin);
	freopen("villa.out","w",stdout);
	TYX_YNXK::main();
	return 0;
}
