#include<bits/stdc++.h>
using namespace std;
namespace hw {
	const int MAXN=1005;
	int T,n,siz[MAXN],edge[MAXN][MAXN];
	long long ans,f[MAXN];
	long long C(int a,int b) {
		long long sum=1ll;
		for (int i=1;i<=b;i++) {
			sum*=1ll*a;
			a--;
		} 
		for (int i=1;i<=b;i++) {
			sum/=1ll*i;
		}
		return sum;
	}
	void dfs(int u) {
		int v;
		for (int i=1;i<=edge[u][0];i++) {
			v=edge[u][i];
			f[v]=max(f[u],1ll*(siz[u])*f[u]);
			dfs(v);
			siz[u]+=siz[v]+1;
		}
		ans*=max(1ll,f[u]);
	}
	int main() {
		freopen("lineup.in","r",stdin);
		freopen("lineup.out","w",stdout);
		scanf("%d",&T);
		while (T--) {
			ans=1ll;
			memset(f,0,sizeof(f));
			memset(siz,0,sizeof(siz));
			for (int i=1;i<=n;i++) edge[i][0]=0;
			scanf("%d",&n);
			for (int i=1;i<=n;i++) {
				scanf("%d",&edge[i][0]);
				for (int j=1;j<=edge[i][0];j++) {
					scanf("%d",&edge[i][j]);
				}	
			}
			f[1]=1;
			dfs(1);
			printf("%lld\n",ans);
		}
		return 0;
	}
}
int main() {
	hw::main();
	return 0;
} 
/*
1 
5 
2 2 3 
2 4 5 
0 
0 
0

1 2 3 4 5
1 2 4 3 5
1 2 4 5 3

1 
5 
2 2 3 
2 4 5 
1 6 
0 
0

1 2 3 4 5 6
1 2 3 4 6 5
1 2 3 6 4 5
1 2 4 3 5 6
1 2 4 3 6 5
1 2 4 5 3 6

1
7 
2 2 3 
2 4 5 
2 6 7 
0 
0 
0 
0

1 2 4 5 3 6 7
1 2 4 3 5 6 7
1 2 4 3 6 5 7
1 2 4 3 6 7 5
1 2 3 4 5 6 7
1 2 3 4 6 5 7
1 2 3 4 6 7 5 
1 2 3 6 4 5 7
1 2 3 6 4 7 5
1 2 3 6 7 4 5

2 
5 
2 2 3 
2 4 5 
0 
0 
0
7 
2 2 3 
2 4 5 
2 6 7 
0 
0 
0 
0
*/
