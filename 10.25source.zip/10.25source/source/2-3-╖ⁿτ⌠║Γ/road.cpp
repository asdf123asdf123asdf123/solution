#include<bits/stdc++.h>
using namespace std;
namespace ac{
	const int MAXN = 105;
	int n, T, val, ans;
	int head[MAXN], cnt;
	struct node{
		int next, to, val;
	}ed[2 * MAXN];
	void add_edge(int u, int v, int val){
		ed[++cnt].next = head[u];
		ed[cnt].to = v;
		ed[cnt].val = val;
		head[u] = cnt;
	}
	void dfs(int u, int len){
		if(!u) return ;
		if(len > T) return ;
		if(u == n && len == T){
			ans++;
			ans %= 2009;
			return ;
		}
		for(int i = head[u];i;i = ed[i].next){
			int v = ed[i].to;
			dfs(v, len + ed[i].val);
		}
	}
	int main(){
		scanf("%d%d", &n, &T);
		for(int i = 1;i <= n;i++){
			for(int j = 1;j <= n;j++){
				scanf("%1d", &val);
				if(val) add_edge(i, j, val);
			}
		} 
		dfs(1, 0);
		printf("%d", ans);//while(1);
		return 0;
	}
} 
int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	return ac::main();
}//664KB
