#include<bits/stdc++.h>
using namespace std;
namespace FireBird{
	int A[12];
	int main(){
		int a,b,ans=0;
		scanf("%d%d",&a,&b);
		for(int i=a;i<=b;i++){
			int r=i,cnt=0;
			while(r){
				A[++cnt]=r%10;
				r/=10;
			}
			bool flag=1;
			for(int j=1;j<cnt;j++){
				if(abs(A[j]-A[j+1])<=1){
					flag=0;
					break;
				}
			}
			if(flag){
				ans++;
			}
		}
		printf("%d",ans);
		return 0;
	}
}
int main(){
	freopen("windy.in","r",stdin);
	freopen("windy.out","w",stdout);
	FireBird::main();
	return 0;
}
