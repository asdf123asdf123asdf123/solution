#include <bits/stdc++.h>
#define int long long 
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ans=(ans<<1)+(ans<<3)+ch-'0';
		ch=getchar();
	}
	return w*ans;
}
int n,m;
long long a[20005];
long long f[20005][2];
long long ans=1e18;
signed main(){
	freopen("goddess.in","r",stdin);
	freopen("goddess.out","w",stdout);
	n=read();
	m=read();
	for(register int i=1;i<=n;i++){
		a[i]=read();
		a[i+n]=a[i]; 
	}
	for(register int k=1;k<=n;k++){
		f[k][0]=0;
		f[k][1]=0;
		for(register int i=k+1;i<=k+n;i++){
			if(a[i]>=a[i-1]){
				f[i][1]=min(f[i-1][1]+abs(a[i]-a[i-1]),f[i-1][0]+(a[i]-a[i-1])*(a[i]-a[i-1])+m);
				f[i][0]=min(f[i-1][1]+abs(a[i]-a[i-1])+m,f[i-1][0]+(a[i]-a[i-1])*(a[i]-a[i-1]));
			}else{//a[i-1]>a[i]
				f[i][1]=min(f[i-1][1]+(a[i]-a[i-1])*(a[i]-a[i-1]),f[i-1][0]+abs(a[i]-a[i-1])+m);
				f[i][0]=min(f[i-1][1]+(a[i]-a[i-1])*(a[i]-a[i-1])+m,f[i-1][0]+abs(a[i]-a[i-1]));	
			}
		}
		ans=min(ans,min(f[k+n][0],f[k+n][1]));
		f[k+n][0]=f[k+n][1]=0;
		for(register int i=k+n-1;i>=k;i--){
			if(a[i]>=a[i+1]){
				f[i][1]=min(f[i+1][1]+abs(a[i]-a[i+1]),f[i+1][0]+(a[i]-a[i+1])*(a[i]-a[i+1])+m);
				f[i][0]=min(f[i+1][1]+abs(a[i]-a[i+1])+m,f[i+1][0]+(a[i]-a[i+1])*(a[i]-a[i+1]));
			}else{//a[i]<a[i+1]
				f[i][1]=min(f[i+1][1]+(a[i]-a[i+1])*(a[i]-a[i+1]),f[i+1][0]+abs(a[i]-a[i+1])+m);
				f[i][0]=min(f[i+1][1]+(a[i]-a[i+1])*(a[i]-a[i+1])+m,f[i+1][0]+abs(a[i]-a[i+1]));	
			}
		}
		ans=min(ans,min(f[k][0],f[k][1]));
	} 
	cout<<ans;
	return 0;
}
//long long !!!!!!
/*
6 7
4 2 6 2 5 6
*/
