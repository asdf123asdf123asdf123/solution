#include<bits/stdc++.h>
using namespace std;
namespace wzk{
	int n;
	map<long long,bool>mp;
	long long ans;
	void dfs(int u,int now,int s){
		if(u>n){
			if(!mp[now+1]){
				ans++;
//				cout<<now+1<<'\n';
				mp[now+1]=1;
			}
			return;
		}
		int ne=now;
		dfs(u+1,ne,s+1);
		ne=now*(s+1)/(__gcd(now,s+1));
		dfs(u+1,ne,0);
	}
	int main(){
		freopen("game.in","r",stdin);
		freopen("game.out","w",stdout);
		scanf("%d",&n);
		dfs(1,1,0);
		printf("%lld\n",ans);
		return 0;
	}
}
int main(){
	return wzk::main();
}

