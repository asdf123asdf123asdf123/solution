#include<bits/stdc++.h>
using namespace std;
namespace last_context{
	const int maxn=1005;
	struct edge{int nxt,to;}eg[maxn*maxn];
	int h[maxn],cnt=0;
	void in(int u,int v){
		eg[++cnt]={h[u],v};
		h[u]=cnt;
	}
	int tmp[maxn],wz[maxn],ans;
	bool bj[maxn];
	int n;
	bool check(){
		for(int i=1;i<=n;i++)
			for(int j=h[i];j;j=eg[j].nxt){
				int u=i,v=eg[j].to;
	//			cout<<u<<' '<<v<<'\n';
				if(wz[u]>wz[v])return 0;
			}
		return 1;
	}
	void dfs(int now){
	//	cout<<now<<'\n';
		if(now>=n+1){
			if(check()){
				ans=(ans+1)%10007;
	//			for(int i=1;i<=n;i++)cout<<tmp[i]<<' ';
	//			cout<<'\n';
			}
			return;
		}
		for(int i=1;i<=n;i++){
			if(bj[i])continue;
			bj[i]=1;
			tmp[now]=i;
			wz[i]=now;
			dfs(now+1);
			bj[i]=0;
			tmp[now]=0;
			wz[i]=0;
		}
	}
	int main(){
		int T,K,last,a;
		scanf("%d",&T);
		while(T--){
			scanf("%d",&n);
			for(int i=1;i<=n;i++){
				scanf("%d",&K);
				last=-1;
				while(K--){
					scanf("%d",&a);
					in(i,a);
					if(last!=-1)in(last,a);
					last=a;
				}
			}
			if(n<=9){
				ans=0;
				memset(tmp,0,sizeof(tmp));
				memset(bj,0,sizeof(bj));
				memset(wz,0,sizeof(wz));
				dfs(1);
				printf("%d\n",ans);
			}else{
				cout<<rand()%10007<<'\n';
			}
		}
		return 0;
	}
}
int main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	last_context::main();
	return 0;
}
/*
2 
5 
2 2 3 
2 4 5 
0 
0 
0 
7 
2 2 3 
2 4 5 
2 6 7 
0 
0 
0 
0

*/
