#include<bits/stdc++.h>
using namespace std;
namespace TYX_YNXK{
	#define il inline
	#define bl bool
	#define ll long long
	#define vd void
	#define c ch=getchar()
	#define mod 10007
	#define N 1005
	il ll read(){
		ll x=0;bl w=1;char c;
		while(ch<48||ch>57){
			if(ch==45) w=0;
			c;
		}while(ch>47&&ch<58){
			x=(x<<3)+(x<<1)+(ch^48);
			c;
		}
		return w?x:-x;
	}
	#undef c
	int T,n,sz[N],f[N],c[N<<1][N<<1];
	il vd init(){
		c[0][0]=1;
		for(int i=1;i<=2000;i++){
			c[i][0]=1;
			for(int j=1;j<i;j++) c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
			c[i][i]=1;
		}
	}
	vector<int> e[N];
	vd dfs(int u){
		f[u]=1;
		int len=e[u].size();
		for(int i=0;i<len;i++){
			int v=e[u][i];
			dfs(v);
		}
		for(int i=len-1;i>=0;i--){
			int v=e[u][i];
			f[u]=f[u]*(f[v]*c[sz[u]+sz[v]-1][sz[u]]%mod)%mod;
			sz[u]+=sz[v];
		}
		sz[u]++;
	}
	signed main(){
		init();
		T=read();
		while(T--){
			n=read();
			for(int i=1;i<=n;i++) e[i].clear(),sz[i]=0,f[i]=0;
			for(int i=1;i<=n;i++){
				int k=read();
				for(int j=1;j<=k;j++){
					int v=read(); 
					e[i].push_back(v);
				}
			}
			dfs(1);
//			for(int i=1;i<=n;i++){
//				cout<<f[i]<<' ';
//			}
//			putchar(10);
			printf("%d\n",f[1]);
		}
		return 0;
	}
}
signed main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	TYX_YNXK::main();
	return 0;
}
