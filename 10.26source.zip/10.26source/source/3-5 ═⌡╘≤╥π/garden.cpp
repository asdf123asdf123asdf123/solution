#include <bits/stdc++.h>
#define P 100002
#define MAXN 200015
using namespace std;

char buf[1<<21];
char* p1;
char* p2;
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf, 1, 1<<21, stdin), p1==p2)?EOF:*p1++)

namespace wzy{
	
	template <typename T> inline void Read(T &in) {
		T w=0;
		T tag=1;
		char ch=0;
		while (ch=getchar(), !isdigit(ch) && ch!=EOF) if (ch=='-') tag=-1;
		if (ch==EOF) return;
		while (isdigit(ch)) w=(w<<1)+(w<<3)+ch-48, ch=getchar();
		return in=tag*w, void();
	}
	
	int n;
	long long num[MAXN];
	int m;
	
	inline long long Abs(long long in){
		if (in>0) return in;
		return -in;
	}
	
	inline long long Dsof(long long u){
		int l=0;
		int r=n;
		int mid=(l+r)>>1;
		int ans=0;
		while (l<=r){
			mid=(l+r)>>1;
			if (num[mid]<=u){
				ans=max(ans, mid);
				l=mid+1;
			}
			else r=mid-1;
		}
		return ans;
	}
	
	inline long long Dsor(long long u){
		int l=0;
		int r=n;
		int mid=(l+r)>>1;
		int ans=n;
		while (l<=r){
			mid=(l+r)>>1;
			if (num[mid]>=u){
				ans=min(ans, mid);
				r=mid-1;
			}
			else l=mid+1;
		}
		return ans;
	}
	
	int main(){
		Read (n);
		for (int i=1;i<=n;i++) Read (num[i]);
		sort (num+1, num+n+1);
		num[++n]=100000001;
		num[0]=-100000001;
		Read (m);
		for (int i=1;i<=m;i++){
			long long x1=0;
			long long y1=0;
			long long x2=0;
			long long y2=0;
			Read (x1);
			Read (y1);
			Read (x2);
			Read (y2);
			if (x1>x2) swap (x1, x2);
			if (y1*y2>0) printf ("%lld\n", Abs(x1-x2)+Abs(y1-y2));
			else if (!y1 && !y2){
				if (Dsof(x2)-Dsof(x1)>=x2-x1) printf ("%lld\n", Abs(x1-x2));
				else printf ("%lld\n", Abs(x1-x2)+2);
			}
			else{
				//if (Ask(min(x1, x2), max(x1, x2))<max(x1, x2)-min(x1, x2)+1) printf ("%lld\n", Abs(x1-x2)+Abs(y1-y2));
				//else{
				//	
				//cout<<num[Dsof(x1)]<<" "<<num[Dsor(x1)]<<" "<<num[Dsof(x2)]<<" "<<num[Dsor(x2)]<<" "<<min(min(x1-num[Dsof(x1)], (long long)(num[Dsor(x1)]<=x2)), min(num[Dsor(x2)]-x2, (long long)(num[Dsof(x2)]>=x1)))<<endl;
				if (num[Dsor(x1)]<=x2 || num[Dsof(x2)]>=x1) printf ("%lld\n", Abs(x1-x2)+Abs(y1-y2));
				else printf ("%lld\n", 2*min(x1-num[Dsof(x1)], num[Dsor(x2)]-x2)+Abs(x1-x2)+Abs(y1-y2));
				//}
			}
		}
		return 0;
	}
}

int main(){
	freopen ("garden.in", "r", stdin);
	freopen ("garden.out", "w", stdout);
	return wzy::main();
}

/*
2
2 -1
2
0 1 0 -1
1 1 2 2
*/
