#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		ans=(ans<<1)+(ans<<3)+ch-'0';
		ch=getchar();
	}
	return w*ans;
}
struct edge{
	int to;
	int next;
}ed[1205];
int cnt;
int h[15];
int fa[15];
void add(int x,int y){
	ed[++cnt]={y,h[x]};
	h[x]=cnt;
}
int T,n;
bool vis[10];
int a[10];
int ans;
bool check(){
	bool st[15]={0,0,0,0,0,0,0,0,0,0,0,0};
	st[1]=1;
	for(int i=2;i<=n;i++){
	//	cout<<"**** "<<i<<' '<<a[i]<<' '<<fa[a[i]]<<' '<<st[fa[a[i]]]<<endl;
		if(!st[fa[a[i]]])return 0;
		st[a[i]]=1;
	} 
	return 1;
}
void dfs(int now){
	if(now==n+1){
		if(check()){
			ans++;
		}
		return ;
	}
	for(int i=2;i<=n;i++){
		if(vis[i])continue;
		a[i]=now;//��i��ȡ��now 
		vis[i]=1;
		dfs(now+1);
		vis[i]=0;
	}
}
int main(){
	freopen("lineup.in","r",stdin);
	freopen("lineup.out","w",stdout);
	T=read();
	while(T--){
		memset (vis,0,sizeof vis);
		memset (a,0,sizeof a);
		memset (fa,0,sizeof fa);
		memset (ed,0,sizeof ed);
		ans=0;
		n=read();
		for(int i=1;i<=n;i++){
			int k=read();
			int last;
			for(int j=1;j<=k;j++){
				int x=read();
				if(j==1){
					add(i,x);
					fa[x]=i;
				}
				else {
					add(last,x);
					fa[x]=last;
				}
				last=x;
			}
		}	
		a[1]=1;
		vis[1]=1;
		dfs(2);
		cout<<ans<<'\n';
	}
	return 0;
} 
/*
2
5
2 2 3
2 4 5
0
0
0
7
2 2 3
2 4 5
2 6 7
0
0
0
0
*/
